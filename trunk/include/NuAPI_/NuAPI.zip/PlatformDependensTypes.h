
#ifndef __PLATFORM_DEPENDENS_TYPES_H__
#define __PLATFORM_DEPENDENS_TYPES_H__

#include <swilib.h>




#endif








