
#ifndef __MEMCTL_H__
#define __MEMCTL_H__

#include <swilib.h>
#include <nu_swilib.h>
#include <NuAPI/ExtList.h>


int MemCtl_push(ExtList *q, void *address, size_t size);
int MemCtl_pop(ExtList *q, void *address);
int MemCtl_replace(ExtList *q, void *from, void *to, int size);
int MemCtl_clean(ExtList *q);
size_t MemCtl_memory_used(ExtList *q);


void *MemCtl_malloc(size_t sz);
int MemCtl_free(void *ptr);
void *MemCtl_calloc(size_t count, size_t size);
void *MemCtl_realloc(void *ptr, size_t size);

#endif
