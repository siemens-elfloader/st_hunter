

#ifndef __TASK_DATA_BASE_H__
#define __TASK_DATA_BASE_H__


#ifdef __cplusplus
extern "C" {
#endif

#define _db_get_task(data)      \
        ((void**)data)[0]

#define _db_is_need_task_kill(data) \
        (((void**)data)[1] == 0)

int task_db_push(ExtTask *task, int no_kill_on_exit);
int task_db_pop(ExtTask *task);
int task_db_is_exist(ExtTask *task);
int task_db_count();
ExtQueue *task_db_queue();

int task_db_kill_and_free();



#ifdef __cplusplus
}
#endif

#endif
