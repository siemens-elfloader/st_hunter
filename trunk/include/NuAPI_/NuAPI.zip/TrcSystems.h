



#define trc_alloc_resource() (TaskResourceControl *)_malloc(sizeof(TaskResourceControl))
