#include <swilib.h>
//#include <stdio.h>

/*
class test
{
public:

        test()
        {

        }

        ~test()
        {

        }


        void my_test()
        {
            help();
        }

        virtual void help() = 0;
};



class Main : public test
{
public:

    Main()
    {

    }

    virtual void help()
    {
        ShowMSG(1, (int)"oO");
    }
};



int main (char *exename, char *fname)
{
    test *m = new Main();

    m->help();


    delete m;

    kill_elf();
    return 0;
}


*/









