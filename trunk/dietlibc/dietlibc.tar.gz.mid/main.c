
#include <swilib.h>
#include <stdio.h>
#include <fcntl.h>
#include <ctype.h>
#include <stdlib.h>
#include <assert.h>

//__BUILDIN_FUNCTIONS

/*
void test_string()
{
    time_t t;
    localtime(&t);
}


int _start()
{
    int ferr = open("0:\\Misc\\elf3\\stderr.txt", O_CREAT | O_WRONLY | O_TRUNC);
    int fout = open("0:\\Misc\\elf3\\stdout.txt", O_CREAT | O_WRONLY | O_TRUNC);
    __setup_stderr_fd(ferr);
    __setup_stdout_fd(fout);

    test_string();

    fflush(stdout);
    fflush(stderr);
    close(fout);
    close(ferr);

    exit(0);
}*/


