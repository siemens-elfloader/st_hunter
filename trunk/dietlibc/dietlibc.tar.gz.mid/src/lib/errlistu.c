/*
 *  used by perror() and strerror()
 */

const char  __sys_err_unknown [] = "[unknown error]";

