extern enum __encoding {
  CT_8BIT,
  CT_UTF8,
} lc_ctype;
