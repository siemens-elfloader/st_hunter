


int
unlockpt (int fd)
{

  return 0;
}
