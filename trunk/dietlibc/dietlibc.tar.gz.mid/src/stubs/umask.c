
#include <sys/types.h>


mode_t
umask(mode_t mode)
{

        return 0777;
}
