
#include <swihelper.h>
#include <stddef.h>



void *realloc(void *ptr, size_t size)
{
    __def_noinline(186, void *, ptr, size);
}
