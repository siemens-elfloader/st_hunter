
#include <swihelper.h>
#include <stddef.h>


void *calloc(size_t nelem, size_t elsize)
{
    __def_noinline(146, void*, nelem, elsize);
}

