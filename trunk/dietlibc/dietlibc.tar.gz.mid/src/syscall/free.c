
#include <swihelper.h>
#include <stddef.h>


void free(void * data)
{
    __def_noinline(21, void, data);
}
