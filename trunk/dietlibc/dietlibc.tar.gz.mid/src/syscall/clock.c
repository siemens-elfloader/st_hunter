
#include <time.h>



clock_t clock(void)
{
    return 0;
}
