#include <getopt.h>
#include <unistd.h>
#include <string.h>

int opterr=1;
int optopt;

int optind=1;
char *optarg;

