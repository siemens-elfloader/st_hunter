#include "dietlocale.h"

enum __encoding lc_ctype=CT_8BIT;
