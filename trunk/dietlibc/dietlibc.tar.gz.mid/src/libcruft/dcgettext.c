#include <libintl.h>

char* dcgettext(const char *domainname, const char *msgid, int category) {
  return (char*)msgid;
}
