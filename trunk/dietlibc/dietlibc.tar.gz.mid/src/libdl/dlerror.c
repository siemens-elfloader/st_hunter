
#include <swilib.h>


const char *dlerror(void) {

    return _dlerror();
}
