
#include <endian.h>