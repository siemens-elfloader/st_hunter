

#ifndef __LANG_PARSER_H__
#define __LANG_PARSER_H__

#include <string>
using namespace std;


int ParseToMssivInLang(char *buf, string lang[2][50]);
int ParseToMassivOutLang(char *buf, string lang[2][50]);



#endif
