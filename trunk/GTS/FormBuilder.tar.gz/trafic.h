


#ifndef __TRAFIC_H__
#define __TRAFIC_H__


extern EForm *traf;



#endif