

#ifndef __LANG_PARSER_H__
#define __LANG_PARSER_H__



int ParseToMssivInLang(char *buf, char *lang[2][50]);
int ParseToMassivOutLang(char *buf, char *lang[2][50]);



#endif