

#ifndef __SIEMENS_H__
#define __SIEMENS_H__

#include <swilib.h>

extern char red[4];
extern char green[4];
extern char blue[4];
extern char white[4];
extern char dark[4];
extern char yelow[4];

class sl
{
public:

   static int char2int(char*buf);
   static void DrwImg(int x, int y, IMGHDR *img);
   static void FreeIMGHDR(IMGHDR *img);
   static void ascii2ws(char *s, WSHDR *ws, int len);
   static int _memcmp(char*s,char*d);
   static char* getDirFromPatch(char *exename);
   static char* getFileNameFromPatch(char *buf);
   static int GetFileSize(const char *file);
   static int IsFileExist(char *file);
   static char* strToLower(char *st);
   static void MSG(int type,int typemsg,char *buf,...);
};



#endif
