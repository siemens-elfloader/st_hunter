

extern "C" LForm *input_lang, *output_lang;
extern "C" int inputlang, outputlang;
extern "C" char *lang[2][50];
extern "C" char *inlang[2][50];

void Start();
void Close();


int ShowMenuInput();
int ShowMenuOutput();
