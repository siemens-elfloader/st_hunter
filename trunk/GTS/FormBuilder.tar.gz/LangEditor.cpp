

#include <swilib.h>
#include "FormBuilder/LForm.h"
#include "FormBuilder/EForm.h"
#include "main.h"
#include "LangEditor.h"
#include "LangConfig.h"





void AllocLangEditor()
{

}


void FreeLangEditor()
{
}
