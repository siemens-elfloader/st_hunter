//******************
//
// CLASS: Read
//
// DESCRIPTION:
//  Vova
//

//#define DEBUG 1

class Read
{
public:
  Read();
  ~Read();

  void SetHeadString();
  int sumbols;
};

extern Read * myread;
