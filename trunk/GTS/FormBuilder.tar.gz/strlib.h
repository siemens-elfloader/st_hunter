
#ifndef __STRLIB_H__
#define __STRLIB_H__


char *
strnstr (const char *phaystack, const char *pneedle);

char *resize(char *c, int size);
char *remove(char *c, int pos, int len);
char *insert(char *c, int pos, const char *i, int s);
char *replace(char *fin, int from, const char *rch, const char *ron);



#endif
