int x[9],y[9]; //���������� ������ ������ 9*9
int csx ,csy, w, h;
char load_canvas = 0;

char pattern_active = 0;
int pattern_cur = 0;

IMGHDR *bgg_canvas_header = 0;
IMGHDR *bgg_canvas_matrix = 0;
IMGHDR *bgg_canvas_softs  = 0;

#define EMENU_XA 0
#define EMENU_YA 0
#define EMENU_CT 6


char emenu_cur = 0;
char emenu_str[EMENU_CT][16]={LG_SE_EMENU_NEW,LG_SE_EMENU_OPEN,LG_SE_EMENU_SAVE,LG_SE_EMENU_CHECK,LG_SE_EMENU_PATTERNS" "PATTERNS_NUMBER_STR,LG_SE_EMENU_EXIT};


void DrawGrid(int csx, int csy, int w, int h, const char *linecol, const char *contcol)
{
    int vl1, vl2, gl1, gl2;
    
    vl1 = 3*dig_img[0]->w+2;
    vl2 = 6*dig_img[0]->w+4;
    
    gl1 = 3*dig_img[0]->h+2;
    gl2 = 6*dig_img[0]->h+4;
    
    
    DrawLine(csx+vl1,csy,csx+vl1,csy+h,0,linecol);
    DrawLine(csx+vl1+1,csy,csx+vl1+1,csy+h,0,linecol);
    DrawLine(csx+vl2,csy,csx+vl2,csy+h,0,linecol);
    DrawLine(csx+vl2+1,csy,csx+vl2+1,csy+h,0,linecol);
    
    DrawLine(csx,csy+gl1,csx+w,csy+gl1,0,linecol);
    DrawLine(csx,csy+gl1+1,csx+w,csy+gl1+1,0,linecol);
    DrawLine(csx,csy+gl2,csx+w,csy+gl2,0,linecol);
    DrawLine(csx,csy+gl2+1,csx+w,csy+gl2+1,0,linecol);
    
    DrawRectangle(csx,csy,csx + w,csy + h,0,contcol,0);
    DrawRectangle(csx+1,csy+1,csx + w - 1,csy + h - 1,0,contcol,0);
}

void EDITW_RENDER()
{
  GBSTIMER_KOEFFICENT = 2;
   
  int hf = GetFontYSIZE(bcfg_gamew_hfont);
   
  if (load_canvas == 0) 
  {
    
   w = MAXXC*dig_img[0]->w+7;
   h = MAXYC*dig_img[0]->h+7;
    
   if (bcfg_gamew_pos == 0)
    {
     csx = ((SCRW/2)-((w+2)/2));
     csy = ((SCRH/2)-((h+2)/2));
    } else 
       {
        csx = bcfg_gamew_posX;
        csy = bcfg_gamew_posY;
       }
   
     for (int i=0;i<3;i++){
       x[i]=(csx+2)+(i*dig_img[0]->w);
       y[i]=(csy+2)+(i*dig_img[0]->h);}
  
     for (int i=3;i<6;i++){
       x[i]=(csx+4)+(i*dig_img[0]->w);
       y[i]=(csy+4)+(i*dig_img[0]->h);}
  
     for (int i=6;i<9;i++){
       x[i]=(csx+6)+(i*dig_img[0]->w);
       y[i]=(csy+6)+(i*dig_img[0]->h);}


       bgg_canvas_softs =  CreateIMGHDRbyfragmentIMGHDR(bgg_img, 0, SCRH - GetFontYSIZE(bcfg_sh_softfont) - 2, SCRW, GetFontYSIZE(bcfg_sh_softfont)+1);
       bgg_canvas_header = CreateIMGHDRbyfragmentIMGHDR(bgg_img, 0, 0, SCRW,GetFontYSIZE(bcfg_gamew_hfont)+5);
       bgg_canvas_matrix = CreateIMGHDRbyfragmentIMGHDR(bgg_img, csx, csy, w, h);


       load_canvas ++;
  }
  
  
    if (TYPEREDRAW == 0) DrwImg(bgg_img, 0, 0, 0, 0);
    else
    {
      if (RENDERWINDOW == 2) DrwImg(bgg_img, 0, 0, 0, 0);
      else
       {
        DrwImg(bgg_canvas_header, 0, 0, 0, 0);
        DrwImg(bgg_canvas_matrix, csx, csy, 0, 0);
        DrwImg(bgg_canvas_softs, 0, SCRH - GetFontYSIZE(bcfg_sh_softfont) - 2, 0, 0);
       }
    }
  
 
      if (esdm->error == 0x04 || pattern_active == 1)
       {
        if (esdm->error == 0x04)
         {
          char rstext[16];
          sprintf(rstext,"%d,%d,%d",esdm->dig,esdm->type,esdm->numquad);
          DrawSoftHeader(LG_SE_EDITW_LS,rstext,ELF_NAME, bcfg_sh_softfont, bcfg_gamew_hfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);
         }
        if (pattern_active == 1)
         {
          char headtext[64];
          sprintf(headtext,"%s #%02d",ELF_NAME,pattern_cur+1);
          DrawSoftHeader(LG_SE_PATTERN_PREV,LG_SE_PATTERN_NEXT,headtext, bcfg_sh_softfont, bcfg_gamew_hfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);
         }
       }
      else DrawSoftHeader(LG_SE_EDITW_LS,0,ELF_NAME, bcfg_sh_softfont, bcfg_gamew_hfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);
    
      //�����
      DrawGrid(csx, csy, w, h, bcfg_gamew_grid_col, bcfg_gamew_kont_col);
    
      //������� ����
       for (int i=0;i<9;i++) for (int k=0;k<9;k++)
        {
         if (sdm->gcell[k][i]<0x0A)                          DrwImg(dig_img[sdm->gcell[k][i]], x[i], y[k], 0, 0);
         if (sdm->gcell[k][i]>0x20 && sdm->gcell[k][i]<0x2A) DrwImg(dig_img[sdm->gcell[k][i]-0x17], x[i], y[k], 0, 0);
        }
    
      
     //������
     DrawRectangle(x[sdm->x],y[sdm->y],x[sdm->x] + dig_img[0]->w - 1,y[sdm->y] + dig_img[0]->h - 1,0,bcfg_gamew_cur_col,bcfg_gamew_cur_bg);
     //�������� ������
     if (esdm->error == 0x04)
     DrawRectangle(x[esdm->x],y[esdm->y],x[esdm->x] + dig_img[0]->w - 1,y[esdm->y] + dig_img[0]->h - 1,0,bcfg_editw_cur_col,red_50); 

   
     if (RENDERWINDOW == 2)
     {
      int w = 6*SCRW/10 + EMENU_XA;
      int h = GetFontYSIZE(bcfg_emenu_font) + 2 + EMENU_YA;
  
      int mx = 1;
      int my = GetFontYSIZE(bcfg_emenu_font) + 2 + 1;
     
      for (int k = 0; k < EMENU_CT; k++)                          
       {           
         if (k==emenu_cur)  DrawRectangle(mx, my + k*h, mx + w,my+k*h + h,0,black,bcfg_emenu_col_m);
                      else  DrawRectangle(mx, my + k*h, mx + w,my+k*h + h,0,black,bcfg_emenu_col_u);
         DrawStringV2(emenu_str[k],mx+1,my + k*h + 2,mx + 1 + w,my + 1 + k*h+h, bcfg_emenu_font,0,bcfg_emenu_col_t,0);
       }
     }
   
}
