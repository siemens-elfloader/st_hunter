int x[9],y[9]; //���������� ������ ������ 9*9
int csx ,csy, w, h;
char load_canvas2 = 0;
int game_timer_temp;
int preview_tumbler = 0, preview_timer = 0;
IMGHDR *bgg_canvas_header = 0;
IMGHDR *bgg_canvas_matrix = 0;
IMGHDR *bgg_canvas_softs  = 0;

char gmenu_cur = 0;
char gmenu_str[4][16]={LG_GMENU_CHECK,LG_GMENU_PREVIEW,LG_GMENU_SAVE,LG_GMENU_LOAD};

#define GMENU_XA 0
#define GMENU_YA 0
#define GMENU_CT 4

#define NAME_TIME_DIST 8

void timeini(int *tmr, int *temp) //�������� ���������� ... :(
{  
   TDate date; TTime time; 
   GetDateTime(&date,&time);
   if (*tmr == 0) *temp = time.hour*60*60 + time.min*60 + time.sec;
   *tmr = time.hour*60*60 + time.min*60 + time.sec - *temp + 1;
}



int scrollini(int maxwidth, int wordlen, int step)
{
 static int x = 0, back = 0;
 if (wordlen > maxwidth)
 {
  if (x <= step)     back = 0;
  if (x >= maxwidth) back = 1;
  if (back == 0) x+=step; else x-=step;
 }
  else x = 1;
 return x;
}





void DrawGrid(int csx, int csy, int w, int h, const char *linecol, const char *contcol)
{
    int vl1, vl2, gl1, gl2;
    
    vl1 = 3*dig_img[0]->w+2;
    vl2 = 6*dig_img[0]->w+4;
    
    gl1 = 3*dig_img[0]->h+2;
    gl2 = 6*dig_img[0]->h+4;
    
    
    DrawLine(csx+vl1,csy,csx+vl1,csy+h,0,linecol);
    DrawLine(csx+vl1+1,csy,csx+vl1+1,csy+h,0,linecol);
    DrawLine(csx+vl2,csy,csx+vl2,csy+h,0,linecol);
    DrawLine(csx+vl2+1,csy,csx+vl2+1,csy+h,0,linecol);
    
    DrawLine(csx,csy+gl1,csx+w,csy+gl1,0,linecol);
    DrawLine(csx,csy+gl1+1,csx+w,csy+gl1+1,0,linecol);
    DrawLine(csx,csy+gl2,csx+w,csy+gl2,0,linecol);
    DrawLine(csx,csy+gl2+1,csx+w,csy+gl2+1,0,linecol);
    
    DrawRectangle(csx,csy,csx + w,csy + h,0,contcol,0);
    DrawRectangle(csx+1,csy+1,csx + w - 1,csy + h - 1,0,contcol,0);
}

void GAMEH_RENDER(int font)
{
 //Timer
 char time[8];
 WSHDR *ws=AllocWS(8);
 str_2ws(ws,"00:00:00",8);
 DrawStringV2(timeBySeconds(time, sdm->sec),SCRW-Get_WS_width(ws, font)-2, 2,SCRW, GetFontYSIZE(font) + 2, font,0,bcfg_gamew_ht,0);
 
 if (sdm->sec > MAXSECOND)
  {
    RENDERWINDOW = 1;
    preview_tumbler = 0;
    ClearSUDOKUMAP(sdm);
    ShowMessage(LG_GAMEW_LOSE_TIME, bcfg_msg_font, MSGINFO);
  }
 
 //Header - name
 WSHDR *ws_scroll=AllocWS(64);
 if (sdm->warn == 0 || sdm->warn == 1)
 {
  str_2ws(ws_scroll, sdm->name, 64);
  DrawStringV3(sdm->name, 2, 2, SCRW-Get_WS_width(ws, font)-NAME_TIME_DIST, GetFontYSIZE(font) + 2, scrollini(SCRW-Get_WS_width(ws, font)-4, Get_WS_width(ws_scroll, font),2), font,0,bcfg_gamew_hn,0);
 }
 if (sdm->warn == 2 || sdm->warn == 3)
 {
  str_2ws(ws_scroll, ELF_NAME, 64);
  DrawStringV3(ELF_NAME, 2, 2, SCRW-Get_WS_width(ws, font)-NAME_TIME_DIST, GetFontYSIZE(font) + 2, scrollini(SCRW-Get_WS_width(ws, font)-4, Get_WS_width(ws_scroll, font),2), font,0,bcfg_gamew_hn,0);
 }
 FreeWS(ws_scroll);
 FreeWS(ws);
}

void GAMEW_RENDER()
{
  GBSTIMER_KOEFFICENT = 2;
   
  int hf = GetFontYSIZE(bcfg_gamew_hfont);
   
  if (load_canvas2 == 0) 
  {
    
   w = MAXXC*dig_img[0]->w+7;
   h = MAXYC*dig_img[0]->h+7;
    
   if (bcfg_gamew_pos == 0)
    {
     csx = ((SCRW/2)-((w+2)/2));
     csy = ((SCRH/2)-((h+2)/2));
    } else 
       {
        csx = bcfg_gamew_posX;
        csy = bcfg_gamew_posY;
       }
   
     for (int i=0;i<3;i++){
       x[i]=(csx+2)+(i*dig_img[0]->w);
       y[i]=(csy+2)+(i*dig_img[0]->h);}
  
     for (int i=3;i<6;i++){
       x[i]=(csx+4)+(i*dig_img[0]->w);
       y[i]=(csy+4)+(i*dig_img[0]->h);}
  
     for (int i=6;i<9;i++){
       x[i]=(csx+6)+(i*dig_img[0]->w);
       y[i]=(csy+6)+(i*dig_img[0]->h);}


       bgg_canvas_softs =  CreateIMGHDRbyfragmentIMGHDR(bgg_img, 0, SCRH - GetFontYSIZE(bcfg_sh_softfont) - 2, SCRW, GetFontYSIZE(bcfg_sh_softfont)+1);
       bgg_canvas_header = CreateIMGHDRbyfragmentIMGHDR(bgg_img, 0, 0, SCRW,GetFontYSIZE(bcfg_gamew_hfont)+5);
       bgg_canvas_matrix = CreateIMGHDRbyfragmentIMGHDR(bgg_img, csx, csy, w, h);


       load_canvas2 ++;
  }
  
  
    if (TYPEREDRAW == 0) DrwImg(bgg_img, 0, 0, 0, 0);
    else
    {
      if (RENDERWINDOW == 2) DrwImg(bgg_img, 0, 0, 0, 0);
      else
       {
        DrwImg(bgg_canvas_header, 0, 0, 0, 0);
        DrwImg(bgg_canvas_matrix, csx, csy, 0, 0);
        DrwImg(bgg_canvas_softs, 0, SCRH - GetFontYSIZE(bcfg_sh_softfont) - 2, 0, 0);
       }
    }
  
       if (sdm->warn == 0 || sdm->warn == 2)
        {
         if (sdm->level == 'L') DrawSoftHeader(LG_GAMEW_LSTEXT,LG_SUDOKULEVELL," ", bcfg_sh_softfont, bcfg_gamew_hfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);
         if (sdm->level == 'M') DrawSoftHeader(LG_GAMEW_LSTEXT,LG_SUDOKULEVELM," ", bcfg_sh_softfont, bcfg_gamew_hfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);
         if (sdm->level == 'H') DrawSoftHeader(LG_GAMEW_LSTEXT,LG_SUDOKULEVELH," ", bcfg_sh_softfont, bcfg_gamew_hfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);
        }
       if (sdm->warn == 1 || sdm->warn == 3) DrawSoftHeader(LG_GAMEW_LSTEXT,LG_GAMEW_RSTEXT," ", bcfg_sh_softfont, bcfg_gamew_hfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);

  
      //�����
      DrawGrid(csx, csy, w, h, bcfg_gamew_grid_col, bcfg_gamew_kont_col);
    
      //������� ����
      if (preview_tumbler == 0)
      {
       for (int i=0;i<9;i++) for (int k=0;k<9;k++)
        {
         if (sdm->gcell[k][i]<0x0A) DrwImg(dig_img[0], x[i], y[k], 0, 0);
         if (sdm->gcell[k][i]>0x10 && sdm->gcell[k][i]<0x1A) DrwImg(dig_img[sdm->gcell[k][i]-0x10], x[i], y[k], 0, 0);
         if (sdm->gcell[k][i]>0x20 && sdm->gcell[k][i]<0x2A) DrwImg(dig_img[sdm->gcell[k][i]-0x17], x[i], y[k], 0, 0);
         if (sdm->gcell[k][i]>0x30 && sdm->gcell[k][i]<0x3A) DrwImg(dig_img[sdm->gcell[k][i]-0x1E], x[i], y[k], 0, 0);
        }
      }
      else 
       {
       for (int i=0;i<9;i++) for (int k=0;k<9;k++)
        {
         if (sdm->gcell[k][i]>0x20 && sdm->gcell[k][i]<0x2A) DrwImg(dig_img[sdm->gcell[k][i]-0x17], x[i], y[k], 0, 0);
                                                        else DrwImg(dig_img[sdm->rcell[k][i]+0x12], x[i], y[k], 0, 0);
        }
       }
      
      
      
     //������
     if (preview_tumbler == 0)
     DrawRectangle(x[sdm->x],y[sdm->y],x[sdm->x] + dig_img[0]->w - 1,y[sdm->y] + dig_img[0]->h - 1,0,bcfg_gamew_cur_col,bcfg_gamew_cur_bg); 

       
     GAMEH_RENDER(bcfg_gamew_hfont);
   
     if (RENDERWINDOW == 7)
     {
      int w = 6*SCRW/10 + GMENU_XA;
      int h = GetFontYSIZE(bcfg_gmenu_font) + 2 + GMENU_YA;
  
      int mx = SCRW/2 - w/2;
      int my = SCRH/2 - (h*GMENU_CT)/2;
     
      for (int k = 0; k < GMENU_CT; k++)                          
       {           
         if (k==gmenu_cur)  DrawRectangle(mx, my + k*h, mx + w,my+k*h + h,0,black,bcfg_gmenu_col_m);
                    else  DrawRectangle(mx, my + k*h, mx + w,my+k*h + h,0,black,bcfg_gmenu_col_u);
         DrawStringV2(gmenu_str[k],mx,my + k*h + 2,mx + w,my + 1 + k*h+h, bcfg_gmenu_font,TEXT_ALIGNMIDDLE,bcfg_gmenu_col_t,0);
       }
      }
   
   GBS_StartTimerProc(&timer,TIMER_SECOND/GBSTIMER_KOEFFICENT,REDRAW_CONTROL);
   
}
