char load_canvas3 = 0;
char datetext[32];
char smenu_cur = 0;
char smenu_str[5][16];

#define SMENU_XA 0
#define SMENU_YA 0
#define SMENU_CT 5 //sizeof(mmenu_str)


IMGHDR *bgm_canvas_smenu  = 0; //������ �� ������� ����


void SMENU_RENDER()
{
int w, h, hd, cy, cmy;
  
  w  = 8*SCRW/10 + SMENU_XA;
  h  = GetFontYSIZE(bcfg_mmenu_font) + SMENU_YA;
  hd = (GetFontYSIZE(bcfg_std_font)+2)*2;
  
  if (SCRH>SCRHM) cy = SCRH/2 - ((h*SMENU_CT)/2 + hd);
             else cy = SCRH/2 - ((h*SMENU_CT)/2 + hd) + 12;
  cmy = cy + hd;

  
  if (load_canvas3 == 0) 
   {
     if (bcfg_redraw == 0)
     bgm_canvas_smenu  = CreateIMGHDRbyfragmentIMGHDR(bgm_img, 0, cy, 9*SCRW/10, h*(SMENU_CT)+1+hd);
     else
     bgm_canvas_smenu  = CreateIMGHDRbyfragmentIMGHDR(bgm_img, 0, cy, SCRW-1, h*(SMENU_CT)+1+hd);
     load_canvas3 = 1;
   }
  
    if (TYPEREDRAW == 0) DrwImg(bgm_img, 0, 0, 0, 0);
    else
    {
      DrwImg(bgm_canvas_smenu, 0, cy, 0, 0);
      DrwImg(bgm_canvas_header, 0, 0, 0, 0);
      DrwImg(bgm_canvas_lsoft, 0,SCRH - GetFontYSIZE(bcfg_sh_softfont) - 2, 0, 0);
      DrwImg(bgm_canvas_rsoft, (6*SCRW)/10, SCRH - GetFontYSIZE(bcfg_sh_softfont) - 2, 0, 0);
    }
    
   sprintf(datetext,"%s:\n%s",LG_SMENU_DATE,ssfnt[smenu_cur]->time);
   DrawStringV2(datetext,2,cy, w, cy + hd, bcfg_std_font,TEXT_OUTLINE,bcfg_std_colp,bcfg_std_colb);
   for (int k = 0; k < SMENU_CT; k++)
    {
     if (bcfg_redraw == 0)
      {
       for (int i=0; i<(9*SCRW/10); i++)                           
       {   
        int a = 100 - (i*100)/(9*SCRW/10);
        char color[2][4]={{bcfg_mmenu_bgcol_u[0],bcfg_mmenu_bgcol_u[1],bcfg_mmenu_bgcol_u[2],a},
                          {bcfg_mmenu_bgcol_m[0],bcfg_mmenu_bgcol_m[1],bcfg_mmenu_bgcol_m[2],a}};
             
        if (k==smenu_cur)  DrawRectangle(i, cmy + k*h, i,cmy+k*h + h,0,color[1],color[1]);
                     else  DrawRectangle(i, cmy + k*h, i,cmy+k*h + h,0,color[0],color[0]);
        }
      }
     if (bcfg_redraw == 1)
      {
        if (k==smenu_cur)  DrawRectangle(0, cmy + k*h, SCRW - 1, cmy+k*h + h,0,black,bcfg_mmenu_bgcol_m);
                     else  DrawRectangle(0, cmy + k*h, SCRW - 1, cmy+k*h + h,0,black,bcfg_mmenu_bgcol_u);
      }
     if (bcfg_redraw == 0) DrawStringV2(ssfnt[k]->name,2,cmy + k*h + 1, w,cmy+ k*h+h + 1, bcfg_mmenu_font,0,bcfg_mmenu_col,0);
                     else  DrawStringV2(ssfnt[k]->name,2,cmy + k*h + 1, SCRW-1,cmy+ k*h+h + 1, bcfg_mmenu_font,0,bcfg_mmenu_col,0);  
    }
   

    if (RENDERWINDOW == 3)
     {
       if (ssfnt[smenu_cur]->error == 0) DrawSoftHeader(LG_SMENU_LSTEXT,LG_SMENU_RSTEXTL,LG_SMENU_LOADH, bcfg_sh_softfont, bcfg_sh_headfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);
                                    else DrawSoftHeader(LG_SMENU_LSTEXT,0,LG_SMENU_LOADH, bcfg_sh_softfont, bcfg_sh_headfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);
     }
    if (RENDERWINDOW == 8)
     {
       if (ssfnt[smenu_cur]->error == 0) DrawSoftHeader(LG_SMENU_LSTEXT,LG_SMENU_RSTEXTR,LG_SMENU_SAVEH, bcfg_sh_softfont, bcfg_sh_headfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);
                                    else DrawSoftHeader(LG_SMENU_LSTEXT,LG_SMENU_RSTEXTS,LG_SMENU_SAVEH, bcfg_sh_softfont, bcfg_sh_headfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);
     }


  
    if (TYPEREDRAW == 1)
     {
      if(IsTimerProc(&timer)) GBS_StopTimer(&timer);    
     }
}
