
char NewGameText[128];
char sudokuname[64];
char sudokulevel[32];

void NMENU_RENDER()
{
 if (TYPEREDRAW == 0)
 {
  DrwImg(bgm_img, 0, 0, 0, 0);
  
  if (sdm->error == 0) DrawSoftHeader(LG_NMENU_LSTEXT,LG_NMENU_RSTEXT1,LG_MMENU_NEWGAME, bcfg_sh_softfont, bcfg_sh_headfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);
                 else  DrawSoftHeader(LG_NMENU_LSTEXT,LG_NMENU_RSTEXT2,LG_MMENU_NEWGAME, bcfg_sh_softfont, bcfg_sh_headfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);

                   
                   
   if (sdm->warn > 0x01 || sdm->error > 0)                       sprintf(sudokuname,LG_UNDEFINED); else sprintf(sudokuname,sdm->name);
   if (sdm->warn == 0x01 || sdm->warn == 0x03 || sdm->error > 0) sprintf(sudokulevel,LG_UNDEFINED);
   else 
      {
       if (sdm->level == 'L')  sprintf(sudokulevel,LG_SUDOKULEVELL);
       if (sdm->level == 'M')  sprintf(sudokulevel,LG_SUDOKULEVELM); 
       if (sdm->level == 'H')  sprintf(sudokulevel,LG_SUDOKULEVELH);
      }
   sprintf(NewGameText,"%s:\n%s\n%s:\n%s", LG_NMENU_SMFNAME, sudokuname,LG_NMENU_SMFLEVEL,sudokulevel);
   DrawStringV2(NewGameText,2,GetFontYSIZE(bcfg_sh_headfont)+7,SCRW-2,SCRH - GetFontYSIZE(bcfg_sh_softfont) - 5,bcfg_std_font,TEXT_OUTLINE,bcfg_std_colp,bcfg_std_colb);
 }
}

