
#ifdef __FILEMAN_SUDOKU__

char path_smffile[256];
int SAVEMENU = 0;
GUI *savew_gui = 0;
WSHDR *ews;


char isdir_filepath(char *path) // 0x01 - exist
{
 char folder[256];
 int n = strlen(path)-strlen((strrchr(path,(int)'\\')+1));
 for (int i=0;i<=256;i++) folder[i]=path[i];
 folder[n]='\0';
 return isdir(folder, 0);
}

inline char iscorrect_filepath(char *path) // 0x01 - correct
{
 char res = 1;
 for (int i=3;i<strlen(path);i++) if (path[i]=='/' || path[i]=='?' || path[i]=='*' || path[i]=='\"' ||
                                      path[i]=='<' || path[i]=='>' || path[i]=='|' || path[i]==':') res = 0;
  return res;
}


SOFTKEY_DESC menu_sk[]=
{
  {0x0018,0x0000,(int)"Left"},
  {0x0001,0x0000,(int)"Right"},
  {0x003D,0x0000,(int)"+"}
};

SOFTKEYSTAB menu_skt=
{
  menu_sk,0
};




void FileCreater(int a)
{
 if (a == 0)
  {
     EDITCONTROL ec1, ec2, ec3;

     ExtractEditControl(savew_gui,2,&ec1);
     ExtractEditControl(savew_gui,4,&ec2);
     ExtractEditControl(savew_gui,6,&ec3);
     
     CreateEXTFILEV20bySUDOKUMAP(sdm, path_smffile, 1);
     char msg[512];
     sprintf(msg,LG_SE_SAVEW_MSG_CREAT,path_smffile);
     ShowMSG(1,(int)msg);
     
     wsprintf(ec1.pWS,pt,path_smffile);
     wsprintf(ec2.pWS,pt,sdm->name);
     wsprintf(ec3.pWS,pc,sdm->level);
     
     StoreEditControl(savew_gui,2,&ec1);
     StoreEditControl(savew_gui,4,&ec2);
     StoreEditControl(savew_gui,6,&ec3);
     
     sprintf(smffilepath,path_smffile);
  }

}



void saver(GUI *data)
{
  EDITCONTROL ec1, ec2, ec3;
  char variant = 0;
      
   ExtractEditControl(data,2,&ec1);
   ExtractEditControl(data,4,&ec2);
   ExtractEditControl(data,6,&ec3);
          
   SAVEMENU = 0;
   char path[256], lev[2];
   
   ws2ascii(path, ec1.pWS);
   ws2ascii(sdm->name, ec2.pWS);
   ws2ascii(lev, ec3.pWS); 
   sdm->level = lev[0];


  if ((((path[0]>0x00 && path[0]<0x30) || (path[0]>0x34 && path[0]<0xFF) || path[0]==0x33) || path[1]!=':' || path[2]!='\\' || path[strlen(path)-1]=='\\' || iscorrect_filepath(path) == 0) && variant == 0) 
   {
    MsgBoxError(1,(int)LG_SE_SAVEW_MSG_PATHS);
    variant = 1;
   }
  
   if (isdir_filepath(path) != 1 && variant == 0)
   {
     MsgBoxError(1,(int)LG_SE_SAVEW_MSG_FOLDE);
     variant = 2;
   }
   
   
  if (sdm->name[0]==0x00 && variant == 0) 
   {
    MsgBoxError(1,(int)LG_SE_SAVEW_MSG_NAMES);
    variant = 3;
   }
       
   if (variant == 0)
    {
     FSTATS stat;
     if (GetFileStats(path, &stat, 0)!=-1 && stat.size) 
      {
        sprintf(path_smffile,path);
        MsgBoxYesNo(1, (int)LG_SE_SAVEW_MSG_EXIST,  FileCreater);
      }
     else
      {
       sprintf(path_smffile,path);
       FileCreater(0);
      }
    }
  
}


void ed1_locret(void){}



void ed1_ghook(GUI *data, int cmd)
{
 static SOFTKEY_DESC options={0x0ABC,0x0000,(int)LG_SE_SAVEW_OPTIONS};

  
  if (cmd==TI_CMD_FOCUS)
  {
    EDITCONTROL ec1, ec2, ec3;
    
    ExtractEditControl(data,2,&ec1);
    ExtractEditControl(data,4,&ec2);
    ExtractEditControl(data,6,&ec3);
    
    if (FILEMAN2 == 1)
     {
      wsprintf(ec1.pWS,pt,smffilepath);
      StoreEditControl(data,2,&ec1);
      FILEMAN2 = 0;
     }
    
    DisableIDLETMR();
    
  }

  if (cmd==TI_CMD_REDRAW)
  {
    SetSoftKey(data,&options,!SET_SOFT_KEY_N);
  }
  
  if (cmd==TI_CMD_CREATE)
  {
    savew_gui = data;
  }
  
}




void on_utf8ec(USR_MENU_ITEM *item)
{
  if (item->type==0)
  {
    switch(item->cur_item)
    {
    case 0:
      wsprintf(item->ws,pt,LG_SE_SAVEW_OPT_SELFO);
      break;
    case 1:
      wsprintf(item->ws,pt,LG_SE_SAVEW_OPT_SELFI);
      break;
     case 2:
      wsprintf(item->ws,pt,LG_SE_SAVEW_OPT_SAVER);
      break;
    }
  }
  if (item->type==1)
  {
    switch(item->cur_item)
    {
    case 0:
      open_fm(smffolder, 0);
      FILEMAN = 1;
      SAVEMENU = 1;
      break;
      
    case 1:
      open_fm(smffolder, 1);
      FILEMAN = 1;
      SAVEMENU = 1;
      break;
      
    case 2:
      saver(savew_gui);
      break;
    
    }
  }   
}




int KEY_CONTROL_SM(GUI *data,char KEYSMSG,int KEYMSG, short keys)
{
  if (KEYMSG == KEY_DOWN)
   {
    if (keys == 0x0ABC)
     {
       FULLREDRAW();
       EDIT_OpenOptionMenuWithUserItems(data,on_utf8ec,data,3);
       return (-1);
     }
    
    if (KEYSMSG == RED_BUTTON)
     {
      SAVEMENU = 0;
      FULLREDRAW();
      FreeWS(ews);
      return (1);
     }
    
   }

 return 0;
}



int ed1_onkey(GUI *data, GUI_MSG *msg)
{
#ifdef MULTISGOLD
  if (IF_NSG || IF_ELKA) return KEY_CONTROL_SM(data,msg->gbsmsg->submess, msg->gbsmsg->msg, msg->keys);
                         return KEY_CONTROL_SM(data,((GBS_MSG_SG*)msg->gbsmsg)->submess, ((GBS_MSG_SG*)msg->gbsmsg)->msg, msg->keys);
#else
  return KEY_CONTROL_SM(data,msg->gbsmsg->submess, msg->gbsmsg->msg, msg->keys);
#endif
  
}



HEADER_DESC ed1_hdr={0,0,0,0,NULL,(int)LG_SE_SAVEW_HEADER,LGP_NULL};

INPUTDIA_DESC ed1_desc=
{
  1,
  ed1_onkey,
  ed1_ghook,
  (void *)ed1_locret,
  0,
  &menu_skt,
  {0,0,0,0},
  4,
  100,
  101,
  0,

//  0x00000001 - ��������� �� ������� ����
//  0x00000002 - ��������� �� ������
//  0x00000004 - �������� ���������
//  0x00000008 - UnderLine
//  0x00000020 - �� ���������� �����
//  0x00000200 - bold
  0,

//  0x00000002 - ReadOnly
//  0x00000004 - �� ��������� ������
//  0x40000000 - �������� ������� ����-������
  0
};




int CreateEditControls(void)
{
  void *ma=malloc_adr();
  void *eq;
  EDITCONTROL ec;

  PrepareEditControl(&ec);
  eq=AllocEQueue(ma,mfree_adr());

  wsprintf(ews,pt,LG_SE_SAVEW_PATHFILE);
  ConstructEditControl(&ec,1,0x40,ews,32);
  AddEditControlToEditQend(eq,&ec,ma);

  if (smffilepath[1]!=':') wsprintf(ews,pt,smffolder);
                      else wsprintf(ews,pt,smffilepath);
  ConstructEditControl(&ec,3,0x40,ews,256);
  AddEditControlToEditQend(eq,&ec,ma);
  
  wsprintf(ews,pt,LG_SE_SAVEW_SDMNAME);
  ConstructEditControl(&ec,1,0x40,ews,32);
  AddEditControlToEditQend(eq,&ec,ma);
  
  if (sdm->name[0]==0x00) wsprintf(ews,pt,bcfg_smfname);
                     else wsprintf(ews,pt,sdm->name);
  ConstructEditControl(&ec,3,0x40,ews,32);
  AddEditControlToEditQend(eq,&ec,ma);

  wsprintf(ews,pt,LG_SE_SAVEW_SDMLEVEL);
  ConstructEditControl(&ec,1,0x40,ews,32);
  AddEditControlToEditQend(eq,&ec,ma);
  
  wsprintf(ews,pc,sdm->level);
  ConstructEditControl(&ec,3,ECF_DISABLE_SMALL_LETTERS,ews,1);
  AddEditControlToEditQend(eq,&ec,ma);

  patch_header(&ed1_hdr);
  patch_input(&ed1_desc);
  return CreateInputTextDialog(&ed1_desc,&ed1_hdr,eq,1,0);
}



void CreateSaveWindow()
{
  ews=AllocWS(256);
  CreateEditControls();
  SAVEMENU = 1;
}

#endif
