

int counter = -1;
char logo_anime = 0;

void LOGOS_RENDER()
{
 GBSTIMER_KOEFFICENT = 20;
  
 DrawRectangle(0,0,SCRW - 1,SCRH - 1, 0, logo_color, logo_color);
 DrwImg((IMGHDR*)&logo_edit_img[logo_anime], SCRW/2 - logo_edit_img[logo_anime].w/2, SCRH/2 - logo_edit_img[logo_anime].h/2, 0, 0);


 char logo_edit_text[64];
 sprintf(logo_edit_text,ELF_NAME" "ELF_VERSION);
 DrawStringV2(logo_edit_text, 2, 2, SCRW, SCRH, 7,TEXT_ALIGNMIDDLE, blue, 0);
 if (AUTHORMODE) DrawStringV2(LG_SE_LOGO_AM, 2, GetFontYSIZE(7) + 2 + 2, SCRW, SCRH, 7,TEXT_ALIGNMIDDLE, red, 0);
 DrawStringV2(LG_SE_LOGO_LOAD, 2, SCRH - GetFontYSIZE(7) - 2, SCRW, SCRH, 7,TEXT_ALIGNMIDDLE, blue, 0);
 
 
  if (counter == -1) {counter++; goto END_LOGOW_RENDER;}
  if (counter >= 0 && counter < 28) 
   {
     if (bcfg_usealpha >  0) dig_img[counter] = CreateIMGHDRFromPngFile(dig[counter], 3);
                        else dig_img[counter] = CreateIMGHDRFromPngFile(dig[counter], 2);
     counter++;
     goto END_LOGOW_RENDER;
   }
 
  if (counter ==  28) 
   {
    bgg_img = CreateIMGHDRFromPngFile(bgg, 2);
    counter++;
    goto END_LOGOW_RENDER;
   }

 
  RENDERWINDOW = 1;
  GBSTIMER_KOEFFICENT = 1;
  FULLREDRAW();
 
END_LOGOW_RENDER:
  
  if (logo_anime == 3)  logo_anime = 0; else logo_anime ++;
  GBS_StartTimerProc(&timer,TIMER_SECOND/GBSTIMER_KOEFFICENT,REDRAW_CONTROL);
  
}

