
char AboutText[128];

void AMENU_RENDER()
{
 if (TYPEREDRAW == 0)
 {
  DrwImg(bgm_img, 0, 0, 0, 0);
  
  DrawSoftHeader(LG_AMENU_LSTEXT,LG_AMENU_RSTEXT,LG_MMENU_ABOUT, bcfg_sh_softfont, bcfg_sh_headfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);
                               
  if (SCRH > SCRHM) sprintf(AboutText, LG_AMENU_ELFAUTHOR":\n"ELF_AUTHOR"\n\n"LG_AMENU_ELFNAME":\n"ELF_NAME" "ELF_VERSION"\n\n"LG_AMENU_ELFSITE":\n"ELF_SITE); 
              else  sprintf(AboutText, LG_AMENU_ELFAUTHOR":\n"ELF_AUTHOR"\n"LG_AMENU_ELFNAME":\n"ELF_NAME" "ELF_VERSION"\n"LG_AMENU_ELFSITE":\n"ELF_SITE);
  DrawStringV2(AboutText,2,GetFontYSIZE(bcfg_sh_headfont)+7,SCRW-2,SCRH - GetFontYSIZE(bcfg_sh_softfont) - 5,bcfg_std_font,TEXT_OUTLINE,bcfg_std_colp,bcfg_std_colb);
 }
}

