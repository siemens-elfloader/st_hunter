
char loadhelp = 0;
char *main_helpbuf = 0;
char *temp_helpbuf = 0;
int helpsize, helpbs, yhelp_cur = 0, yhelp_max;

void HMENU_RENDER()
{
   if (loadhelp == 0)
    {
     FSTATS stat;
     GetFileStats(hlpfile, &stat, 0);
     
     helpsize = stat.size;
     if (bcfg_hmenu_bs > helpsize) helpbs = helpsize; else  helpbs = bcfg_hmenu_bs;
     main_helpbuf = malloc(helpsize);
     temp_helpbuf = malloc(helpsize);
     yhelp_max = helpsize/helpbs;
     
     int hlp = fopen(hlpfile,A_ReadOnly+A_BIN,P_READ,0);
     fread(hlp, main_helpbuf, helpsize,0);
     fclose(hlp,0);
     
     loadhelp++;
    }
   
   zeromem(temp_helpbuf, helpsize);
   memcpy (temp_helpbuf, main_helpbuf + yhelp_cur*helpbs, helpsize - yhelp_cur*helpbs);
   
   if (TYPEREDRAW == 0) 
    {
      DrwImg(bgm_img, 0, 0, 0, 0);  
      DrawSoftHeader(0,LG_HELP_RSTEXT,LG_MMENU_HELP, bcfg_sh_softfont, bcfg_sh_headfont, bcfg_sh_softcolt, bcfg_sh_headcolt, bcfg_sh_softcolg, bcfg_sh_headcolg, bcfg_redraw);
    }

   DrawRectangle(3,3+GetFontYSIZE(bcfg_sh_headfont)+2,SCRW - 4,SCRH - GetFontYSIZE(bcfg_sh_softfont)- 5, TEXT_NOFORMAT, black, white);    
   DrawStringV2(temp_helpbuf,4,GetFontYSIZE(bcfg_sh_headfont)+8,SCRW-5,SCRH - GetFontYSIZE(bcfg_sh_softfont) - 7,bcfg_hmenu_font,0,bcfg_hmenu_col,0);


}

