


WSHDR *ews;

char pt[]="%t";
char ps[]="%s";
char pc[]="%c";

char FMSG = 0,ERROR = 1;

#ifndef MULTISGOLD
#pragma inline
void patch_header(const HEADER_DESC* head)
{
  ((HEADER_DESC*)head)->rc.x=0;
  ((HEADER_DESC*)head)->rc.y=YDISP;
  ((HEADER_DESC*)head)->rc.x2=ScreenW()-1;
  ((HEADER_DESC*)head)->rc.y2=HeaderH()+YDISP-1;
}
#pragma inline
void patch_input(const INPUTDIA_DESC* inp)
{
  ((INPUTDIA_DESC*)inp)->rc.x=0;
  ((INPUTDIA_DESC*)inp)->rc.y=HeaderH()+1+YDISP;
  ((INPUTDIA_DESC*)inp)->rc.x2=ScreenW()-1;
  ((INPUTDIA_DESC*)inp)->rc.y2=ScreenH()-SoftkeyH()-1;
}

#else
#pragma inline
void patch_header(const HEADER_DESC* head)
{
  ((HEADER_DESC*)head)->rc.x=0;
   if (IF_ELKA) ((HEADER_DESC*)head)->rc.y=ICONB; else ((HEADER_DESC*)head)->rc.y=0;
  ((HEADER_DESC*)head)->rc.x2=SCRW-1;
  if (IF_ELKA) ((HEADER_DESC*)head)->rc.y2=HEADH + ICONB -1; else ((HEADER_DESC*)head)->rc.y2=HEADH-1;
}

#pragma inline
void patch_input(const INPUTDIA_DESC* inp)
{
  ((INPUTDIA_DESC*)inp)->rc.x=0;
  if (IF_ELKA) ((INPUTDIA_DESC*)inp)->rc.y=HEADH+1+ICONB; else ((INPUTDIA_DESC*)inp)->rc.y=HEADH+1;
  ((INPUTDIA_DESC*)inp)->rc.x2=SCRH-1;
  ((INPUTDIA_DESC*)inp)->rc.y2=SCRH-SOFTH-1;
}
#endif


SOFTKEY_DESC menu_sk[]=
{
  {0x0018,0x0000,(int)"Left"},
  {0x0001,0x0000,(int)"Right"},
  {0x003D,0x0000,(int)"+"}
};

SOFTKEYSTAB menu_skt=
{
  menu_sk,0
};





void converter(GUI *data)
{
    char sdmname_pat[32], sdkpath_pat[32], smfpath_pat[32], sdk_num[8], smf_num[8], sdmname_num[8];
    int sdknum_adj, smfnum_adj, sdmnamenum_adj;
    EDITCONTROL ec1, ec2, ec3, ec4, ec5, ec6;
    
    ExtractEditControl(data,2,  &ec1);
    ExtractEditControl(data,4,  &ec2);
    ExtractEditControl(data,6,  &ec3);
    ExtractEditControl(data,8,  &ec4);
    ExtractEditControl(data,10, &ec5);
    ExtractEditControl(data,12, &ec6);
    
    ws2ascii(sdkpath_pat, ec1.pWS);
    ws2ascii(sdk_num,     ec2.pWS);
    ws2ascii(smfpath_pat, ec3.pWS);
    ws2ascii(smf_num,     ec4.pWS);
    ws2ascii(sdmname_pat, ec5.pWS);
    ws2ascii(sdmname_num, ec6.pWS);
    
    sdknum_adj     = str2int(sdk_num);
    smfnum_adj     = str2int(smf_num);
    sdmnamenum_adj = str2int(sdmname_num);
       
    
    for (unsigned int i = 0;i<=0xFFFFFFFF;i++)
     {
      char path[256];
      sprintf(path,sdkpath_pat,sdkfolder_in,i+sdknum_adj);
      sdm = CreateSUDOKUMAPbySDKFILE(path);
      sdm->warn = 0x00;
      if (sdm->error == 0x01) goto END_FOR; 
      sprintf(sdm->name,sdmname_pat,i+sdmnamenum_adj);
      sprintf(path,smfpath_pat,smffolder_out,i+smfnum_adj);
      CreateEXTFILEV20bySUDOKUMAP(sdm, path, 1);
      zeromem(sdm,sizeof(SUDOKUMAP));
      MemFreeOfSUDOKUMAP(sdm);
      ERROR = 0;
     }
END_FOR:

     if (sdm) zeromem(sdm,sizeof(SUDOKUMAP));
     MemFreeOfSUDOKUMAP(sdm);
  
}


void ed1_locret(void){}



void ed1_ghook(GUI *data, int cmd)
{
  static SOFTKEY_DESC options={0x0ABC,0x0000,(int)LG_CONVW_RSTEXT};

  if (cmd==TI_CMD_CREATE) 
   {
     DisableIDLETMR();
     if (FMSG) ShowMSG(1,(int)"sdk_input\\\nsmf_output\\");
   }
  if (cmd==TI_CMD_FOCUS)  DisableIDLETMR(); 
  if (cmd==TI_CMD_REDRAW) SetSoftKey(data,&options,!SET_SOFT_KEY_N); 
}




int KEY_CONTROL_SM(GUI *data,char KEYSMSG,int KEYMSG, short keys)
{
  if (KEYMSG == KEY_DOWN)
   {
    if (keys == 0x0ABC)
     {
       converter(data);
       FreeWS(ews);
       if (ERROR == 0) ShowMSG(1,(int)LG_CONVW_ENDMSG1);
                  else ShowMSG(1,(int)LG_CONVW_ENDMSG2);
       return KEY_CONTROL(0,0);
     }
    
    if (KEYSMSG == RED_BUTTON)
     {
      FreeWS(ews);
      ShowMSG(1,(int)"(c)"ELF_AUTHOR"\n"LG_CONVW_HEADTEXT);
      return KEY_CONTROL(0,0);
     }
    
   }

 return 0;
}



int ed1_onkey(GUI *data, GUI_MSG *msg)
{
#ifdef MULTISGOLD
  if (IF_NSG || IF_ELKA) return KEY_CONTROL_SM(data,msg->gbsmsg->submess, msg->gbsmsg->msg, msg->keys);
                         return KEY_CONTROL_SM(data,((GBS_MSG_SG*)msg->gbsmsg)->submess, ((GBS_MSG_SG*)msg->gbsmsg)->msg, msg->keys);
#else
  return KEY_CONTROL_SM(data,msg->gbsmsg->submess, msg->gbsmsg->msg, msg->keys);
#endif
  
}



HEADER_DESC ed1_hdr={0,0,0,0,NULL,(int)LG_CONVW_HEADTEXT,LGP_NULL};

INPUTDIA_DESC ed1_desc=
{
  1,
  ed1_onkey,
  ed1_ghook,
  (void *)ed1_locret,
  0,
  &menu_skt,
  {0,0,0,0},
  4,
  100,
  101,
  0,

//  0x00000001 - ��������� �� ������� ����
//  0x00000002 - ��������� �� ������
//  0x00000004 - �������� ���������
//  0x00000008 - UnderLine
//  0x00000020 - �� ���������� �����
//  0x00000200 - bold
  0,

//  0x00000002 - ReadOnly
//  0x00000004 - �� ��������� ������
//  0x40000000 - �������� ������� ����-������
  0
};




int CreateEditControls(void)
{
  void *ma=malloc_adr();
  void *eq;
  EDITCONTROL ec;

  PrepareEditControl(&ec);
  eq=AllocEQueue(ma,mfree_adr());
  
  wsprintf(ews,pt,LG_CONVW_SDKPATHPATTERN);
  ConstructEditControl(&ec,1,0x40,ews,32);
  AddEditControlToEditQend(eq,&ec,ma);

  wsprintf(ews,pt,"%sfile_%04d.sdk");
  ConstructEditControl(&ec,3,0x40,ews,32);
  AddEditControlToEditQend(eq,&ec,ma);
  
  wsprintf(ews,pt,LG_CONVW_SDKNUMADJUST);
  ConstructEditControl(&ec,1,0x40,ews,32);
  AddEditControlToEditQend(eq,&ec,ma);
  
  wsprintf(ews,pt,"0");
  ConstructEditControl(&ec,ECT_NORMAL_NUM,0x40,ews,8);
  AddEditControlToEditQend(eq,&ec,ma);
  
  wsprintf(ews,pt,LG_CONVW_SMFPATHPATTERN);
  ConstructEditControl(&ec,1,0x40,ews,32);
  AddEditControlToEditQend(eq,&ec,ma);

  wsprintf(ews,pt,"%ssudoku_%04d.smf");
  ConstructEditControl(&ec,3,0x40,ews,32);
  AddEditControlToEditQend(eq,&ec,ma);
  
  wsprintf(ews,pt,LG_CONVW_SMFNUMADJUST);
  ConstructEditControl(&ec,1,0x40,ews,32);
  AddEditControlToEditQend(eq,&ec,ma);
  
  wsprintf(ews,pt,"0");
  ConstructEditControl(&ec,ECT_NORMAL_NUM,0x40,ews,8);
  AddEditControlToEditQend(eq,&ec,ma);

  wsprintf(ews,pt,LG_CONVW_SDNPATHPATTERN);
  ConstructEditControl(&ec,1,0x40,ews,32);
  AddEditControlToEditQend(eq,&ec,ma);

  wsprintf(ews,pt,"������ #%04d");
  ConstructEditControl(&ec,3,0x40,ews,32);
  AddEditControlToEditQend(eq,&ec,ma);
  
  wsprintf(ews,pt,LG_CONVW_SDNNUMADJUST);
  ConstructEditControl(&ec,1,0x40,ews,32);
  AddEditControlToEditQend(eq,&ec,ma);
  
  wsprintf(ews,pt,"0");
  ConstructEditControl(&ec,ECT_NORMAL_NUM,0x40,ews,8);
  AddEditControlToEditQend(eq,&ec,ma);
  


  patch_header(&ed1_hdr);
  patch_input(&ed1_desc);
  return CreateInputTextDialog(&ed1_desc,&ed1_hdr,eq,1,0);
}



void CreateConverterWindow()
{
  ews=AllocWS(256);
  CreateEditControls();
}


