//addfunc.h - ���������� �������������� �-��

//����� RGBA {������� (0-255), ������ (0-255), ����� (0-255), �����-����������� (0-100)}

//��������
char white[4]={255,255,255,100}; // = ����� 
char red[4]={255,0,0,100};       // = �������
char green[4]={0,255,0,100};     // = ������
char blue[4]={0,0,255,100};      // = �����
char yellow[4]={255,255,0,100};  // = Ƹ����
char black[4]={0,0,0,100};       // = ׸����
char alpha[4]={0,0,0,0};         // = ��������� ����������
//��������������
char logo_color[4]={0xFF,0xFB,0xFF,0x64};   // = ����� � ��������� �������� �������� 
char logo_loadbar[4]={0xFC,0xCA,0x03,0x64}; // = Ƹ��������
char white_85[4]={255,255,255,85};          // = �����  85%
char black_40[4]={0,0,0,40};                // = ׸���� 40%
char red_50[4]={255,0,0,50};                // = ������� 50%

char msg_error[4]={250,0,0,70};             // = ������� - ������!
char msg_info[4]={0,250,0,70};              // = ������ - ����!


#ifdef DEBUG
void debuglog(char *string)
{
  TDate date; TTime time; 
  
  char *t=malloc(512);
  sprintf(t,"%sdebug.log",elffolder);
  int logfile=fopen(t,A_ReadWrite+A_TXT+A_Append+A_Create,P_READ+P_WRITE,0);
  mfree(t);
  
  char *data=malloc(4096);
  GetDateTime(&date,&time);
  sprintf(data,">%d:%02d:%02d/%02d-%02d-%04d< = %s\r\n",time.hour,time.min,time.sec,date.day, date.month,date.year,string);
  lseek(logfile, 0x0, S_END, 0, 0);
  fwrite(logfile,data,strlen(data),0);
  mfree(data);
  fclose(logfile,0);
}
#else

void debuglog(char *string){}

#endif



void FULLREDRAW()
{
 TYPEREDRAW = 0;
 REDRAW_CONTROL();
}

void SMARTREDRAW()
{
 TYPEREDRAW = 1;
 REDRAW_CONTROL();
 TYPEREDRAW = 0;
}

//������� �-��, �� � � ��� �� ���� ...
int isSGoldX75() //0 - SGold x65, 1 - SGold x75, 2 - NewSGold, 3 - E/EL71
{
  char res = 0;
  char sgold_x75[6][8]={"C72","ME75","C75","CF75","M75","CX75"};

  for (char i = 0;i<6;i++) if (strstr(sgold_x75[i],Get_Phone_Info(PI_MODEL))!=0) res = 1;
  
  if (isnewSGold() == 1) res = 2;
  if (isnewSGold() == 2) res = 3;
  
  return res;
}


void fileext(char *path,char *filebody, int size) //��������� ���� �� ����a
{
 int file;
 unlink(path,0);
 file = fopen(path,A_WriteOnly+A_Create,P_WRITE,0);
 fwrite(file,filebody,size,0);
 fclose(file, 0);
}



int char16to8(int c)
{
  if (c<0x400) return (c);
  c-=0x400;
  if (c<16)
  {
    if (c==1) c=0;
    else if (c==4) c=2;
    else if (c==6) c=10;
    else return (c);
  }
  else if (c>79)
  {
    if (c==0x51) c=16;
    else if (c==0x54) c=18;
    else if (c==0x56) c=11;
    else if (c==0x57) c=23;
    else return (c);
  }
  else c+=8;
  c+=168;
  return (c);
}


int char8to16(int c)
{
  if (c<168) return (c);
  c-=168;
  if (!c)  c=1;
  else if (c<24)
  {
    if (c==2) c=4;
    else if (c==10) c=6;
    else if (c==11) c=0x56;
    else if (c==16) c=0x51;
    else if (c==18) c=0x54;
    else if (c==23) c=0x57;
    else return (c);
  }
  else if (c>87) return (c);
    else c-=8;
  c+=0x400;
  return (c);
}

int ws2ascii(char *buf, WSHDR *ws)
{
  unsigned int sWs=ws->wsbody[0];
  int p=0;
  unsigned int cWs;
  while(p<sWs)
  {
    cWs=ws->wsbody[p+1];
    buf[p]=char16to8(cWs);
    p++;
  }
  buf[p] = 0;
  return p;
}


void ascii2ws(WSHDR *ws, const char *s)
{
  char c;
  CutWSTR(ws,0);
  while((c=*s++))
  {
    wsAppendChar(ws,char8to16(c));
  }
}

#ifndef MULTISGOLD
void DrwImg(IMGHDR *img, int x, int y, char *pen, char *brush) //��������� IMGHDR
{
  RECT rc;
  DRWOBJ drwobj;
  StoreXYWHtoRECT(&rc,x,y,img->w,img->h);
  SetPropTo_Obj5(&drwobj,&rc,0,img);
  SetColor(&drwobj,pen,brush);
  DrawObject(&drwobj);
}
#endif

IMGHDR *CreateIMGHDRbyLastScreen(short x, short y, short w, short h, short maxw, short maxh) //�������� IMGHDR �� ��������� ��� ��� ���������
{
  // x    - ���������� ������ x
  // y    - ���������� ������ y
  // w    - ������ ��������� ������ �� X
  // h    - ������ ��������� ������ �� Y
  // maxw - ������ ������
  // maxh - ������ ������
  
  IMGHDR *img = 0;
  if ((x+w)<=maxw && (y+h)<=maxh)
   { 
    img = malloc(sizeof(IMGHDR));
    img->w     = w;
    img->h     = h;
    img->bpnum = 0x08;
    img->bitmap = malloc(h*w*2);
    char *scrbuf = RamScreenBuffer();
    for (int i=0;i<h;i++) memcpy(img->bitmap+w*i*2, scrbuf+x*2+(y+i)*maxw*2, w*2);
   }
  
   return img;
}


IMGHDR *CreateIMGHDRbyfragmentIMGHDR(IMGHDR *img, short x, short y, short w, short h) //�������� IMGHDR �� ��������� IMGHDR
{
  IMGHDR *imgf = 0;
  if ((x+w)<=img->w && (y+h)<=img->h)
   { 
    imgf = malloc(sizeof(IMGHDR));
    int bn;
    if (img->bpnum == 0x05) bn = 1;
    if (img->bpnum == 0x08) bn = 2;
    if (img->bpnum == 0x0A) bn = 4;
    
    imgf->w = w;
    imgf->h = h;
    imgf->bpnum = img->bpnum;
    imgf->bitmap = malloc(h*w*bn);
    for (int i=0;i<h;i++) memcpy(imgf->bitmap+w*i*bn, img->bitmap+x*bn+(y+i)*img->w*bn, w*bn);
   }
  
   return imgf;
}

void MemFreeOfIMGHDR(IMGHDR *img) // ������� ������ �� IMGHDR
{
 if (img)
  {
    if (img->bpnum == 0x01) zeromem(img->bitmap,img->w*img->h*1/8);
    if (img->bpnum == 0x05) zeromem(img->bitmap,img->w*img->h*1);
    if (img->bpnum == 0x08) zeromem(img->bitmap,img->w*img->h*2);
    if (img->bpnum == 0x0A) zeromem(img->bitmap,img->w*img->h*4);
    mfree(img->bitmap);
    zeromem(img,sizeof(IMGHDR));
    mfree(img);
    img = 0;
  }
}

void DrawStringV2(char *text,int x1,int y1,int x2,int y2,int font,int text_attribute,const char *Pen,const char *Brush)
{
  WSHDR *text_ws = AllocWS(strlen(text) + 5);  
  ascii2ws(text_ws, text);
  DrawString(text_ws,x1,y1,x2,y2,font,text_attribute,Pen,Brush);
  FreeWS(text_ws); 
}

void DrawStringV3(char *text,int x1,int y1,int x2,int y2,int xdisp,int font,int text_attribute,const char *Pen,const char *Brush)
{
  WSHDR *text_ws = AllocWS(strlen(text) + 5);  
  ascii2ws(text_ws, text);
  DrawScrollString(text_ws,x1,y1,x2,y2, xdisp,font,text_attribute,Pen,Brush);
  FreeWS(text_ws); 
}

#define MSGERROR 0
#define MSGINFO  1

void ShowMessage(char *text, int font, int type) //��, ���  ����� ��������� � ���� �������������, ������ 2-� �����
{
 char txt[128];
 if (type == 0)
  {
    sprintf(txt,"%s\n%s",LG_MSG_ERROR,text);
    DrawRectangle(5,5, SCRW - 6, SCRH - 6, 0, black, msg_error);
  }
 if (type == 1) 
  {
    sprintf(txt,"%s\n%s",LG_MSG_INFO,text);
    DrawRectangle(5,5, SCRW - 6, SCRH - 6, 0, black, msg_info);
  }
 
 DrawStringV2(txt,7,7, SCRW - 8, SCRH - 8, font, 0, black, alpha);
 MESSAGEWINDOW = 1;
 FULLREDRAW();
}



void OpenFile(char *path, void *p)
{
     WSHDR *path_ws = AllocWS(256);
     wsprintf(path_ws, path);
     ExecuteFile(path_ws,0,p);
     FreeWS(path_ws);
}

void DrawSoftHeader(char *skl,char *skr,char *head,int font, int hfont, const char *soft_col, const char *head_col, const char *soft_colg, const char *head_colg, int redraw) //������ ����� � ���������
{  
   char t[3]="%t";
   int w1,w2,wh,hf,hh;
  
   WSHDR *skl_ws=AllocWS(32);
   WSHDR *skr_ws=AllocWS(32);
   WSHDR *head_ws=AllocWS(32);
   
   wsprintf(skl_ws,t,skl);
   wsprintf(skr_ws,t,skr);
   wsprintf(head_ws,t,head);
  
   w1 = Get_WS_width(skl_ws, font);
   w2 = Get_WS_width(skr_ws, font);
   wh = Get_WS_width(head_ws, hfont);
   hf = GetFontYSIZE(font);
   hh = GetFontYSIZE(hfont);
   
   if (head>0 && head_colg > 0)             //Header
    {
     if (redraw == 0)
      {
       for (int i=0; i<(hh+2); i++)                                
        {                                                            
         int a=100 - (i*100)/(hh+2);
         char colh[4]={head_colg[0],head_colg[1],head_colg[2],a};
         DrawRectangle(0,i,SCRW-1,i,0,colh,0);
        }
      }
     if (redraw == 1) DrawRectangle(0,0,SCRW-1,hh+2,0,0,head_colg);
    } 
 
   if (skl>0 && soft_colg > 0)
    {
    if (redraw == 0)
     {
      for (int i=0; i<(4*SCRW/10); i++)      //Left                          
      {                                                            
       int a=100-(i*100)/(4*SCRW/10);
       char col1[4]={soft_colg[0],soft_colg[1],soft_colg[2],a};
       DrawRectangle(i,SCRH-hf-2,i, SCRH - 2,0,col1,0);
      }
     }
    if (redraw == 1) DrawRectangle(0,SCRH-hf-2,SCRW-1, SCRH - 2,0,0,soft_colg);
    }
      
   if (skr>0 && soft_colg > 0)
    {
      if (redraw == 0)
       {
        for (int i=0; i<=(4*SCRW/10); i++)      //Right                      
        {                                                            
         int a=(i*100)/(4*SCRW/10);
         char col2[4]={soft_colg[0],soft_colg[1],soft_colg[2],a};
         DrawRectangle(i + (6*SCRW)/10,SCRH-hf-2,i + (6*SCRW)/10, SCRH - 2,0,col2,0);
        }
       }
      if (redraw == 1 && skl == 0) DrawRectangle(0,SCRH-hf-2,SCRW-1, SCRH - 2,0,0,soft_colg);
    }
    
     if (skl>0)   DrawString(skl_ws, 2, SCRH - hf - 1, w1+5, SCRH - 2, font,0,soft_col,0);
     if (skr>0)   DrawString(skr_ws, SCRW - w2 - 2, SCRH - hf - 1,SCRW, SCRH - 2, font,0,soft_col,0);
     if (head>0)  DrawString(head_ws, 0, 0, 2 + wh, 2 + hh, hfont,0,head_col,0);
    
    FreeWS(skl_ws);
    FreeWS(skr_ws);
    FreeWS(head_ws);
}

void DrawRightSoft(char *str, int font, const char *soft_col, const char *soft_colg, int redraw)  //������ ������ ������������� �����
{
   int w,h;
   char t[3]="%t";
  
   WSHDR *str_ws=AllocWS(32);  
   wsprintf(str_ws,t,str);

   w = Get_WS_width(str_ws, font);
   h = GetFontYSIZE(font);
   if (redraw == 0)
    {
     for (int i=0; i<=(6*SCRW/10); i++)                  
      {                                                            
       int a=(i*100)/(6*SCRW/10);
       char col[4]={soft_colg[0],soft_colg[1],soft_colg[2],a};
       DrawRectangle(i + (4*SCRW)/10,SCRH-h-2,i + (4*SCRW)/10, SCRH - 2,0,0,col);
      }
    }
   if (redraw == 1) DrawRectangle(0,SCRH-h-2,SCRW-1, SCRH - 2,0,0,soft_colg);
   DrawString(str_ws, SCRW - w - 2, SCRH - h - 1, SCRW, SCRH - 2, font,0,soft_col,0);
   FreeWS(str_ws);
}

char *timeBySeconds(char *str, int sec)
{
 int h,m,s;
 h = sec/3600;
 m = (sec - h*3600)/60;
 s = sec - h*3600 - m*60;
 sprintf(str,"%02d:%02d:%02d",h,m,s);
 return str;
}

char ProtectOfCopy(char *exename) //0x01 - ���������,  0x00 - �� ������ ��������
{
 char imei[15];
 char imei2[25];
 char freespace[25]="This may be your market!";
 
 int addr, lock1 = 0, lock2 = 0;
 memcpy(imei,  (char*)0xA000065C, 15);
 
 imei2[0]  = imei[12] - 0x20;
 imei2[1]  = imei[13] - 0x20;
 imei2[2]  = imei[14] - 0x20;
 
 imei2[3]  = imei[8]  - 0x20;
 imei2[4]  = imei[9]  - 0x20;
 imei2[5]  = imei[10] - 0x20;
 imei2[6]  = imei[11] - 0x20;
 
 imei2[7]  = imei[4]  - 0x20;
 imei2[8]  = imei[5]  - 0x20;
 imei2[9]  = imei[6]  - 0x20;
 imei2[10] = imei[7]  - 0x20;
 
 imei2[11] = imei[0]  - 0x20;
 imei2[12] = imei[1]  - 0x20;
 imei2[13] = imei[2]  - 0x20;
 imei2[14] = imei[3]  - 0x20;
 
 FSTATS stat;
 GetFileStats(exename, &stat, 0);
 char *elfcopy = malloc(stat.size);
 
 int elf = fopen(exename,A_ReadWrite+A_BIN,P_WRITE,0);
 fread(elf, elfcopy, stat.size,0);

 if (freespace[0]=='T')
  {
    for (int i=0;i<stat.size; i++) if(memcmp(elfcopy+i,freespace,25)==0)
     {
      addr  = i;
      lock1 = 1;
     }
  }
 
 if (lock1 == 1)
 { 
  lseek(elf, addr, S_SET, 0, 0);
  fwrite(elf, imei2, 25, 0);
  addr = 0x01;
  goto END_SF; 
 }
 
 for (int i=0;i<stat.size; i++) if(memcmp(elfcopy+i,imei2,15)==0) lock2 = 1;
 
 if (lock2 == 1)
 { 
  addr = 0x01;
  goto END_SF;
 }
 
 //3564 2700 3704 348 => 348 3704 2700 3564 - 0x20
 
  addr = 0x00;
   
END_SF:
  mfree(elfcopy);
  fclose(elf, 0);
  return addr;
}


