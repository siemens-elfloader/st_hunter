
int char16to8(int c)
{
  if (c<0x400) return (c);
  c-=0x400;
  if (c<16)
  {
    if (c==1) c=0;
    else if (c==4) c=2;
    else if (c==6) c=10;
    else return (c);
  }
  else if (c>79)
  {
    if (c==0x51) c=16;
    else if (c==0x54) c=18;
    else if (c==0x56) c=11;
    else if (c==0x57) c=23;
    else return (c);
  }
  else c+=8;
  c+=168;
  return (c);
}


int char8to16(int c)
{
  if (c<168) return (c);
  c-=168;
  if (!c)  c=1;
  else if (c<24)
  {
    if (c==2) c=4;
    else if (c==10) c=6;
    else if (c==11) c=0x56;
    else if (c==16) c=0x51;
    else if (c==18) c=0x54;
    else if (c==23) c=0x57;
    else return (c);
  }
  else if (c>87) return (c);
    else c-=8;
  c+=0x400;
  return (c);
}

int ws2ascii(char *buf, WSHDR *ws)
{
  unsigned int sWs=ws->wsbody[0];
  int p=0;
  unsigned int cWs;
  while(p<sWs)
  {
    cWs=ws->wsbody[p+1];
    buf[p]=char16to8(cWs);
    p++;
  }
  buf[p] = 0;
  return p;
}


void ascii2ws(WSHDR *ws, const char *s)
{
  char c;
  CutWSTR(ws,0);
  while((c=*s++))
  {
    wsAppendChar(ws,char8to16(c));
  }
}

int str2int(const char *str)
{
  int i;
  sscanf(str,"%08d",&i);
  return i;

}


char ElfFolderOperations(char *elfpath)
{
 char res = 0;
   
 //��������� ����� ���������
 int elfn = strlen(elfpath)-strlen((strrchr(elfpath,(int)'\\')+1));
 for (int i=0;i<=256;i++) elffolder[i]=elfpath[i];
 elffolder[elfn]='\0';
 
 sprintf(sdkfolder_in, "%s%s",elffolder,"sdk_input\\");
 sprintf(smffolder_out,"%s%s",elffolder,"smf_output\\");
 
 //�������� ��� �������� ���������
 if (isdir(sdkfolder_in, 0) !=1) {mkdir(sdkfolder_in, 0);  res = 1;}
 if (isdir(smffolder_out, 0)!=1) {mkdir(smffolder_out, 0); res = 1;}
 
 return res;

}

char ProtectOfCopy(char *exename) //0x01 - ���������,  0x00 - �� ������ ��������
{
 char imei[15];
 char imei2[25];
 char freespace[25]="This may be your market!";
 
 int addr, lock1 = 0, lock2 = 0;
 memcpy(imei,  (char*)0xA000065C, 15);
 
 imei2[0]  = imei[12] - 0x20;
 imei2[1]  = imei[13] - 0x20;
 imei2[2]  = imei[14] - 0x20;
 
 imei2[3]  = imei[8]  - 0x20;
 imei2[4]  = imei[9]  - 0x20;
 imei2[5]  = imei[10] - 0x20;
 imei2[6]  = imei[11] - 0x20;
 
 imei2[7]  = imei[4]  - 0x20;
 imei2[8]  = imei[5]  - 0x20;
 imei2[9]  = imei[6]  - 0x20;
 imei2[10] = imei[7]  - 0x20;
 
 imei2[11] = imei[0]  - 0x20;
 imei2[12] = imei[1]  - 0x20;
 imei2[13] = imei[2]  - 0x20;
 imei2[14] = imei[3]  - 0x20;
 
 FSTATS stat;
 GetFileStats(exename, &stat, 0);
 char *elfcopy = malloc(stat.size);
 
 int elf = fopen(exename,A_ReadWrite+A_BIN,P_WRITE,0);
 fread(elf, elfcopy, stat.size,0);

 if (freespace[0]=='T')
  {
    for (int i=0;i<stat.size; i++) if(memcmp(elfcopy+i,freespace,25)==0)
     {
      addr  = i;
      lock1 = 1;
     }
  }
 
 if (lock1 == 1)
 { 
  lseek(elf, addr, S_SET, 0, 0);
  fwrite(elf, imei2, 25, 0);
  addr = 0x01;
  goto END_SF; 
 }
 
 for (int i=0;i<stat.size; i++) if(memcmp(elfcopy+i,imei2,15)==0) lock2 = 1;
 
 if (lock2 == 1)
 { 
  addr = 0x01;
  goto END_SF;
 }
 
 //3564 2700 3704 348 => 348 3704 2700 3564 - 0x20
 
  addr = 0x00;
   
END_SF:
  mfree(elfcopy);
  fclose(elf, 0);
  return addr;
}
