typedef struct
{
	void *ChanBannerQ; // {*next, *proc}
}SFN_DATA;
