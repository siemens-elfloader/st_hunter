#ifndef _SIEGET_IPC_H_
#define _SIEGET_IPC_H_

#define SIEGET_IPC_NAME "SieGetD"

#define SIEGET_GOTO_URL 0

#endif
