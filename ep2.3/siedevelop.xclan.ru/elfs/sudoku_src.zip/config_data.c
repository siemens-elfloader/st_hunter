#include "engine\inc\cfg_items.h"
#include "engine\system\lang.h"

//������������

__root const CFG_HDR cfghdr_01_begin={CFG_LEVEL,LG_BCFG_GENERAL,1,0};

__root const CFG_HDR cfghdr1_01 = {CFG_CBOX, LG_BCFG_GENERAL_INTERFACE, 0, 2};
__root const int bcfg_redraw = 0;
__root const CFG_CBOX_ITEM cfgcbox1_01[2] = {LG_BCFG_GENERAL_IF_GRAD,LG_BCFG_GENERAL_IF_RECT};

__root const CFG_HDR cfghdr1_02 = {CFG_UINT, LG_BCFG_GENERAL_TEXTFONT, 0, 23};
__root const unsigned int bcfg_std_font = 7;

__root const CFG_HDR cfghdr1_03={CFG_COLOR,LG_BCFG_GENERAL_TEXTCOLOR,0,0};
__root const char bcfg_std_colp[4]={255,0,0,100};

__root const CFG_HDR cfghdr1_04={CFG_COLOR,LG_BCFG_GENERAL_UNDERCOLOR,0,0};
__root const char bcfg_std_colb[4]={0,0,0,100};

__root const CFG_HDR cfghdr1_05 = {CFG_UINT, LG_BCFG_GENERAL_MSGFONT, 0, 23};
__root const unsigned int bcfg_msg_font = 7;

__root const CFG_HDR cfghdr1_06 = {CFG_UINT, LG_BCFG_GENERAL_HELPFONT, 0, 23};
__root const unsigned int bcfg_hmenu_font = 7;

__root const CFG_HDR cfghdr1_07={CFG_COLOR,LG_BCFG_GENERAL_HELPCOLOR,0,0};
__root const char bcfg_hmenu_col[4]={0,0,0,100};

__root const CFG_HDR cfghdr1_08 = {CFG_UINT, LG_BCFG_GENERAL_HELPSCROLLBUF, 0, 1000};
__root const unsigned int bcfg_hmenu_bs = 50;

__root const CFG_HDR cfghdr1_09 = {CFG_CBOX, LG_BCFG_GENERAL_SECONDCOUNT, 0, 2};
__root const int bcfg_alttimer = 0;
__root const CFG_CBOX_ITEM cfgcbox1_08[2] = {LG_BCFG_GENERAL_SC_ALWAYS,LG_BCFG_GENERAL_SC_GAMEW};

__root const CFG_HDR cfghdr1_10 = {CFG_CBOX, LG_BCFG_GENERAL_USEALPHA, 0, 2};
__root const int bcfg_usealpha = 0;
__root const CFG_CBOX_ITEM cfgcbox1_09[2] = {LG_BCFG_GENERAL_UA_NO, LG_BCFG_GENERAL_UA_YES};

__root const CFG_HDR cfghdr_01_end={CFG_LEVEL,"",0,0};




__root const CFG_HDR cfghdr_02_begin={CFG_LEVEL,LG_BCFG_MAINMENU,1,0};

__root const CFG_HDR cfghdr2_01 = {CFG_UINT, LG_BCFG_MAINMENU_TEXTFONT, 0, 23};
__root const unsigned int bcfg_mmenu_font = 7;

__root const CFG_HDR cfghdr2_02={CFG_COLOR,LG_BCFG_MAINMENU_TEXTCOLOR,0,0};
__root const char bcfg_mmenu_col[4]={0,0,255,100};

__root const CFG_HDR cfghdr2_03={CFG_COLOR,LG_BCFG_MAINMENU_BGCOLOR_U,0,0};
__root const char bcfg_mmenu_bgcol_u[4]={0,0,0,70};

__root const CFG_HDR cfghdr2_04={CFG_COLOR,LG_BCFG_MAINMENU_BGCOLOR_M,0,0};
__root const char bcfg_mmenu_bgcol_m[4]={255,0,0,70};

__root const CFG_HDR cfghdr_02_end={CFG_LEVEL,"",0,0};




__root const CFG_HDR cfghdr_03_begin={CFG_LEVEL,LG_BCFG_HEADERSOFTS,1,0};

__root const CFG_HDR cfghdr3_01 = {CFG_UINT, LG_BCFG_HS_HEADERFONT, 0, 23};
__root const unsigned int bcfg_sh_headfont = 8;

__root const CFG_HDR cfghdr3_02={CFG_COLOR,LG_BCFG_HS_HEADERCOLOR,0,0};
__root const char bcfg_sh_headcolt[4]={0,0,255,100};

__root const CFG_HDR cfghdr3_03={CFG_COLOR,LG_BCFG_HS_HEADERBGCOLOR,0,0};
__root const char bcfg_sh_headcolg[4]={0,0,0,70};

__root const CFG_HDR cfghdr3_04 = {CFG_UINT, LG_BCFG_HS_SOFTSFONT, 0, 23};
__root const unsigned int bcfg_sh_softfont = 7;

__root const CFG_HDR cfghdr3_05={CFG_COLOR,LG_BCFG_HS_SOFTSCOLOR,0,0};
__root const char bcfg_sh_softcolt[4]={255,0,0,100};

__root const CFG_HDR cfghdr3_06={CFG_COLOR,LG_BCFG_HS_SOFTSBGCOLOR,0,0};
__root const char bcfg_sh_softcolg[4]={0,0,0,70};

__root const CFG_HDR cfghdr_03_end={CFG_LEVEL,"",0,0};



__root const CFG_HDR cfghdr_04_begin={CFG_LEVEL,LG_BCFG_GAMEW,1,0};

__root const CFG_HDR cfghdr4_01 = {CFG_UINT, LG_BCFG_GAMEW_HEADFONT, 0, 23};
__root const unsigned int bcfg_gamew_hfont = 7;

__root const CFG_HDR cfghdr4_02={CFG_COLOR,LG_BCFG_GAMEW_HEADNAMECOL,0,0};
__root const char bcfg_gamew_hn[4]={0,0,255,100};

__root const CFG_HDR cfghdr4_03={CFG_COLOR,LG_BCFG_GAMEW_HEADTIMECOL,0,0};
__root const char bcfg_gamew_ht[4]={0,255,0,100};

__root const CFG_HDR cfghdr4_04 = {CFG_CBOX, LG_BCFG_GAMEW_CHANGEPOS, 0, 2};
__root const int bcfg_gamew_pos = 0;
__root const CFG_CBOX_ITEM cfgcbox4_04[2] = {LG_BCFG_GAMEW_CP_AUTO,LG_BCFG_GAMEW_CP_MANUAL};

__root const CFG_HDR cfghdr4_05={CFG_COORDINATES,LG_BCFG_GAMEW_FIELDPOS,0,0};
__root const unsigned int bcfg_gamew_posX = 5;
__root const unsigned int bcfg_gamew_posY = 30;

__root const CFG_HDR cfghdr4_06={CFG_COLOR,LG_BCFG_GAMEW_FC_GRIDCOL,0,0};
__root const char bcfg_gamew_grid_col[4]={150,0,0,100};

__root const CFG_HDR cfghdr4_07={CFG_COLOR,LG_BCFG_GAMEW_FC_CONTCOL,0,0};
__root const char bcfg_gamew_kont_col[4]={0,0,0,100};

__root const CFG_HDR cfghdr4_08={CFG_COLOR,LG_BCFG_GAMEW_CUR_CONTCOL,0,0};
__root const char bcfg_gamew_cur_col[4]={0,150,0,100};

__root const CFG_HDR cfghdr4_09={CFG_COLOR,LG_BCFG_GAMEW_CUR_BGCOL,0,0};
__root const char bcfg_gamew_cur_bg[4]={0,0,0,30};

__root const CFG_HDR cfghdr4_10 = {CFG_UINT, LG_BCFG_GAMEW_GM_TEXTFONT, 0, 23};
__root const unsigned int bcfg_gmenu_font = 8;

__root const CFG_HDR cfghdr4_11={CFG_COLOR,LG_BCFG_GAMEW_GM_TEXTCOLOR,0,0};
__root const char bcfg_gmenu_col_t[4]={0,0,0,100};

__root const CFG_HDR cfghdr4_12={CFG_COLOR,LG_BCFG_GAMEW_GM_ELEM_U,0,0};
__root const char bcfg_gmenu_col_u[4]={0,150,0,70};

__root const CFG_HDR cfghdr4_13={CFG_COLOR,LG_BCFG_GAMEW_GM_ELEM_M,0,0};
__root const char bcfg_gmenu_col_m[4]={150,0,0,70};

__root const CFG_HDR cfghdr_04_end={CFG_LEVEL,"",0,0};



__root const CFG_HDR cfghdr_05_begin={CFG_LEVEL,LG_BCFG_KEYCONTROL,1,0};

__root const CFG_HDR cfghdr5_01 = {CFG_CBOX, LG_BCFG_KC_TYPE, 0, 2};
__root const int bcfg_key_control = 1;
__root const CFG_CBOX_ITEM cfgcbox4_01[2] = {LG_BCFG_KC_TYPE_FIRST,LG_BCFG_KC_TYPE_SECOND};

__root const CFG_HDR cfghdr5_02={CFG_CHECKBOX,LG_BCFG_KC_CENTERFIVE,0,0};
__root const int bcfg_key_five = 0;

__root const CFG_HDR cfghdr_05_end={CFG_LEVEL,"",0,0};



__root const CFG_HDR cfghdr_06_begin={CFG_LEVEL,LG_BCFG_EDITOR,1,0};

__root const CFG_HDR cfghdr6_01={CFG_COLOR,LG_BCFG_EDITOR_CUR_CONTCOL,0,0};
__root const char bcfg_editw_cur_col[4]={255,0,0,100};

__root const CFG_HDR cfghdr6_02={CFG_COLOR,LG_BCFG_EDITOR_CUR_BGCOL,0,0};
__root const char bcfg_editw_cur_bg[4]={0,0,0,40};

__root const CFG_HDR cfghdr6_03 = {CFG_UINT, LG_BCFG_EDITOR_EM_TEXTFONT, 0, 23};
__root const unsigned int bcfg_emenu_font = 7;

__root const CFG_HDR cfghdr6_04={CFG_COLOR,LG_BCFG_EDITOR_EM_TEXTCOLOR,0,0};
__root const char bcfg_emenu_col_t[4]={0,0,0,100};

__root const CFG_HDR cfghdr6_05={CFG_COLOR,LG_BCFG_EDITOR_EM_ELEM_U,0,0};
__root const char bcfg_emenu_col_u[4]={0,150,0,70};

__root const CFG_HDR cfghdr6_06={CFG_COLOR,LG_BCFG_EDITOR_EM_ELEM_M,0,0};
__root const char bcfg_emenu_col_m[4]={150,0,0,70};

__root const CFG_HDR cfghdr6_07={CFG_STR_WIN1251,LG_BCFG_EDITOR_SMFNAME,0,31};
__root const char bcfg_smfname[32]=ELF_NAME" "ELF_VERSION;

__root const CFG_HDR cfghdr6_08={CFG_CHECKBOX,LG_BCFG_EDITOR_CLOSESUDOKU,0,0};
__root const int bcfg_closeelf = 1;

__root const CFG_HDR cfghdr_06_end={CFG_LEVEL,"",0,0};
