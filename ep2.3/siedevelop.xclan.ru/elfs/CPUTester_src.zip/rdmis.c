#include "..\inc\swilib.h"
#include "math.h"


void CPUTesterUnLoad(void)
{
  extern void kill_data(void *p, void (*func_p)(void *));
  extern void *ELF_BEGIN;
  kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}

int main()
{
   if (isnewSGold() == 0)
   {
     LockSched(); 
     unsigned int steps_per_sec = 0, sec = 0, time = 0;
   
     extern unsigned int getSec1970();
     extern unsigned int RDMISCounter(unsigned int firsttime);


     time = getSec1970();
     sec = getSec1970();
   
     LockSched();
     while (time == sec) time = getSec1970();
     steps_per_sec = RDMISCounter(time);
     UnlockSched();
    
     double RDMIS = (3 + 2 + (4 + 9) * steps_per_sec)*0.000001;
     double MHZ = (RDMIS*RDMIS)*0.368972 + RDMIS*3.60212 + 0.708651; 
     // y = 0.368972*x^2 + 3.60212*x + 0.708651
     // MHz / RDMIS
   
     char answer[256];
     sprintf(answer, "%.03f RDMIS\n%.02f MHz", RDMIS, MHZ);
   
     ShowMSG(1, (int)answer);
     UnlockSched();
     
    } else ShowMSG(1, (int)"This ELF\nfor SGold!");
   
   SUBPROC((void *)CPUTesterUnLoad);
   
   return 0;
}


