#include "..\..\inc\cfg_items.h"

__root const CFG_HDR cfghdr00 = {CFG_STR_UTF8, "Daemons Folder", 3, 127};
__root const char bcfg_daemons[128] = "0:\\ZBin\\daemons\\";

__root const CFG_HDR cfghdr03_01={CFG_CHECKBOX,"Daemons Enable",0,0};
__root const int bcfg_daemons_ena = 1;

__root const CFG_HDR cfghdr01 = {CFG_STR_UTF8, "Image Folder", 3, 127};
__root const char bcfg_img[128] = "0:\\ZBin\\img\\";

__root const CFG_HDR cfghdr02={CFG_UINT,"ELF Icon",0,1200};
__root const unsigned int bcfg_elficon = 465;

__root const CFG_HDR cfghdr03={CFG_UINT,"Alpha-chan threshold",0,255};
__root const unsigned int ALPHA_THRESHOLD = 128;

__root const CFG_HDR cfghdr04={CFG_UINT,"PNG cache size", 20, 200};
__root const unsigned int CACHE_PNG = 50;

__root const CFG_HDR cfghdr05={CFG_CBOX,"Default bit-depth", 0, 3};
__root const unsigned int DEFAULT_COLOR = 1;
__root const CFG_CBOX_ITEM cfgcbox01[3]={"8 bits","16 bits","24 bits+alpha"};
