#ifndef __HELPER_H__
#define __HELPER_H__

#define HELPER_CEPID      0x4407
#define HELPER_NAME      "HELPER"
#define HELPER_PRIO       128
#define MSG_HELPER_RUN    0x0001

#define SWINUM_SUBPROC    0x171
#define SWINUM_REDRAW     0x172
#define SWINUM_SEQKILLER  0x19C

void __jel_helper_install();
void __jel_helper_deinstall();

#endif //__HELPER_H__
