#ifndef __SWIHOOK_H__
#define __SWIHOOK_H__

#define SWIHOOK_JUMPER_ADDRESS 0x00000134
#define SWIHOOK_LOCATE_ADDRESS 0x00000218
#define SWIHOOK_JUMPER_OPCODE  0xE59FF0DC

#define SWINUM_LIBTOP          0x1BA


#pragma swi_number=0x00
__swi __arm void system_mode();

extern void __jel_swihook_start();

void __jel_swihook_abort(unsigned short swinum, unsigned int swi_call_lr_address);
int __jel_swihook_install(unsigned int *swilib);

int __jel_swihook_setfunc(unsigned short swinum, unsigned int address);
unsigned int  __jel_swihook_getfunc(unsigned short swinum);
int __jel_swihook_clearfunc(unsigned short swinum);

#endif //__SWIHOOK_H__
