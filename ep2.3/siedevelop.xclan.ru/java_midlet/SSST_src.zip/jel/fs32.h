#ifndef __FS32_H__
#define __FS32_H__

#define SWINUM_READ  0x00B
#define SWINUM_WRITE 0x00C

void __jel_fs32_install();

#endif //__FS32_H__
