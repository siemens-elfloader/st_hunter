#ifndef __KEYHOOK_H__
#define __KEYHOOK_H__

typedef struct
{
  void *next;
  void *prev;
  int (*proc)(int submsg,int msg);
  char is_first;
}PLIST;

#define KEYHOOK_PATCH_VREZKA_RET_OFFSET 0x0B
#define KEYHOOK_PATCH_VREZKA_SIZE       8

#define SWINUM_ADDKEYBMSGHOOK           0x12B
#define SWINUM_ADDKEYBMSGHOOKEND        0x12C
#define SWINUM_REMKEYBMSGHOOK           0x12D

extern int keyhook_vrezka_entry;


void __jel_keyhookpatch_init();

#endif //__KEYHOOK_H__
