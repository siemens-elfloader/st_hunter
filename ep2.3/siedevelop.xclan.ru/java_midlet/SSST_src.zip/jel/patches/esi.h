#ifndef __ESI_H__
#define __ESI_H__

#define ESI_PATCH_VREZKA_OFFSET 0x002
#define ESI_PATCH_RET_OFFSET    0x00B
#define ESI_PATCH_VREZKA_SIZE   8

#define SWINUM_ESIPATCHFUNC     0x089

extern int esi_vrezka_entry; /**/

void __jel_esipatch_init();

#endif //__ESI_H__
