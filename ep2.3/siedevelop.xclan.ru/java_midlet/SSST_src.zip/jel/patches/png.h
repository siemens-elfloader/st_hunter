#ifndef __PNG_H__
#define __PNG_H__

//PIT_PATCH_VREZKA
#define PIT_PATCH_GETN_OFFSET  0x00D // -
#define PIT_PATCH_RET_OFFSET   0x009 // +
#define PIT_PATCH_VREZKA_SIZE  8

#define SWINUM_GETPITIMG       0x01E
#define SWINUM_CREATTEIMGFILE  0x1E9
#define SWINUM_PNGTOP          0x1B9


extern int pit_patch_vrezka_entry;

void __jel_pitpatch_init();

#endif //__PNG_H__
