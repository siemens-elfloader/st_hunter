#ifndef __JELFLOADER_H__
#define __JELFLOADER_H__

int jelfloader(void *elf_base, unsigned int *swilib, void *(*jmalloc)(unsigned int size), void (*jfree)(void *ptr));

int jelfloader_ptcctrl_isESIEnable();
int jelfloader_ptcctrl_isKeyHookEnable();
int jelfloader_ptcctrl_isPITPatchEnable();

#endif // __JELFLOADER_H__

