#ifndef __EXT_H__
#define __EXT_H__

typedef struct
{
  char *ext;
  int unical_id;
  signed char enabled_options;
  unsigned char obex_path_id;
  unsigned short menu_flag;
  int *icon1;
  int *icon2; //skip on reg
  void *proc;
  void *altproc;
}REGEXT;

#define UNICON_SMALL     0x1D1
#define UNICON_BIG       0x1D2
#define SWINUM_EXTTOP    0x1B8

extern const unsigned int bcfg_elficon;
 
void __jel_elfextreg();

#endif //__EXT_H__
