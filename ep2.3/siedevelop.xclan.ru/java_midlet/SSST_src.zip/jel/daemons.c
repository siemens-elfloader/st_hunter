#include "../inc/swilib.h"
#include "daemons.h"
#include "elf.h"

extern const char bcfg_daemons[];
extern const int bcfg_daemons_ena;


void __jel_daemons_run()
{
  if (bcfg_daemons_ena)
   {
    DIR_ENTRY de;
    unsigned int err;
    unsigned int pathlen;
    char name[256];
    strcpy(name, bcfg_daemons);
    pathlen=strlen(name);
    strcat(name,"*.elf");
    if (FindFirstFile(&de,name,&err))
     {
      do
        {
         name[pathlen]=0;
         strcat(name,de.file_name);
         elfload(name, 0, 0, 0);
        }
       while(FindNextFile(&de,&err));
      }
     FindClose(&de,&err);
   }
}

void __jel_daemons_subrun()
{
 SUBPROC((void *)&__jel_daemons_run);
}
