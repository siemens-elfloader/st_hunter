#ifndef __SEARCH_PATTERN_H__
#define __SEARCH_PATTERN_H__

typedef struct {
 int          *body;
 int           skipint;
 int           offset;
 int           bodysize; 
 int           elemsize; // 1, 2, 4
}PATTERN;

#define NULLINT        -1
#define SEARCH_ADDRESS 0xA0020000
#define SEARCH_SIZE    0x01900000

#define pat_byte_read(b) *( (unsigned char  *) ( b ) )
#define pat_hwrd_read(h) *( (unsigned short *) ( h ) )
#define pat_word_read(w) *( (unsigned int   *) ( w ) )

int SearchFunction(int search_address, int search_size, PATTERN *pattern);

#endif //__SEARCH_PATTERN_H__
