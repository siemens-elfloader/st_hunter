#ifndef __DAEMONS_H__
#define __DAEMONS_H__

void __jel_daemons_run();
void __jel_daemons_subrun();

#endif //__DAEMONS_H__
