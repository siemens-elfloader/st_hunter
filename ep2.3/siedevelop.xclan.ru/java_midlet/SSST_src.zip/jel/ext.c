#include "..\inc\swilib.h"
#include "swihook.h"
#include "elf.h"
#include "ext.h"

int elficon_id = 0;

int elfload_cardexplorer(WSHDR *filename, WSHDR *ext, void *param)
{
  char fn[128];
  ws_2str(filename, fn, 126);

  if (elfload(fn, (char *)param, 0, 0)) return 0; else return 1;
}


char eicon_folder[256] = "0:\\Zbin\\img\\";
char elf_ext[]="elf";

int icon_sml[2] = {UNICON_SMALL, 0};
int icon_big[2] = {UNICON_BIG, 0};

REGEXT elf_reg =
{
    elf_ext,
    0x60,
    0xFF,
    7,
    MENU_FLAG2,
    icon_sml,
    icon_big,
    (void *)elfload_cardexplorer,
    0   
};


void __jel_elfextreg()
{
 elficon_id = bcfg_elficon;
 icon_sml[0] = elficon_id;
 icon_big[0] = elficon_id + 1;
 RegExplorerExt((REGEXPLEXT *)&elf_reg);
 __jel_swihook_setfunc(SWINUM_EXTTOP, 0);
}

