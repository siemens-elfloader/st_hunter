#include "..\inc\cfg_items.h"
#include "..\inc\swilib.h"

//������������

__root CFG_HDR cfghdr1={CFG_CHECKBOX,"Enable Patch",0,0};
__root int patch_ena = 1;

__root CFG_HDR cfghdr2 = {CFG_STR_UTF8,"ET Folder",0,127};
__root char et_folder[128]="1:\\ExtTheme\\";

__root CFG_HDR cfghdr_cur_b={CFG_LEVEL,"Cursor\'s settings",1,0};

__root CFG_HDR cfghdr_c1 = {CFG_UINT, "Simple Cur Hight Limit", 0, 320};
__root unsigned int hlimit = 20;

__root CFG_HDR cfghdr_c2 = {CFG_UINT, "Options Cur Width Limit", 0, 240};
#ifdef SCREEN_132_176
__root unsigned int wlimit = 120;
#else
__root unsigned int wlimit = 115;
#endif

__root CFG_HDR cfghdr_c3 = {CFG_COLOR,"Color Border",0,0};
__root char col_p[4]={0xFF,0x00,0x00,80};

__root CFG_HDR cfghdr_c4 = {CFG_COLOR,"Color Body",0,0};
__root char col_b[4]={0x00,0x00,0x00,80};

__root CFG_HDR cfghdr_cur_e={CFG_LEVEL,"",0,0};


__root CFG_HDR cfghdr_pb_b={CFG_LEVEL,"Progressbar\'s settings",1,0};

__root CFG_HDR cfghdr_pb1 = {CFG_UINT, "Hight Limit for thin PB", 0, 320};
__root unsigned int hlim_pb = 12;


__root CFG_HDR cfghdr_pb_e={CFG_LEVEL,"",0,0};
