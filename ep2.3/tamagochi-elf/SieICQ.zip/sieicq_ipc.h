#ifndef _SIEICQ_IPC_H_
#define _SIEICQ_IPC_H_

#define SIEICQ_IPC_NAME "SieICQ"



#endif
