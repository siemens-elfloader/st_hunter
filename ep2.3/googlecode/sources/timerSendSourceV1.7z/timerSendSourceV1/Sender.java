

import com.siemens.mp.gsm.SMS;

class Sender extends Thread {

	public void run() {
		//System.out.println("Sleeping");
		try {
			Thread.sleep(5000L);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
		//System.out.println("Waking up");
		int i = 0;
		do {

			try {
				String number = (String) midlet.numbers.elementAt(i);
				String message=midlet.message;

				//System.out.println("Number:");
				//System.out.println(number);
				//System.out.println("Message:");
				//System.out.println(message);
				SMS.send(number, message);
			} catch (Exception ex) {
				ex.printStackTrace();
				MainMidlet.success = false;
			}
			if (MainMidlet.success) {
				i++;
				try {
					Thread.sleep(100L);
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
			} else {
				//System.out.println("Error sending...");
				try {
					Thread.sleep(500L);
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
			}
		} while (i < midlet.numbers.size());
	}

	MainMidlet midlet;

	public Sender(MainMidlet m) {
		midlet = m;
	}
}