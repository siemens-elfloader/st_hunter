public class OptChoice {

	public String name;

	public String[] opt_names;
	public int[] opt_values;
	public int count;

	public OptChoice(String cname, int npars) {

				name = cname;
				opt_names = new String[npars];
				opt_values = new int[npars];
				count = 0;

	}
}
