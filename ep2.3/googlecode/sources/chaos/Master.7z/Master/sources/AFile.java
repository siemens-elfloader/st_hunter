public abstract class AFile {

  public static boolean JSR;

  static {

	JSR = false;
	try {
		Class.forName("javax.microedition.io.file.FileConnection");
		JSR = true;
	}
	catch (Exception e) {
		

	}

  }

  public static AFile open(String name) throws Exception {

	return JSR ? AFileJ.open(name) : AFileS.open(name);

  }

  public abstract int read(byte[] buf, int off, int len) throws Exception;
  public abstract int write(byte[] buf, int off, int len) throws Exception;
  public abstract int length() throws Exception;
  public abstract void close() throws Exception;


  public static boolean exists(String name) throws Exception {

	return JSR ? AFileJ.exists(name) : AFileS.exists(name);

  }

  public static String[] list(String name) throws Exception {

	return JSR ? AFileJ.list(name) : AFileS.list(name);

  }

  public static void delete(String name) throws Exception {

	if (JSR) AFileJ.delete(name) ; else AFileS.delete(name);

  }

  public static boolean isDirectory(String name) throws Exception {

	return JSR ? AFileJ.isDirectory(name) : AFileS.isDirectory(name);

  }

}
