import com.siemens.mp.io.File;

public class AFileS extends AFile {

  private File F;
  private int fd;

  public static boolean exists(String name) throws Exception {

	return (File.exists(name) >= 0);

  }

  public static String[] list(String name) throws Exception {

	return File.list(name);

  }

  public static void delete(String name) throws Exception {

	File.delete(name);

  }

  public static boolean isDirectory(String name) throws Exception {

	return File.isDirectory(name);

  }

  public static AFile open(String name) throws Exception {

	AFileS af = new AFileS();
	af.F = new File();
	af.fd = af.F.open(name);
	return (AFile)af;

  }

  public int read(byte[] buf, int off, int len) throws Exception {

	return F.read(fd, buf, off, len);

  }

  public int write(byte[] buf, int off, int len) throws Exception {

	return F.write(fd, buf, off, len);

  }

  public int length() throws Exception {

	return F.length(fd);

  }

  public void close() throws Exception {

	F.close(fd);
	F = null;

  }

}
