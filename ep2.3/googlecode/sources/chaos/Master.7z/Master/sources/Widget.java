import javax.microedition.lcdui.*;

public class Widget {

	public static final int BYTE = 1;
	public static final int INT = 2;
	public static final int STRING = 3;
	public static final int USTRING = 4;
	public static final int HEX = 5;
	public static final int CHECKBOX = 6;
	public static final int SELECTFILE = 7;
	public static final int SELECTDIR = 8;
	public static final int PHONE = 9;
	public static final int SLIDER = 10;
	public static final int OPTION = 11;
	public static final int SUBMENU = 12;
	public static final int CONSTANT = 13;
	public static final int TIMEINMS = 14;
	public static final int XY = 15;
	public static final int XY2 = 16;
	public static final int ADDR = 17;
	public static final int COLOR = 18;

	public int type;
	public Tag tag;
	public String name;
	public Item item;
	public Command command;
	public Form form;
	public OptChoice optchoice;
	public int minvalue;

	public int size;
	public int value;
	public int x, y, w, h, savex, savey;

	public Widget(int wtype, Tag t) {

		type = wtype;
		tag = t;
		name = t.name;

	}

}
