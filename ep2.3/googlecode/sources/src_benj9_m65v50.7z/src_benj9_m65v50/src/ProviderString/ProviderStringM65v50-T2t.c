#define M65v50

#include "..\shared\x65.h"

#ifdef M65v50
	#define _PicturePaint_ (0xA16341BC+1)
	#define _GetProfile_ (0xA08C9FE4+1)
	#define _NetData_ 0xA867B0A0
	#define _VarROM_  0xA08009E0
	#define _Sprintf_ 0xA153E501
	#define _Dec2Hex_ (0xA082BE20+1)
	#define _GetImageWidth_ (0xA114E024+1) 
	#define _PlaySoundLoop_ 0xA0935CF8 
	
	#define _IsScrSaver_ 0xA163E2D1
	#define _IsUnlocked_ 0xA114D0A7
	
	#define NETDataAddress 0xA867B0A0
	
	#define _RAMvar_   0xA8000200 

	#define _RAMspy_ 0xA8002000 //  0xA8002000
	#define _ROM_ 0xA0C00020
	
	#define _FAccuTemp_ 0xA1159FD0
	
	// A8019200  A8311849  A801EFA0 A866EAFC  A867B0A0  A875AE00
	
	// A866EAFC  A867B0A0
	
	
	
	// 900A69A8 ; 38E563A8 A863E583 / E85E65A8 A8655EE8 / 900A69A8 A8690A90 / 
	/*
	// File handling
	g_fopen fopen = (g_fopen)(0xA1216FE8);
	g_fwrite fwrite = (g_fwrite)(0xA1217110);
	g_lseek lseek = (g_lseek)(0xA12181FC);
	g_fclose fclose = (g_fclose)(0xA1216F3C);
	g_OpenReadCloseFile OpenReadCloseFile = (g_OpenReadCloseFile)(0xA0BB4106+1); 

	// File System Handling
	g_mkdir mkdir = (g_mkdir)(0xA126057C);

	// Memory
	g_malloc malloc = (g_malloc)(0xA0820F98);
	g_mfree mfree = (g_mfree)(0xA0821000);
	g_mfree_high mfree_high = (g_mfree_high)(0xA0BB76E4+1);

	// Date / Time
	GETDATETIME getdate = (GETDATETIME)(0xA0B20D3A+1);	

	// Strings
	f_strlen strlen = (f_strlen)(0xA153E6E4+1);
	g_strcat strcat = (g_strcat)(0xA153E584+1);
	g_strchr strchr = (g_strchr)(0xA153E5A4+1);
	g_strcmp strcmp = (g_strcmp)(0xA153E5C8);
	f_strcpy strcpy = (f_strcpy)(0xA153E664+1);

	// Other
	g_AlarmClockRing AlarmClockRing = (g_AlarmClockRing)(0xA0B6D4A6+1);
	g_SwitchPhoneOff SwitchPhoneOff = (g_SwitchPhoneOff)(0xA1240938);
	g_SetProfile SetProfile = (g_SetProfile)(0xA08C9EB2+1);
	g_GetProfile GetProfile = (g_GetProfile)_GetProfile_;
	
	g_editOrNewTXTModule editOrNewTXTModule = (g_editOrNewTXTModule)(0xA0A2A104+1);	
	*/
#endif

//g_GetProfile GetProfile = (g_GetProfile)_GetProfile_;

//typedef unsigned int (*g_IsScrSaver)();
//g_IsScrSaver IsScrSaver = (g_IsScrSaver) _IsScrSaver_;

//typedef unsigned int (*g_IsUnlocked)();
//g_IsUnlocked IsUnlocked = (g_IsUnlocked) _IsUnlocked_;

	

struct ROMb{
	byte r0,r1,r2,r3;
};

struct ROMw{
	word w0,w1;
};

struct ROMd{
	dword d0 ;
};


struct RAM_VAR{
	int v0;
};

//struct RAMvar0{
//	byte b0, b1, b2, b3;
//};

//struct RAM_SPY {
//	byte b0,b1,b2,b3;
//};

//struct b1 {
//	byte b0, b1, b2, b3;
//};


//g_PlaySoundLoop PlaySoundLoop = (g_PlaySoundLoop) _PlaySoundLoop_;


//typedef void (*f_Keypadlight)(int r0, int r1, int r2, int r3);
//f_Keypadlight Keypadlight = (f_Keypadlight) 0xA0BC78B8; 

f_sprintf sprintf = (f_sprintf) _Sprintf_;


//typedef char*(*g_Dec2Hex)(int decnumber, int l);
//g_Dec2Hex dec2hex = (g_Dec2Hex) _Dec2Hex_;

//void chartounicode(char *src, char *dest);
//void saveTMOfile(char *filename, char *text);
//void decodeTMOfile(char *src, char *dest);
//unsigned char XORCheck(char *str);


void copystrtowstr(char *src, unsigned short *dest, unsigned int*count) {
	while(*src != 0) {
		*dest++ = *src++;
		*count += 1;
	}	
} 

void Custom_Format(struct WString* pws) {
//const struct NetData* net = (struct NetData *) _NetData_;
struct RAM_VAR* RAMvar = (struct RAM_VAR *) _RAMvar_;

struct ROMb* Romb = (struct ROMb *) _ROM_;
struct ROMw* Romw = (struct ROMw *) _ROM_;
struct ROMd* Romd = (struct ROMd *) _ROM_;
//struct RAM_SPY* RAMspy = (struct RAM_SPY *) _RAMspy_;

unsigned int count = 1;// int i=0; //int j;
unsigned short *p = pws->pstr; 
char string[32];

	//i=GetProfile();
	//sprintf(string, "hallo");
	
	switch(RAMvar->v0){
		case 0:
		case 2: sprintf(string, "%x %x %x %x", Romb->r0, Romb->r1, Romb->r2, Romb->r3); 
				RAMvar->v0++; break;
		case 1: sprintf(string, "%x %x ", Romw->w0, Romw->w1);
				RAMvar->v0++; break;
		case 3: sprintf(string, "%x", Romd->d0);
				RAMvar->v0=0; break;
	}
	
	//string=pws->pstr;
	copystrtowstr(string, &p[count], &count);
	*p = count-1;
	
	return;
}


//void entryMainscreen(struct WString* pws) {
//	Custom_Format(pws);
//	return;
//}
/*

void saveTMOfile(char *filename, char *text)
{
	unsigned char cLength;
	unsigned char cXORCheck;
	int iFileHandle;
	unsigned int iError;
	
	char *filebuffer;
	char *out;
	
	filebuffer = malloc(256);
	out = malloc(2);
	out[1] = 0;
	
	cLength = strlen(text);
	cXORCheck = XORCheck(text) ^ cLength;
	
	
	chartounicode(text, filebuffer);
	
	iFileHandle = fopen(filename, A_Create + A_WriteOnly, P_WRITE, &iError);
	lseek (iFileHandle, 0, S_SET, &iError);

	out[0] = cLength;
	fwrite(iFileHandle, out, 2, &iError); // write header

	fwrite(iFileHandle, filebuffer, cLength * 2, &iError); // write text

	out[0] = cXORCheck;
	fwrite(iFileHandle, out, 2, &iError); // write XOR check

	fclose(iFileHandle, &iError);
		
	
	mfree(filebuffer);
	mfree(out);
}


void decodeTMOfile(char *src, char *dest)
{
	unsigned int iSize;
	unsigned int i;
	iSize = src[0];
	for (i = 0; i < iSize; i++) {
		dest[i] = src[i * 2 + 2];
	}
	dest[iSize] = 0x00;
}

void chartounicode(char *src, char *dest)
{
	unsigned int count = 0;
	unsigned int count2 = 0;
	while(src[count] != 0) {
		dest[count2] = src[count++];
		dest[count2+1] = 0x00;
		count2 += 2;
	}
}

unsigned char XORCheck(char *str)
{
	unsigned char chk = 0;
	unsigned int i=0;
	while(str[i] != 0) chk ^= str[i++];
	return chk;
}

*/