// TEstversion for evalution of accu temp as monitor for other patch

#define M65v50

#include "..\shared\x65.h"

#ifdef M65v50
	#define _PicturePaint_ (0xA16341BC+1)
	#define _GetProfile_ (0xA08C9FE4+1)
	#define _NetData_ 0xA867B0A0
	#define _VarROM_  0xA08009E0
	#define _Sprintf_ 0xA153E501
	#define _Dec2Hex_ (0xA082BE20+1)
	#define _GetImageWidth_ (0xA114E024+1) 
	#define _PlaySoundLoop_ 0xA0935CF8 

	#define NETDataAddress 0xA867B0A0
	
	#define _RAMvar_   0xA8000200 

	#define _RAMspy_ 0xA8000210
	
	// A8019200  A8311849  A801EFA0 A866EAFC  A867B0A0  A875AE00
	
	// A866EAFC  A867B0A0
	
	
	
	// 900A69A8 ; 38E563A8 A863E583 / E85E65A8 A8655EE8 / 900A69A8 A8690A90 / 
	/*
	// File handling
	g_fopen fopen = (g_fopen)(0xA1216FE8);
	g_fwrite fwrite = (g_fwrite)(0xA1217110);
	g_lseek lseek = (g_lseek)(0xA12181FC);
	g_fclose fclose = (g_fclose)(0xA1216F3C);
	g_OpenReadCloseFile OpenReadCloseFile = (g_OpenReadCloseFile)(0xA0BB4106+1); 

	// File System Handling
	g_mkdir mkdir = (g_mkdir)(0xA126057C);

	// Memory
	g_malloc malloc = (g_malloc)(0xA0820F98);
	g_mfree mfree = (g_mfree)(0xA0821000);
	g_mfree_high mfree_high = (g_mfree_high)(0xA0BB76E4+1);

	// Date / Time
	GETDATETIME getdate = (GETDATETIME)(0xA0B20D3A+1);	

	// Strings
	f_strlen strlen = (f_strlen)(0xA153E6E4+1);
	g_strcat strcat = (g_strcat)(0xA153E584+1);
	g_strchr strchr = (g_strchr)(0xA153E5A4+1);
	g_strcmp strcmp = (g_strcmp)(0xA153E5C8);
	f_strcpy strcpy = (f_strcpy)(0xA153E664+1);

	// Other
	g_AlarmClockRing AlarmClockRing = (g_AlarmClockRing)(0xA0B6D4A6+1);
	g_SwitchPhoneOff SwitchPhoneOff = (g_SwitchPhoneOff)(0xA1240938);
	g_SetProfile SetProfile = (g_SetProfile)(0xA08C9EB2+1);
	g_GetProfile GetProfile = (g_GetProfile)_GetProfile_;
	
	g_editOrNewTXTModule editOrNewTXTModule = (g_editOrNewTXTModule)(0xA0A2A104+1);	
	*/
#endif

g_GetProfile GetProfile = (g_GetProfile)_GetProfile_;
	

//struct VarRom{
//	byte p[7];
//};

struct RAM_VAR{
	int profile, dist, offset;
};

//struct RAMvar0{
//	byte b0, b1, b2, b3;
//};

struct RAM_SPY {
	byte b0,b1,b2,b3;
};

//struct b1 {
//	byte b0, b1, b2, b3;
//};


g_PlaySoundLoop PlaySoundLoop = (g_PlaySoundLoop) _PlaySoundLoop_;


//typedef void (*f_Keypadlight)(int r0, int r1, int r2, int r3);
//f_Keypadlight Keypadlight = (f_Keypadlight) 0xA0BC78B8; 

f_sprintf sprintf = (f_sprintf) _Sprintf_;


//typedef char*(*g_Dec2Hex)(int decnumber, int l);
//g_Dec2Hex dec2hex = (g_Dec2Hex) _Dec2Hex_;

//void chartounicode(char *src, char *dest);
//void saveTMOfile(char *filename, char *text);
//void decodeTMOfile(char *src, char *dest);
//unsigned char XORCheck(char *str);


void copystrtowstr(char *src, unsigned short *dest, unsigned int*count) {
	while(*src != 0) {
		*dest++ = *src++;
		*count += 1;
	}	
} 

/*void inline(const dword ADR)
{
    int ch;
    __asm
 {

        LDR  ch, [ADR]

   }
} */




void Custom_Format(struct WString* pws) {
//const char* profilemode;
//const struct NetData* net = (struct NetData *) _NetData_;
struct RAM_VAR* RAMvar = (struct RAM_VAR *) _RAMvar_;

//struct VarRom* varRom = (struct VarRom *) _VarROM_;
struct RAM_SPY* RAMspy = (struct RAM_SPY *) _RAMspy_;

unsigned int count = 1; int i=0; int j;
unsigned short *p = pws->pstr;
const temp_min=180; //starts at 18�C - end at (180+176)/10=35,6�C
char string[32];

	i=GetProfile();
	
	if (i==4) RAMvar->offset += RAMvar->dist -1 ;
	if (RAMvar->offset>0) {
		for (j=0;j<RAMvar->offset;j++) RAMspy++;
	} else {
		if (RAMvar->offset<0) {
			for (j=0;j>RAMvar->offset;j--) RAMspy--;
		}
	}
	
	
	if (i<4) RAMvar->profile=i; else
	    if (i==5){
	    	RAMvar->dist=2-RAMvar->dist;
	    	// Keypadlight(1,1,0,5);
	    } else
	      if (i==6) { 
		    switch(RAMvar->profile) { 
			  case (0): RAMspy->b0 += RAMvar->dist-1; break;
			  case (1): RAMspy->b1 += RAMvar->dist-1; 
			  			PlaySoundLoop(RAMspy->b1, 2, RAMspy->b2); //play sound b2, b2 times
			 			break;
			  case (2): RAMspy->b2 += RAMvar->dist-1; break;
			  case (3): RAMspy->b3 += RAMvar->dist-1;
						// RAMspy->b0=1-RAMspy->b0; // toggle b0
						break;
		    }
	      }
	i=RAMspy->b2+(RAMspy->b3*256);
	sprintf(string, "[%x,%x]=%d,%d�@%d", RAMspy->b2,RAMspy->b3,i,i-temp_min,(RAMvar->dist)-1);
	
	//sprintf(string, "%x[%x,%x,%x,%x]%d", RAMspy - 0xA8000000, RAMspy->b0,RAMspy->b1,RAMspy->b2,RAMspy->b3, (RAMvar->dist)-1);
	copystrtowstr(string, &p[count], &count);
	
	*p = count-1;
	
	return;
}


//void entryMainscreen(struct WString* pws) {
//	Custom_Format(pws);
//	return;
//}
/*

void saveTMOfile(char *filename, char *text)
{
	unsigned char cLength;
	unsigned char cXORCheck;
	int iFileHandle;
	unsigned int iError;
	
	char *filebuffer;
	char *out;
	
	filebuffer = malloc(256);
	out = malloc(2);
	out[1] = 0;
	
	cLength = strlen(text);
	cXORCheck = XORCheck(text) ^ cLength;
	
	
	chartounicode(text, filebuffer);
	
	iFileHandle = fopen(filename, A_Create + A_WriteOnly, P_WRITE, &iError);
	lseek (iFileHandle, 0, S_SET, &iError);

	out[0] = cLength;
	fwrite(iFileHandle, out, 2, &iError); // write header

	fwrite(iFileHandle, filebuffer, cLength * 2, &iError); // write text

	out[0] = cXORCheck;
	fwrite(iFileHandle, out, 2, &iError); // write XOR check

	fclose(iFileHandle, &iError);
		
	
	mfree(filebuffer);
	mfree(out);
}


void decodeTMOfile(char *src, char *dest)
{
	unsigned int iSize;
	unsigned int i;
	iSize = src[0];
	for (i = 0; i < iSize; i++) {
		dest[i] = src[i * 2 + 2];
	}
	dest[iSize] = 0x00;
}

void chartounicode(char *src, char *dest)
{
	unsigned int count = 0;
	unsigned int count2 = 0;
	while(src[count] != 0) {
		dest[count2] = src[count++];
		dest[count2+1] = 0x00;
		count2 += 2;
	}
}

unsigned char XORCheck(char *str)
{
	unsigned char chk = 0;
	unsigned int i=0;
	while(str[i] != 0) chk ^= str[i++];
	return chk;
}

*/