// displays running number A8001748

#define M65v50

#include "..\shared\x65.h"

#ifdef M65v50
	#define _PicturePaint_ (0xA16341BC+1)
	#define _GetProfile_ (0xA08C9FE4+1)
	#define _NetData_ 0xA867B0A0
	#define _VarROM_  0xA08009E0
	#define _Sprintf_ 0xA153E501
	#define _Dec2Hex_ (0xA082BE20+1)
	#define _GetImageWidth_ (0xA114E024+1) 
	#define _PlaySoundLoop_ 0xA0935CF8 

	#define NETDataAddress 0xA867B0A0
	
	#define _VarRAM0_   0xA8001748
	#define _VarRAM_   0xA8000220
	
	
	#define netdatax 0xA867B090
	#define netdata1 
	#define netaccessmode 0xA132D7D0
	
	#define _ram_timer_basic_ 0xA8001748
	#define _ram_net_mode2	0xA8752560 
	#define _ram_net_mode	0xA8752560+0x68
#endif

//g_GetProfile GetProfile = (g_GetProfile)_GetProfile_;
f_sprintf sprintf = (f_sprintf) _Sprintf_;	


//struct VarRam{
//	byte x;
//};

struct _NET_mode2{
	byte x;
};

struct _NET_mode{
	byte x;
};


copystrtowstr(char *src, unsigned short *dest, unsigned int*count) {
	while(*src != 0) {
		*dest++ = *src++;
		*count += 1;
	}	
}

 Custom_Format(struct WString* pws) {

struct _NET_mode* netmode = (struct _NET_mode *) _ram_net_mode;
struct _NET_mode2* netmode2 = (struct _NET_mode2 *) _ram_net_mode2;

unsigned int count = 1;
unsigned short *p = pws->pstr; 
char string[32];


	sprintf(string, "[%02x] [%02x]",netmode2->x,netmode->x);
	
	copystrtowstr(string, &p[count], &count);
	*p = count-1;	
	return;
}



