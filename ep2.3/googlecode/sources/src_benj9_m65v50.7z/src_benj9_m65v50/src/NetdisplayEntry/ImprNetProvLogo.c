// (c) benj9

// based on code of (c) 2005 ACiD[mrp] and arsh0r




#define M65v50

#include "..\shared\x65.h"

#ifdef M65v50
	#define _FollowUpPatch_ 0xA0FDE301
	#define _PicturePaint_ (0xA16341BC+1)
	#define _GetSelectedProfile_ (0xA08C9FE4+1)
	#define _NetData_ 0xA867B0A0
	#define _VarROM_  0xA16E00E4
	#define _VarRAM_  0xA8000200
	#define _SecRAM_ 0xA875AE0A
	#define _PlaySoundLoop_ 0xA0935CF8  
	#define _ram_netaccess_mode2_ 0xA8752560
	#define _free_ram_ 0xA8000250
#endif


#ifdef M65v43
	#define _PicturePaint_ (0xA163AD10+1)
	#define _GetSelectedProfile_ (0xA08C93E0+1)
	#define _NetData_ 0xA867AF98
#endif

#ifdef S65v47
	#define _PicturePaint_ (0xA169E998+1)
	#define _GetSelectedProfile_ (0xA08C88F4+1)
	#define _NetData_ 
#endif

#ifdef S65v50
	#define _PicturePaint_ 
	#define _GetSelectedProfile_
	#define _NetData_  
#endif

struct VarRom{
	byte b0;
};

struct VarRam{
	byte x;
};

struct SecRam{
	byte s;
};

struct Netmode2{
	byte n2;
};  

typedef int (*g_GetSelectedProfile)(void);
g_GetSelectedProfile GetSelectedProfile = (g_GetSelectedProfile) _GetSelectedProfile_;

typedef void (*g_PicturePaint)(int x, int y, int PictureIndex);
g_PicturePaint PicturePaint = (g_PicturePaint) _PicturePaint_;

// typedef int (*g_PlaySoundLoop)(unsigned int iSoundID, unsigned int unknown1, unsigned int LoopCount);
// g_PlaySoundLoop PlaySoundLoop = (g_PlaySoundLoop) _PlaySoundLoop_;

//typedef int (*g_FollowUpPatch)(void);
//g_FollowUpPatch FollowUpPatch = (g_FollowUpPatch) _FollowUpPatch_;

void Net_Display(int x, int y, int PictureIndex) 
{
	// const struct NetData* net = (struct NetData *) _NetData_;
	const struct Netmode2* netmode2 = (struct Netmode2 *) _ram_netaccess_mode2_;

	
//	struct VarRom* varRom = (struct VarRom *)_VarROM_;
//	struct VarRam* varRam = (struct VarRam *)_free_ram_;
//	struct SecRam* secRam = (struct SecRam *)_SecRAM_;

	//const  x_NetIndiImproved=3;//0x65;
	//const  y_NetIndiImproved=13;//0x90;
	//const  x_ProfileLogo=0x01;
	//const  y_ProfileLogo=0x95;
	
	//const   first_profileIcon=225;
	//const   first_imprNetIndiIcon=232;
	
	const	first_normalNetLogo=808;
	
	
	//const  xt_pic=400;
	//const  yt_pic=402;
	
	// const  numberOfImprovNetBars=7;
	// const  spacingnOfImprovNetBars=4;
	
	int i,n ; //, xo=0, ;
      	
    i=GetSelectedProfile();

	// Profile_Logo
    // PicturePaint(x_ProfileLogo,y_ProfileLogo, i + first_profileIcon); //profillogo 


	//  netmode 2 net indicator benj9
		if  (i!=0x99) { 
		
		if (netmode2->n2 <= 2) { n=273; }   // net traffic
		else
		if (netmode2->n2 == 3) { n=261; }    // net gsm 900 
		else
		if (netmode2->n2 == 8) { n=267; }    // net gsm 1800
		else
		if (netmode2->n2 == 0x1b) { n=808; }    // net gsm auto
		else { n=279; }
		
		PicturePaint(x,y,PictureIndex - first_normalNetLogo + n);

	// Improved Net Indicator arsh0r 
	/*
		xo -= spacingnOfImprovNetBars;
		for (i=0; i<numberOfImprovNetBars; i++) {
			if (net->CH < 0xFF)
				PictureIndex = first_imprNetIndiIcon+7; // 0x303 + 434;  
			else
				PictureIndex = first_imprNetIndiIcon; // 0x30A+ 434;
			if (net->RX < 50)
				PictureIndex = first_imprNetIndiIcon+14; // 0x311+ 434;
			else if (net->RX < 62)
				PictureIndex += 6;
			else if (net->RX < 69)
				PictureIndex += 5;
			else if (net->RX < 76)
				PictureIndex += 4;
			else if (net->RX < 83)
				PictureIndex += 3;
			else if (net->RX < 90)
				PictureIndex += 2;
			else if (net->RX < 97)
				PictureIndex += 1;
			else if (net->RX < 104)
				PictureIndex += 0;
			else
				PictureIndex = first_imprNetIndiIcon+14; // 0x311+ 434;
			xo += spacingnOfImprovNetBars;
			PicturePaint(x_NetIndiImproved+xo,y_NetIndiImproved,PictureIndex);
		++net;
		} 
		*/
		} 
		
		//FollowUpPatch();
}