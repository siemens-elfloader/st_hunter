// (c) benj9

// based on code of (c) 2005 ACiD[mrp] and arsh0r




#define M65v50

#include "..\shared\x65.h"

#ifdef M65v50
	#define _PicturePaint_ (0xA16341BC+1)
	#define _GetSelectedProfile_ (0xA08C9FE4+1)
	#define _NetData_ 0xA867B0A0
	#define _VarROM_  0xA16E00E4
	#define _VarRAM_  0xA8000200
	#define _PlaySoundLoop_ 0xA0935CF8  
#endif


#ifdef M65v43
	#define _PicturePaint_ (0xA163AD10+1)
	#define _GetSelectedProfile_ (0xA08C93E0+1)
	#define _NetData_ 0xA867AF98
#endif

#ifdef S65v47
	#define _PicturePaint_ (0xA169E998+1)
	#define _GetSelectedProfile_ (0xA08C88F4+1)
	#define _NetData_ 
#endif

#ifdef S65v50
	#define _PicturePaint_ 
	#define _GetSelectedProfile_
	#define _NetData_  
#endif

struct VarRom{
	byte b0;
};

struct VarRam{
	dword wx; byte bx;
};

typedef int (*g_GetSelectedProfile)(void);
g_GetSelectedProfile GetSelectedProfile = (g_GetSelectedProfile) _GetSelectedProfile_;

typedef void (*g_PicturePaint)(int x, int y, int PictureIndex);
g_PicturePaint PicturePaint = (g_PicturePaint) _PicturePaint_;

typedef int (*g_PlaySoundLoop)(unsigned int iSoundID, unsigned int unknown1, unsigned int LoopCount);
g_PlaySoundLoop PlaySoundLoop = (g_PlaySoundLoop) _PlaySoundLoop_;



void Net_Display(int x, int y, int PictureIndex) 
{
	const struct NetData* net = (struct NetData *) _NetData_;
//	struct VarRom* varRom = (struct VarRom *)_VarROM_;
//	struct VarRam* varRam = (struct VarRam *)_VarRAM_;
	const  x_NetIndiNormal=0x00;
	const  y_NetIndiNormal=0x00;
	const  x_NetIndiImproved=0x65;
	const  y_NetIndiImproved=0x90;
	const  x_ProfileLogo=0x01;
	const  y_ProfileLogo=0x95;
	int i=0; byte m; int xo=0, p;

	/* mode:
	0  NetNormal
	1  ProfileLogo
	2  NetNormal & ProfielLogo
	3  NetImproved
	4  NetNormal & NetImproved
	5  NetImproved & ProfileLogo
	6  NetNormal & NetImprovedl & ProfileLogo
	
	Dont forget to place mode in vkp at (0xA16E00D8)
	 */


      	
      	// m=varRom->b0;
      	
      	p=GetSelectedProfile();
      	if (p==6) m=0; else m=6;
      	
      	//varRam->w0 = PictureIndex;
      	
/*      	if (GetSelectedProfile()==6) {
      		varRam->wx=0xFFFFFFFF;
      		PicturePaint(40,43, 297+varRam->bx++);
      		if (varRam->bx > 5) varRam->bx=0;
      	}	
      	else varRam->wx=0; */
      	
    if (net->RX < 50) PlaySoundLoop(0x2F, 1, 3);
    if (PictureIndex <= 808)  PlaySoundLoop(3, 2, 3);

	if ((m==0)||(m==2)||(m==4)||(m==6))
      	PicturePaint(x_NetIndiNormal, y_NetIndiNormal, PictureIndex); //normal Netlogo
	if ((m==1)||(m==2)||(m==5)||(m==6))
       	PicturePaint(x_ProfileLogo,y_ProfileLogo, p + 225); //profillogo 

        //Typ: M65: 225-284;
 	if  ((m>=3)&&(m<=6)) {      
		xo -= 5;
		for (i=0; i<6; i++) {
			if (net->CH < 0xFF)
				PictureIndex = 232; // 0x303 + 434;  
			else
				PictureIndex = 239; // 0x30A+ 434;
			if (net->RX < 50)
				PictureIndex = 246; // 0x311+ 434;
			else if (net->RX < 62)
				PictureIndex += 6;
			else if (net->RX < 69)
				PictureIndex += 5;
			else if (net->RX < 76)
				PictureIndex += 4;
			else if (net->RX < 83)
				PictureIndex += 3;
			else if (net->RX < 90)
				PictureIndex += 2;
			else if (net->RX < 97)
				PictureIndex += 1;
			else if (net->RX < 104)
				PictureIndex += 0;
			else
				PictureIndex = 246; // 0x311+ 434;
			xo += 5;
			PicturePaint(x_NetIndiImproved+xo,y_NetIndiImproved,PictureIndex);
		++net;
		} }

}