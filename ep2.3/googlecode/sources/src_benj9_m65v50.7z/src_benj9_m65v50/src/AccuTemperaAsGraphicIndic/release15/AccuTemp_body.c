// thermometer accutemperature
// (c) benj9

// based on accutemp-methode of avkiev




#define M65v50

#include "..\shared\x65.h"

#ifdef M65v50
	#define _PicturePaint_ (0xA16341BC+1)
	#define _GetSelectedProfile_ (0xA08C9FE4+1)
	#define _NetData_ 0xA867B0A0
	#define _RAMvar_   0xA8000200 
	#define _RAMspy_ 0xA8000210
	#define _PlaySoundLoop_ 0xA0935CF8  
#endif



//struct VarRom{
//	byte b0;
//};

//struct RAM_VAR{
//	byte b0,b1,b2,b3;
//};

struct RAM_SPY{
	word w0,w1;
};


typedef int (*g_GetSelectedProfile)(void);
g_GetSelectedProfile GetSelectedProfile = (g_GetSelectedProfile) _GetSelectedProfile_;

typedef void (*g_PicturePaint)(int x, int y, int PictureIndex);
g_PicturePaint PicturePaint = (g_PicturePaint) _PicturePaint_;

//typedef int (*g_PlaySoundLoop)(unsigned int iSoundID, unsigned int unknown1, unsigned int LoopCount);
//g_PlaySoundLoop PlaySoundLoop = (g_PlaySoundLoop) _PlaySoundLoop_;

/*word ReadAccuTemp()
{
    int res;
    __asm {
    	MOV R4,#0x68
    	MOV R5,#0xF
    	MOV R0,#1
    	MOV R1,#3
    	NOP // LDR R2,[_FAccuTemp_]
    	NOP // BLX R2
    	MOV R1,#0x0A
    	LSL R1,#0x10
    	ADD R1,0xAA
    	SUB res,R0,R1
    	MOV R1,#0
    	LSL R2,R1,#0x18
    	ASR R1,R2,#0x18
    	ADD res,res,R1
    	BPL marker
    	MOV R3,#0x2d
    	ADD R5,#2
    	STRH R3,[R4,R5]
    	NEG R0,R0
marker:	
		NOP
    }
    return res;
} */


void Net_Display() 
{
//	const struct NetData* net = (struct NetData *) _NetData_;
//	struct VarRom* varRom = (struct VarRom *)_VarROM_;
//struct RAM_VAR* RAMvar = (struct RAM_VAR *) _RAMvar_;
struct RAM_SPY* RAMspy = (struct RAM_SPY *) _RAMspy_;

// number of icons=12 + 2(und and overflow); 

	const temp_min=180; //starts at 18�C - ends at (180+(12*16))/10 = 37,2�C
	const icon_first=0x8967;//383; //0x17F (12 icons)
	const icon_under=0xEFCD; // underflow of temp_min
	const icon_over=0xFF99; // underflow of temp_min
	
	/*
		const temp_min=180; //starts at 18�C - ends at (180+(12*16))/10 = 37,2�C
	const icon_first=568;//383; //0x17F (12 icons)
	const icon_under=565; // underflow of temp_min
	const icon_over=567; // underflow of temp_min
*/


	const icon_x=101; //-7; //0xFFF9
	const icon_y=6; //80; //0x50
	
	int temp, icon;


    if (GetSelectedProfile()!=0x99) {
    	
    	temp=RAMspy->w1 - temp_min;
    	
    	if (temp<0) icon=icon_under;
    	else {
			if (temp>=(192+192)) icon=icon_over;
			else icon=icon_first+(temp/32);
		}
		
		PicturePaint(icon_x, icon_y, icon);

    }
}