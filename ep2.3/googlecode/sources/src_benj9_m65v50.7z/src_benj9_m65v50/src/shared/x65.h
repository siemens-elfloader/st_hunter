/********************************************************************
   (C) Copyright free source ,by Bennie.Joe@Gmail.com  

	filename: 	x65.h
	created:	14:1:2005
	author:		Bennie
	
	describe:	����X65ͨ�õĽṹ������
*********************************************************************/

#ifndef _X65_H_
#define _X65_H_

typedef unsigned char  byte;
typedef unsigned short word;
typedef unsigned int   dword;


struct WString{
	word* pstr;
	int buflen;
}; 
struct DateInfo{
	dword year;
	byte month;
	byte day;
	byte fill[2];
};
struct TimeInfo{
	byte hour;
	byte minute;
	byte sec;
	byte fill;
	dword  ms;
};

struct NetData {
	word CH;
	word CI;
	word LAC;
	byte RX;
	byte C1;
	byte C2;
	byte fill[3];
};

typedef struct _int_int{
	int quotient;
	int remainder;
}int_int;

typedef struct _ReturnReg {
	int r0;
	int r1;
	int r2;
	int r3;
}ReturnReg;

typedef void (*GETDATETIME)(struct DateInfo* pdate, struct TimeInfo* ptime);
typedef int	 (*GETWEEK)(struct DateInfo* pdate);
typedef void (*INTTOSTR)(int dig, char* str, int size);
typedef __value_in_regs int_int (*DWMODDW)(int a, int b);
typedef void (*WS_APPENDCHAR)(struct WString* pws, word ch);
typedef void (*WS_INSERTCHAR)(struct WString* pws, word ch, int pos);
typedef char*(*STRNCPY)( char *strDest, const char *strSource, int count );
typedef char*(*STRCAT)( char *strDestination, const char *strSource );
typedef void (*GETTIMESTR)(struct TimeInfo*, char*, int is12, int flag);

//string and momery
typedef int   (*f_sprintf		)(char*, const char*, ... );
typedef int   (*f_strlen		)(const char*);
typedef char* (*f_strcpy		)(char*, const char*);
typedef void* (*f_memchr		)(const void *buf, int c, int count );
typedef int   (*f_memcmp		)(const void *buf1, const void *buf2, int count );
typedef char* (*g_malloc_high)(int iSize);
typedef void (*g_mfree_high)(char *cArray);
typedef char* (*g_malloc)(unsigned int iSize);
typedef void (*g_mfree)(char *cArray);
typedef char* (*g_strcat)( char * dest, const char * src );
typedef char* (*g_strchr)( const char * string, int c );
typedef int (*g_strcmp)( const char * string1, const char * string2 );

//AT+CGSN
typedef int   (*f_OriginalATCGSN)(void);
typedef char* (*f_GetATCmdString)(void);
typedef void  (*f_SendATAnswerStr)(const char*);
typedef int   (*f_PostAtCommand )(void);
typedef void  (*f_SendStrToHost )(const char*);
typedef __value_in_regs ReturnReg (*f_CallBack		)(dword,dword,dword,dword);
typedef void (*g_SendCommChar)(unsigned char cChar);
typedef void (*g_SendCommString)(unsigned char *cString);


typedef void (*GetLP)(int id, const byte *buffer);
typedef int (*GetAkku)(int x, int y);

//Image
typedef void (*DrawImg)(int x, int y, int imgid);
typedef void (*DrawImgBW)(int x, int y, int imgid, const int *frontcolor, const int *backcolor);


//Profile
typedef unsigned int (*g_GetProfile)();
typedef void (*g_SetProfile)(unsigned int iProfileNumber);

//file handling
#define S_SET 0
#define S_CUR 1
#define S_END 2

#define P_WRITE 0x100
#define P_READ 0x80

#define A_ReadOnly 0
#define A_WriteOnly 1
#define A_ReadWrite 2 
#define A_NoShare 4     
#define A_Append 8
#define A_Exclusive 0x10
#define A_MMCStream 0x20
#define A_Create 0x100
#define A_Truncate 0x200
#define A_FailCreateOnExist 0x400
#define A_FailOnReopen 0x800

#define A_TXT 0x4000
#define A_BIN  0x8000


typedef int (*g_fopen)(const char * cFileName, unsigned int iFileFlags, unsigned int iFileMode, unsigned int *ErrorNumber);
typedef void (*g_fclose)(int FileHandler, unsigned int *ErrorNumber);
typedef void (*g_fflush)(int FileHandler, unsigned int *ErrorNumber);
typedef unsigned int (*g_lseek)(int FileHandler, unsigned int offset, unsigned int origin, unsigned int *ErrorNumber);
typedef void (*g_fread)(int FileHandler, const char *cBuffer, int iByteCount, unsigned int *ErrorNumber);
typedef void (*g_fwrite)(int FileHandler, const char * cBuffer, int iByteCount, unsigned int *ErrorNumber);
typedef void (*g_SetFileSize)(int FileHandler, unsigned int iNewFileSize, unsigned int *ErrorNumber);
typedef int (*g_OpenReadCloseFile)(char *cFilename, char **cFileData);
typedef int (*g_mkdir)(unsigned int runinbackgnd, char * cDirectory, unsigned int *iError);

//misc
typedef void (*g_SwitchPhoneOff)(void);
typedef int (*g_PlaySoundLoop)(unsigned int iSoundID, unsigned int unknown1, unsigned int LoopCount);
typedef void (*g_editOrNewTXTModule)(struct WString* swsFilename);
typedef void (*g_AlarmClockRing)(void);

#endif 
//_X65_h_