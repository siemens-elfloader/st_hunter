// keypadlight proto2 a0800500

#define M65v50

#include "..\shared\x65.h"

#ifdef M65v50
	#define _DrawImg_ (0xA16341BC+1)
	#define _PicturePaint_ (0xA16341BC+1)
	#define _DrawMainscreen_ (0xA163B09C+1)
	#define _GetImageWidth_ (0xA114E024+1)
	#define _GetProfile_ (0xA08C9FE4+1)
	#define _NetData_ 0xA867B0A0
	#define _VarROM_  0xA16E00E4
	#define _Sprintf_ 0xA153E501
	#define _PlaySoundLoop_ 0xA0935CF8 
	#define _SwitchPhoneOff_ 0xA1240938

	#define NETDataAddress 0xA867B0A0
	
	#define _VarRAM_   0xA8000200



#endif

g_SwitchPhoneOff SwitchPhoneOff = (g_SwitchPhoneOff) 0xAABBCCDD;
/*





GetImageWidth getimagewidth = (GetImageWidth) _GetImageWidth_;

typedef void (*g_DrawMainscreen)(void);
g_DrawMainscreen DrawMainscreen = (g_DrawMainscreen) _DrawMainscreen_;
*/

// f_sprintf sprintf = (f_sprintf) _Sprintf_;

//typedef void (*g_PlaySoundLoop)(unsigned int iSoundID, unsigned int unknown1, unsigned int LoopCount);
//g_PlaySoundLoop PlaySoundLoop = (g_PlaySoundLoop) _PlaySoundLoop_;

//typedef int (*g_GetProfile)(void);
g_GetProfile GetProfile = (g_GetProfile) _GetProfile_;

struct VarRam{
	byte state, profile_last, repeat;
};

/*
void copystrtowstr(char *src, unsigned short *dest, unsigned int*count) {
	while(*src != 0) {
		*dest++ = *src++;
		*count += 1;
	}	
}

*/
void Custom_Format(struct WString* pws) {

struct VarRam* varRam = (struct VarRam *) _VarRAM_;

byte ProfileKplDisabled[8], profile_now, profilestate_now;

ProfileKplDisabled[0]=0x11;
ProfileKplDisabled[1]=0x22;
ProfileKplDisabled[2]=0x33;
ProfileKplDisabled[3]=0x44;
ProfileKplDisabled[4]=0x55;
ProfileKplDisabled[5]=0x66;
ProfileKplDisabled[6]=0x77;
ProfileKplDisabled[7]=0x88;

profile_now=GetProfile();
profilestate_now=ProfileKplDisabled[profile_now];

if (profile_now != varRam->profile_last){
	if (profilestate_now != varRam->state ) {
		if (profilestate_now) {
			varRam->state=1;  
		} else {
			varRam->repeat=0x99;
		}
	}
		

}

if (varRam->repeat) {
	varRam->repeat--;
	if (!varRam->repeat) varRam->state = 0;
}

varRam->profile_last=profile_now;

if (varRam->state) SwitchPhoneOff();

}




/*
void entryMainscreen(struct WString* pws) {
	Custom_Format(pws);
	return;
} */