// keypadlight proto1a a0800400

#define M65v50

#include "..\shared\x65.h"

#ifdef M65v50
	#define _DrawImg_ (0xA16341BC+1)
	#define _PicturePaint_ (0xA16341BC+1)
	#define _DrawMainscreen_ (0xA163B09C+1)
	#define _GetImageWidth_ (0xA114E024+1)
	#define _GetProfile_ (0xA08C9FE4+1)
	#define _NetData_ 0xA867B0A0
	#define _VarROM_  0xA16E00E4
	#define _Sprintf_ 0xA153E501
	#define _PlaySoundLoop_ 0xA0935CF8 
	#define _SwitchPhoneOff_ 0xA1240938

	#define NETDataAddress 0xA867B0A0
	
	#define _VarRAM_   0xA8000200
	
	#define _KeypadlightControl_ 0xA0BC78B8



#endif
/*

g_SwitchPhoneOff SwitchPhoneOff = (g_SwitchPhoneOff) _SwitchPhoneOff_;

typedef int (*g_GetProfile)(void);
g_GetProfile GetProfile = (g_GetProfile) _GetProfile_;

GetImageWidth getimagewidth = (GetImageWidth) _GetImageWidth_;

typedef void (*g_DrawMainscreen)(void);
g_DrawMainscreen DrawMainscreen = (g_DrawMainscreen) _DrawMainscreen_;
*/

// f_sprintf sprintf = (f_sprintf) _Sprintf_;

//typedef void (*g_PlaySoundLoop)(unsigned int iSoundID, unsigned int unknown1, unsigned int LoopCount);
g_PlaySoundLoop PlaySoundLoop = (g_PlaySoundLoop) _PlaySoundLoop_;

//typedef void (*f_KeypadlightControl)(unsigned int kpl);
//f_KeypadlightControl KeypadlightControl = (f_KeypadlightControl) _KeypadlightControl_;

g_GetProfile GetProfile = (g_GetProfile) _GetProfile_;

/*struct VarRam{
	dword dw1 ;
}; */

/*
void copystrtowstr(char *src, unsigned short *dest, unsigned int*count) {
	while(*src != 0) {
		*dest++ = *src++;
		*count += 1;
	}	
}

*/
void Custom_Format(struct WString* pws) {
byte i;
//byte const profilemode[7]={0x11,0x22,0x33,0x44,0x55,0x66,0x77};

//struct VarRam* varRam = (struct VarRam *) _VarRAM_;

i=GetProfile();

PlaySoundLoop(i,2,3);



//varRam->dw1=i;

/*PlaySoundLoop(0x36,2,1);

varRam->b = 1 - varRam->b;

if (varRam->b) {
	PlaySoundLoop(0x2f,2,4);
	KeypadlightControl(0xBB8);
}*/

// varRam->dw1 = 0x9999;
//	KeypadlightControl(varRam->dw1);

//if (!i) PlaySoundLoop(0x1c,2,6);

}

/*
void entryMainscreen(struct WString* pws) {
	Custom_Format(pws);
	return;
} */