#include "..\inc\cfg_items.h"
#include "..\inc\swilib.h"
#include "language.h"

#ifdef NEWSGOLD
#define DEFAULT_DISK "4"
#else
#define DEFAULT_DISK "0"
#endif

__root const CFG_HDR cfghdr0={CFG_CBOX,LGP_CFG_HELLO_MESSAGE,0,2};
__root const unsigned int HELLO_MESSAGE=1;
__root const CFG_CBOX_ITEM cfgcbox0[]={LGP_CFG_NO,LGP_CFG_YES};

__root const CFG_HDR cfghdr0_0={CFG_KEYCODE,LGP_CFG_CALL_BUTTON,0,65535};
__root const unsigned int CALL_BUTTON=1;

__root const CFG_HDR cfghdr0_1={CFG_CBOX,LGP_CFG_ACTIVATION_STYLE,0,2};
__root const unsigned int ACTIVE_KEY_STYLE=0;
__root const CFG_CBOX_ITEM cfgcbox0_1[]={LGP_CFG_SHORT_PRESS,LGP_CFG_LONG_PRESS};
/*
__root const CFG_HDR cfghdr0_2={CFG_CBOX,LGP_CFG_UNLOCK_KBD,0,2};
__root const unsigned int UNLOCK_KBD=0;
__root const CFG_CBOX_ITEM cfgcbox0_2[]={LGP_CFG_NO,LGP_CFG_YES};
*/
__root const CFG_HDR cfghdr0_3={CFG_UINT,LGP_CFG_ILLU_POWER,0,100};
__root const unsigned int ILLU_POWER=0;

