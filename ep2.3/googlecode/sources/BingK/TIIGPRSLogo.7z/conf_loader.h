
#ifndef _CONFLOADER_H_
  #define _CONFLOADER_H_

int InitConfig(void);

#endif
