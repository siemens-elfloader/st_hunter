#include "..\inc\swilib.h"
#include "main.h"
extern int codepage;
extern int id_ed;
extern int id_ed2;
extern char file[256];
extern char exe_name[];
extern int curpos;
extern int atoi(char *attr);
extern void *about();

extern const char per_d[];
extern const char per_t[];
extern const char per_s[];
extern const char empty_str[];
const char per_2s[]="%s%s";
extern const char IMG_PATH[64];
extern const char HIST_PATH[128];
extern void ShowBookmarks(void);
extern int LoadBookmark();
extern void UpdateCSMname();
void ShowMenuLast(void);
void LoadHist();

//------------------------MENU-------------------------
extern int id_ed;
int last_id;
int MenuCode_id;
int item=7;//c������ ������� ����
int code=5;//Codepage
int go_to_item=4;//c������ ������� ��� Go to...
int last_item=0;//������� ���� �������...

char *name[]={
  "������� ����",
  "���������",
  "������� �...",
  "���������",
  "���������",
  "�� �����",
  "�����"
};
char *name_codepage[]={
  "win1251",
  "utf8",
  "koi8",
  "ascii",
  "win1250(?)"
};
char *go_to_str[]={
  "������",
  "�����",
  "�����...",
  "��������"
};

 char ICON0[128];//���� � ������� ����
 char ICON1[128];//"\\open.png";//���� � �������
 char ICON2[128];//"\\arrow.png";
 char ICON3[128];//"\\goto.png";
 char ICON4[128];//"\\save.png";
 char ICON5[128];//"\\options.png";
 char ICON6[128];//"\\about.png";
 char ICON7[128];//"\\quit.png";
 char NO_ICON[128];//"\\no_icon.png";
 char ICON8[128];
 char ICON9[128];
 char ICON10[128];
 char ICON11[128];
 char ICON12[128];
 char ICON13[128];
 char ICON14[128];
 char ICON15[128];

int S_ICONS[16]={
(int)ICON0,
(int)ICON1,
(int)ICON2,
(int)ICON3,
(int)ICON4,
(int)ICON5,
(int)ICON6,
(int)ICON7,
(int)ICON8,
(int)ICON9,
(int)ICON10,
(int)ICON11,
(int)ICON12,
(int)ICON13,
(int)ICON14,
(int)NO_ICON
};


//---------------------������� ������-----------------------
void bm_menu_iconhnd(void *data, int curitem, void *unk);
const int menusoftkeys[]={0,1,2};

const SOFTKEY_DESC menu_sk2[]=
{
  {0x0001,0x0000,(int)"�������"},
  {0x0004,0x0000,(int)"�������"},
  {0x003D,0x0000,(int)LGP_DOIT_PIC}
};

const SOFTKEYSTAB menu_skt2=
{
  menu_sk2,0
};

void bm_menu_ghook(void *data, int cmd){};
int bm_menu_onkey2(void *data, GUI_MSG *msg);
const HEADER_DESC bm_menuhdr2={0,0,131,21,NULL,(int)"����",LGP_NULL};
const MENU_DESC bmmenu=
{
  8,bm_menu_onkey2,bm_menu_ghook,NULL,
  menusoftkeys,
  &menu_skt2,
  0x11,//0x11,
  bm_menu_iconhnd,
  NULL,   //Items
  NULL,   //Procs
  0   //n
};
void bm_menu_iconhnd(void *data, int curitem, void *unk)
{
  WSHDR *ws;
  char *s;
  void *item=AllocMenuItem(data);
  s=malloc(1024);
  sprintf(s,per_s,name[curitem]);
  if (s)
  {
    if (strlen(s))
    { 
      ws=AllocMenuWS(data,1024);
      wsprintf(ws,per_t,s);
    }
    else 
    { 
      ws=AllocMenuWS(data,10);
      wsprintf(ws,per_t,"��� �����");
    }
  }
  else  
  {
    ws=AllocMenuWS(data,10);
    wsprintf(ws,"error");
    wsInsertChar(ws,2,1);//���� ��������

  }
   SetMenuItemIconArray(data,item,S_ICONS + curitem + 1);
   SetMenuItemText(data,item,ws,curitem);
   mfree(s);
}

void ShowMenu(void)
{ 
 snprintf(ICON1,127,per_2s,IMG_PATH,"\\open.png");
 sprintf(ICON2,per_2s,IMG_PATH,"\\arrow.png");
 sprintf(ICON3,per_2s,IMG_PATH,"\\goto.png");
 sprintf(ICON4,per_2s,IMG_PATH,"\\save.png");
 sprintf(ICON5,per_2s,IMG_PATH,"\\options.png");
 sprintf(ICON6,per_2s,IMG_PATH,"\\about.png");
 sprintf(ICON7,per_2s,IMG_PATH,"\\quit.png");
 sprintf(NO_ICON,per_2s,IMG_PATH,"\\no_icon.png");
 patch_header2(&bm_menuhdr2);
 CreateMenu(0,0,&bmmenu,&bm_menuhdr2,0,item,0,0);
}
//==============================


void ShowMenuGoTo(void);
int bm_menu_onkey2(void *data, GUI_MSG *msg)
{
  int i;
  i=GetCurMenuItem(data);
  int k=msg->gbsmsg->submess;
 if(msg->keys==0x14)
   {
     about();
     return (-1);
   }
  if (k==ENTER_BUTTON || k==LEFT_SOFT)
  {
    switch(i)
      {
        case 0:  open_fm();break;
        case 1: 
          LoadHist();
          ShowMenuLast();
          break;
        case 2:  ShowMenuGoTo(); break;
        case 3:  SaveFile(file); break;
        case 4:  start("0:\\zbin\\etc\\TextReader.bcfg"); break;
        case 5:  about(); ShowMenu();break;
        case 6:  
            GeneralFunc_flag1(id_ed,1);
            GeneralFunc_flag1(MenuCode_id,1);
            GeneralFunc_flag1(last_id,1);
            break;
      }
    return(1);
  }
 if(k==RIGHT_SOFT || k==RED_BUTTON)
 {
   GeneralFunc_flag1(id_ed,1);
   GeneralFunc_flag1(MenuCode_id,1);
   GeneralFunc_flag1(last_id,1);
 }
  return(0);
}

//------------------------------ ����� ���������----------------------------

void codepage_iconhnd(void *data, int curitem, void *unk);
const int menusoftkeys_codepage[]={0,1,2};

const SOFTKEY_DESC menu_sk_codepage[]=
{
  {0x0001,0x0000,(int)"�������"},
  {0x0004,0x0000,(int)"�������"},
  {0x003D,0x0000,(int)LGP_DOIT_PIC}
};

const SOFTKEYSTAB menu_skt_codepage=
{
  menu_sk_codepage,0
};

void codepage_ghook(void *data, int cmd){};
int codepage_onkey(void *data, GUI_MSG *msg);
HEADER_DESC codepage_menuhdr={0,0,131,21,NULL,(int)"���������...",LGP_NULL};

const MENU_DESC codepage_menu=
{
  8,codepage_onkey,codepage_ghook,NULL,
  menusoftkeys_codepage,
  &menu_skt_codepage,
  0x11,//0x11,
  codepage_iconhnd,
  NULL,   //Items
  NULL,   //Procs
  0   //n
};

void codepage_iconhnd(void *data, int curitem, void *unk)
{
  WSHDR *ws;
  char *s;
  void *item=AllocMenuItem(data);
  s=malloc(1024);
  sprintf(s,per_s,name_codepage[curitem]);
  if (s)
  {
    if (strlen(s))
    { 
      ws=AllocMenuWS(data,1024);
      wsprintf(ws,per_t,s);
    }
  }
  else
  {
    ws=AllocMenuWS(data,10);
    wsprintf(ws,"error");
    wsInsertChar(ws,2,1);//���� ��������

  }
  SetMenuItemText(data,item,ws,curitem);
  mfree(s);
}

int ShowMenuCode()
{ 
  patch_header2(&codepage_menuhdr);
  return MenuCode_id=CreateMenu(0,0,&codepage_menu,&codepage_menuhdr,0,code,0,0);

 }

int codepage_onkey(void *data, GUI_MSG *msg)
{
  int i;
  i=GetCurMenuItem(data);
  int k=msg->gbsmsg->submess;
  
  if (k==ENTER_BUTTON || k==LEFT_SOFT)
  {
    switch(i)
     {
        case 0: codepage=0; GeneralFunc_flag1(id_ed,1); DrawText(file,codepage);  break;//win1251      
        case 1: codepage=1; GeneralFunc_flag1(id_ed,1); DrawText(file,codepage);  break;//utf8
        case 2: codepage=2; GeneralFunc_flag1(id_ed,1); DrawText(file,codepage);  break;//koi8
        case 3: codepage=3; GeneralFunc_flag1(id_ed,1); DrawText(file,codepage);  break;//ascii
        case 4: codepage=4; GeneralFunc_flag1(id_ed,1); DrawText(file,codepage);  break;//win1250
     }    
  return(0);
  }
 if(k==RIGHT_SOFT || k==RED_BUTTON)
   GeneralFunc_flag1(MenuCode_id,1);
 
return(0);
}


//-----------------------------menu GO TO...---------------------------

void go_to_iconhnd(void *data, int curitem, void *unk);
void go_to_ghook(void *data, int cmd){};
int go_to_onkey2(void *data, GUI_MSG *msg)
{
  int i;
  i=GetCurMenuItem(data);
  int k=msg->gbsmsg->submess;
  
  if (k==ENTER_BUTTON || k==LEFT_SOFT)
  {
    switch(i)
      {
         case 0:
            curpos=1;
            GeneralFunc_flag1(id_ed,1);
            DrawText(file,codepage);
            break;//� ������
         case 1:
            curpos=0;
            GeneralFunc_flag1(id_ed,1);
            DrawText(file,codepage);
            break;//� �����
         case 2:
           GeneralFunc_flag1(id_ed,1);
           pos();
           break;//�������
         case 3:
           ShowBookmarks();
           break;
      }
    return(1);
  }
  return(0);
}
const HEADER_DESC go_to_menuhdr2={0,0,131,21,NULL,(int)"������� �...",LGP_NULL};
const MENU_DESC go_to_menu=
{
  8,go_to_onkey2,go_to_ghook,NULL,
  menusoftkeys,
  &menu_skt2,
  0x10,
  go_to_iconhnd,
  NULL,   //Items
  NULL,   //Procs
  0   //n
};

void go_to_iconhnd(void *data, int curitem, void *unk)
{
  WSHDR *ws;
  char *s;
  void *item=AllocMenuItem(data);
  s=malloc(1024);
  sprintf(s,per_s,go_to_str[curitem]);
  if (s)
  {
    if (strlen(s))
    { 
      ws=AllocMenuWS(data,1024);
      wsprintf(ws,per_t,s);
    }
    else 
    {
      ws=AllocMenuWS(data,10);
      wsprintf(ws,"no name!");
    }
  }
  else
  {
    ws=AllocMenuWS(data,10);
    wsprintf(ws,"error");
    wsInsertChar(ws,2,1);//���� ��������
  }
  SetMenuItemText(data,item,ws,curitem);
  mfree(s);
}

void ShowMenuGoTo(void)
{ 
   patch_header2(&go_to_menuhdr2);
   CreateMenu(0,0,&go_to_menu,&go_to_menuhdr2,0,go_to_item,0,0);
}
//-----------------------------menu LAST OPEN...---------------------------
//�� �� � ������� ���,��� �������....� ����� ������� ��....
typedef struct
{
 char name[64];
}LAST;

LAST last_op[200];

int RunHST(char *file)//������ � ����� ���� ��� �������:)
{
  if (file)
  {
    if (strlen(file))
    {
      WSHDR *ws;
      ws=AllocWS(150);
      str_2ws(ws,exe_name,128);
      ExecuteFile(ws,0,file);
      FreeWS(ws);
      return(1);
    }
  }
  return(0);
}
char ff[128];//���� � ����� �� �������, ������ ����� ��� ����� ��������� �� ������ "���������..."
void LoadHST(int curitem)//������ ���� � ����� �� ����� �������.
{
  unsigned int err; 
  int f; 
  char *mem;
  char path[256];//="0:\\zbin\\TextReader\\history\\";
  sprintf(path,per_s,HIST_PATH);
  strcat(path,last_op[curitem].name);
  f = fopen(path, A_ReadOnly + A_BIN, P_READ, & err ); 
  if ( f==-1 ) 
   {
    curpos=1;
    fclose( f, & err ); 
    return; 
   }
 mem=malloc(256); 
 char *str=malloc(256); 
 int size=fread(f,mem,256,&err); 
 int i=0;
 while (((*(mem+i)!=' '))&&(i<size)) {ff[i]=*(mem+i);i++;}    //������ ������ �� ����� 
 ff[i++]=0;
fclose(f,&err); 
mfree(mem); 
}
char *ss;
void last_iconhnd(void *data, int curitem, void *unk);
void last_ghook(void *data, int cmd){};
int last_onkey2(void *data, GUI_MSG *msg)
{
  int i;
  i=GetCurMenuItem(data);
  int k=msg->gbsmsg->submess;
  
  if(k==GREEN_BUTTON) //������� � ����� ����
  {
    GeneralFunc_flag1(last_id,1);
    LoadHST(i);
    RunHST(ff);   
  }
  
  if(k==ENTER_BUTTON) //������� � ������� ����, ��� ���������� �������!!!
  {
    LoadHST(i);
    GeneralFunc_flag1(id_ed,1);
    GeneralFunc_flag1(last_id,1);
    DrawText(ff,0);
  }
  ss=malloc(128);
  if(k=='#')
  {    
    LoadHST(i);
    sprintf(ss,"���� � �����: %s",ff);
    ShowMSG(2,(int)ss);
  }

  return(0);
}
const HEADER_DESC last_menuhdr2={0,0,131,21,NULL,(int)"���������...",LGP_NULL};
const MENU_DESC last_menu=
{
  8,last_onkey2,last_ghook,NULL,
  menusoftkeys,
  &menu_skt2,
  0x10,//0x11,
  last_iconhnd,
  NULL,   //Items
  NULL,   //Procs
  0   //n
};

void last_iconhnd(void *data, int curitem, void *unk)
{
  WSHDR *ws;
  char *s;
  void *item=AllocMenuItem(data);
  s=malloc(1024);
  LoadHST(curitem);
  sprintf(s,per_s,ff);
  if (s)
  {
    if (strlen(s))
    { 
      ws=AllocMenuWS(data,1024);
      wsprintf(ws,"%d.%s",curitem+1,s);
    }
  }
  else
  {
    ws=AllocMenuWS(data,10);
    wsprintf(ws,"error");
    wsInsertChar(ws,2,1);//���� ��������

  }
   SetMenuItemText(data,item,ws,curitem);
  mfree(s);
}

void ShowMenuLast(void)
{ 
   patch_header2(&last_menuhdr2);
   last_id=CreateMenu(0,0,&last_menu,&last_menuhdr2,0,last_item,0,0);
}

void LoadHist()//���� ��� ����� �������.
{
   DIR_ENTRY de;
   unsigned int err;
  // int f; 
  // char *mem;
   char *str=malloc(256); 
   char path[256];//="0:\\zbin\\TextReader\\history\\";
   sprintf(path,per_s,HIST_PATH);
//   ShowMSG(1,(int)path);
   char *ptr=path+strlen(path)+1;
   strcat(path,"*.hst");
   if (FindFirstFile(&de,path,&err))
      { 
       do{
          strcpy(ptr,de.file_name);  
          strcpy(last_op[last_item].name,de.file_name);
          last_item++;
         }while(FindNextFile(&de,&err));
      }FindClose(&de,&err);
}
