#include "..\inc\swilib.h"
#include "main.h"
extern unsigned long  strtoul (const char *nptr,char **endptr,int base);
extern char file[256];
 int curpos;
extern int atoi(char *attr);
extern const char per_d[];
extern const char per_t[];
extern const char per_s[];
extern const char empty_str[];
//extern int file_size;
//-----------------LOAD INI-------------------
/*
format
path /codepage/ position
*/
typedef struct
{
  char name[256];
  unsigned int codepage;
  unsigned int pos;
}INIFILE;

INIFILE ini[200];//����� ������� �� 200 ������ ������:)

int ini_item=0;

void process(char *str, int n)//������ ������ � ��������� ����
{ 
  int j=0; 
  int k=0;
  char pos[5];
  while (str[j]!=' ') {ini[n].name[k]=str[j];k++;j++;}    
  j++;
  k=0;
  //while (str[j]!=' ')
//  pos[0]==str[j];//�������������� ����� ���������, ����� ����������)))
 // codepage=ini[n].codepage=strtoul(pos,0,10);
 // j++;
  while (/*str[j]!='\n'*/j<=strlen(str)) {pos[k]=str[j];k++;j++;}
  ini[n].pos=strtoul(pos,0,10);
  if(ini[n].pos==0)//����� �� ���������� � ����� ����� ���� ������ �����������
  {
    curpos=1;
    ini[n].pos=1;
  }
//  ShowMSG(1,(int)ini[0].name);
}

void LoadINI()
{
  unsigned int err; 
  int plhandle; 
  char *mem;
  char *pos;
  int i,j=0; 
  char *str; 
  int size;
  plhandle = fopen( "0:\\TR_history2.txt", A_ReadOnly + A_BIN, P_READ, & err ); 
 if ( plhandle==-1 ) 
  {
//    ShowMSG(1,(int)"Can't open TR_history");
    curpos=1;
    fclose( plhandle, & err ); 
    return; 
  }
  mem=malloc(10000); 
  size=fread(plhandle,mem,9999,&err); 
  pos=strstr(mem,file)+strlen(file)+1;
  curpos=atoi(pos);  
  str=malloc(256); 
 if ((mem!=0)&&(str!=0)) 
  { 
    //size=fread(f,mem,9999,&err); 
    i=0; 
    while (i<size) //���� �� ����� ����� 
    { 
      //strcpy(str,""); 
      j=0; 
      while (((*(mem+i)!='\n'))&&(i<size)) {*(str+j)=*(mem+i); j++;i++;}    //������ ������ �� ����� 
      //strcat(str,"\n");
      process(str,ini_item);
      i++; 
      ini_item++;
    }
  }

fclose(plhandle,&err); 
mfree(mem); 
mfree(str);
}


void SaveINI()//save history
{
  unsigned int err; 
  int f; 
 // char *mem;
  int cmp;
  int ch=0;
  int i;
  char *s=malloc(7);
  char *ss=malloc(300);
  unlink("0:\\TR_history2.txt",&err);
 f = fopen( "0:\\TR_history2.txt", A_ReadWrite + A_BIN+A_Create+A_Append, P_READ + P_WRITE, & err );
 if ( f ==-1 ) 
  {
    fclose( f, & err ); 
    return; 
  }
  if(ini_item!=0)
  {
     for(i=0;i<ini_item;i++)
      {
        cmp=strcmp(ini[i].name,file);
        if(cmp==0)
          {
            ch=1;
            //strcpy(ini[i].name,file);
            ini[i].pos=curpos;
            sprintf(s,"CMP %d %d",ini[i].pos,i);
            ShowMSG(1,(int)s);
            //break;
            i=ini_item;
          }
       }
  }
  if(ch==0)
  {
    sprintf(ini[ini_item].name,per_s,file);
    ini[ini_item].pos=curpos;
    ShowMSG(1,(int)"ch==0");
  }

if(ini_item!=0)
 {
  for(i=0;i<=ini_item;i++)
     {
       sprintf(ss,"%s %i\n",ini[i].name,ini[i].pos);
       fwrite(f,ss,strlen(ss),&err);
     //fwrite(f,ini[i].name,strlen(ini[i].name),&err);
     //fwrite(f," ",1,&err);
     //strcpy(s,empty_str);
     //sprintf(s,"%u",ini[i].pos);
     //fwrite(f,s,strlen(s),&err);
     //fwrite(f,"\n",0x1,&err);
     }
 }
 else if(ini_item==0)
        {
          fwrite(f,file,strlen(file),&err);
          fwrite(f," ",1,&err);
          strcpy(s,empty_str);
          sprintf(s,"%u",curpos);
          fwrite(f,s,strlen(s),&err);
          fwrite(f,"\n",0x1,&err);
         }
fclose(f,&err); 
ShowMSG(1,(int)"hist save!");
mfree(ss);
}

void FreeINI()
{
  for(int i=0;i<=ini_item;i++)
      mfree(ini[i].name);
}
