#include "..\inc\swilib.h"
#include "main.h"
extern int codepage;
extern int id_ed;
extern int id_ed2;
extern char file[256];
extern int curpos;
extern int atoi(char *attr);
//extern int Quit_Required;
extern const int codepg;//��������� �� ���������
extern void *about();
extern int ReadOnly;
extern int Quit_Required;
extern int level;

extern const char per_d[];
extern const char per_t[];
extern const char per_s[];
extern const char empty_str[];

extern void ShowBookmarks(void);
extern int LoadBookmark();
//extern int bm_item;
//------------------------MENU-------------------------

int item=7;//c������ ������� ����
int code=5;//Codepage
int go_to_item=4;//c������ ������� ��� Go to...
char *name[]={"Select File","Edit","Go to...","Save File","Setting","About","Quit"};
char *name_codepage[]={"win1251","utf8","koi8","ascii","win1250(?)"};
char *go_to_str[]={"Start","End","line...","Bookmarks"};

const char ICON0[128];//���� � �������
#ifdef NEWSGOLD
const char ICON1[128]="4:\\zbin\\TextReader\\img\\open.png";//���� � �������
const char ICON2[128]="4:\\zbin\\TextReader\\img\\edit.png";
const char ICON3[128]="4:\\zbin\\TextReader\\img\\goto.png";
const char ICON4[128]="4:\\zbin\\TextReader\\img\\save.png";
const char ICON5[128]="4:\\zbin\\TextReader\\img\\options.png";
const char ICON6[128]="4:\\zbin\\TextReader\\img\\about.png";
const char ICON7[128]="4:\\zbin\\TextReader\\img\\quit.png";
const char NO_ICON[128]="4:\\shell\\icons\\no_icon.png";
#else
const char ICON1[128]="0:\\zbin\\TextReader\\img\\open.png";//���� � �������
const char ICON2[128]="0:\\zbin\\TextReader\\img\\edit.png";
const char ICON3[128]="0:\\zbin\\TextReader\\img\\goto.png";
const char ICON4[128]="0:\\zbin\\TextReader\\img\\save.png";
const char ICON5[128]="0:\\zbin\\TextReader\\img\\options.png";
const char ICON6[128]="0:\\zbin\\TextReader\\img\\about.png";
const char ICON7[128]="0:\\zbin\\TextReader\\img\\quit.png";
const char NO_ICON[128]="0:\\shell\\icons\\no_icon.png";
#endif
const char ICON8[128];
const char ICON9[128];
const char ICON10[128];
const char ICON11[128];
const char ICON12[128];
const char ICON13[128];
const char ICON14[128];
const char ICON15[128];

int S_ICONS[16]={
(int)ICON0,
(int)ICON1,
(int)ICON2,
(int)ICON3,
(int)ICON4,
(int)ICON5,
(int)ICON6,
(int)ICON7,
(int)ICON8,
(int)ICON9,
(int)ICON10,
(int)ICON11,
(int)ICON12,
(int)ICON13,
(int)ICON14,
(int)NO_ICON
};

//WSHDR *ws=NULL;
int name_cl=7;//���� ���� ��������
int description_cl=4;//���� �������� ��������

volatile int contactlist_menu_id;
unsigned int *ErrorNumber;

//---------------------������� ������-----------------------
void bm_menu_iconhnd(void *data, int curitem, void *unk);
const int menusoftkeys[]={0,1,2};

const SOFTKEY_DESC menu_sk2[]=
{
  {0x0001,0x0000,(int)"Select"},
  {0x0004,0x0000,(int)"Close"},
  {0x003D,0x0000,(int)LGP_DOIT_PIC}
};

const SOFTKEYSTAB menu_skt2=
{
  menu_sk2,0
};

void bm_menu_ghook(void *data, int cmd){};
int bm_menu_onkey2(void *data, GUI_MSG *msg);
const HEADER_DESC bm_menuhdr2={0,0,131,21,NULL,(int)"Menu",LGP_NULL};
const MENU_DESC bmmenu=
{
  8,bm_menu_onkey2,bm_menu_ghook,NULL,
  menusoftkeys,
  &menu_skt2,
  0x11,//0x11,
  bm_menu_iconhnd,
  NULL,   //Items
  NULL,   //Procs
  0   //n
};
void bm_menu_iconhnd(void *data, int curitem, void *unk)
{
  WSHDR *ws;
  char *s;
  void *item=AllocMenuItem(data);
  s=malloc(1024);
  sprintf(s,per_s,name[curitem]);
  if (s)
  {
    if (strlen(s))
    { 
      ws=AllocMenuWS(data,1024);
      wsprintf(ws,per_t,s);
    }
  }
  else
  {
    ws=AllocMenuWS(data,10);
    wsprintf(ws,"error");
    wsInsertChar(ws,2,1);//���� ��������

  }
   SetMenuItemIconArray(data,item,S_ICONS + curitem + 1);
   SetMenuItemText(data,item,ws,curitem);
   mfree(s);
}

void ShowMenu(void)
{ 
   patch_header2(&bm_menuhdr2);
   CreateMenu(0,0,&bmmenu,&bm_menuhdr2,0,item,0,0);
}
//==============================


void ShowMenuGoTo(void);
int bm_menu_onkey2(void *data, GUI_MSG *msg)
{
  if(Quit_Required) return 1;
  int i;
  i=GetCurMenuItem(data);
  int k=msg->gbsmsg->submess;
 if(msg->keys==0x14)
   {
     about();
     return (-1);
   }
  if (k==ENTER_BUTTON || k==LEFT_SOFT)
  {
    switch(i)
      {
        case 0:  open_fm();break;
        case 1:  ReadOnly=!ReadOnly;GeneralFunc_flag1(id_ed,1);DrawText(file,codepage); break;
        case 2:  level=3;ShowMenuGoTo();break;
        case 3:  SaveFile(file); break;
        case 4:  start("0:\\zbin\\etc\\TextReader.bcfg");break;
        case 5:  about();break;
        case 6: /* MsgBoxYesNo(1,(int)"�������� TextReader?",QuitCallbackProc);*/
          Quit_Required=1;
          //SUBPROC((void *)Killer);
          break;
      }
    return(1);
  }
  return(0);
}

//------------------------------ ����� ���������----------------------------


void codepage_iconhnd(void *data, int curitem, void *unk);
const int menusoftkeys_codepage[]={0,1,2};

const SOFTKEY_DESC menu_sk_codepage[]=
{
  {0x0001,0x0000,(int)"Select"},
  {0x0004,0x0000,(int)"Close"},
  {0x003D,0x0000,(int)LGP_DOIT_PIC}
};

const SOFTKEYSTAB menu_skt_codepage=
{
  menu_sk_codepage,0
};

void codepage_ghook(void *data, int cmd){};
int codepage_onkey(void *data, GUI_MSG *msg);
HEADER_DESC codepage_menuhdr={0,0,131,21,NULL,(int)"Codepage",LGP_NULL};

const MENU_DESC codepage_menu=
{
  8,codepage_onkey,codepage_ghook,NULL,
  menusoftkeys_codepage,
  &menu_skt_codepage,
  0x11,//0x11,
  codepage_iconhnd,
  NULL,   //Items
  NULL,   //Procs
  0   //n
};

void codepage_iconhnd(void *data, int curitem, void *unk)
{
  WSHDR *ws;
  char *s;
  void *item=AllocMenuItem(data);
  s=malloc(1024);
  sprintf(s,per_s,name_codepage[curitem]);
  if (s)
  {
    if (strlen(s))
    { 
      ws=AllocMenuWS(data,1024);
      wsprintf(ws,per_t,s);
    }
  }
  else
  {
    ws=AllocMenuWS(data,10);
    wsprintf(ws,"error");
    wsInsertChar(ws,2,1);//���� ��������

  }
  SetMenuItemText(data,item,ws,curitem);
  mfree(s);
}

int ShowMenuCode()
{ 
  patch_header2(&codepage_menuhdr);
  return CreateMenu(0,0,&codepage_menu,&codepage_menuhdr,0,code,0,0);

 }

int codepage_onkey(void *data, GUI_MSG *msg)
{
  int i;
  i=GetCurMenuItem(data);
  int k=msg->gbsmsg->submess;
  if (k==ENTER_BUTTON || k==LEFT_SOFT)
  {
  switch(i)
  {
    case 0: codepage=0; GeneralFunc_flag1(id_ed,1); DrawText(file,codepage);  break;//win1251      
    case 1: codepage=1; GeneralFunc_flag1(id_ed,1); DrawText(file,codepage);  break;//utf8
    case 2: codepage=2; GeneralFunc_flag1(id_ed,1); DrawText(file,codepage);  break;//koi8
    case 3: codepage=3; GeneralFunc_flag1(id_ed,1); DrawText(file,codepage);  break;//ascii
    case 4: codepage=4; GeneralFunc_flag1(id_ed,1); DrawText(file,codepage);  break;//win1250
  }    
  return(1);
 }
return(0);
}


//-----------------------------menu GO TO...---------------------------

void go_to_iconhnd(void *data, int curitem, void *unk);
void go_to_ghook(void *data, int cmd){};
int go_to_onkey2(void *data, GUI_MSG *msg)
{
  int i;
  i=GetCurMenuItem(data);
  int k=msg->gbsmsg->submess;
  if (k==ENTER_BUTTON || k==LEFT_SOFT)
  {
    switch(i)
      {
         case 0:
            curpos=1;
            GeneralFunc_flag1(id_ed,1);
            DrawText(file,codepg);
            break;//� ������
         case 1:
            curpos=0;
            GeneralFunc_flag1(id_ed,1);
            DrawText(file,codepg);
            break;//� �����
         case 2:
           GeneralFunc_flag1(id_ed,1);
           pos();
           break;//�������
         case 3:
//           LoadBookmark();
   //        Menu_SetItemCountDyn(data,LoadBookmark());
     //      SetCursorToMenuItem(data, 0);
       //    RefreshGUI();
           ShowBookmarks();
           break;
      }
    return(1);
  }
  return(0);
}
const HEADER_DESC go_to_menuhdr2={0,0,131,21,NULL,(int)"Go to...",LGP_NULL};
const MENU_DESC go_to_menu=
{
  8,go_to_onkey2,go_to_ghook,NULL,
  menusoftkeys,
  &menu_skt2,
  0x11,//0x11,
  go_to_iconhnd,
  NULL,   //Items
  NULL,   //Procs
  0   //n
};

void go_to_iconhnd(void *data, int curitem, void *unk)
{
  WSHDR *ws;
  char *s;
  void *item=AllocMenuItem(data);
  s=malloc(1024);
  sprintf(s,per_s,go_to_str[curitem]);
  if (s)
  {
    if (strlen(s))
    { 
      ws=AllocMenuWS(data,1024);
      wsprintf(ws,per_t,s);
    }
  }
  else
  {
    ws=AllocMenuWS(data,10);
    wsprintf(ws,"error");
    wsInsertChar(ws,2,1);//���� ��������

  }
   SetMenuItemText(data,item,ws,curitem);
  mfree(s);
}

void ShowMenuGoTo(void)
{ 
   patch_header2(&go_to_menuhdr2);
   CreateMenu(0,0,&go_to_menu,&go_to_menuhdr2,0,go_to_item,0,0);
}
