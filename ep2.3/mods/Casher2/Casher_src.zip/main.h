
#define IMSI_DATA_BYTE_LEN  (9)

void StartHoursTimer(void);
