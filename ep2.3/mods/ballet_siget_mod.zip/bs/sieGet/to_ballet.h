void SendToBallet(char *name, int total, int recieved, int flag, char *filename);
