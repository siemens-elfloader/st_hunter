#ifndef _MEM_H_
#define _MEM_H_

#include "include.h"

class Buffer
{
public:
  Buffer();
  ~Buffer();
  int size;
  char *data;
  void Write(char *tdata, int tsize);
  void Clean();
private:
  int memsize;
};

#endif
