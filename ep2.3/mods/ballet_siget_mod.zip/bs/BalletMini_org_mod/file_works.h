void getSymbolicPath(char * path,const char * cFileName);
int ballet_fexists(const char * cFileName);
