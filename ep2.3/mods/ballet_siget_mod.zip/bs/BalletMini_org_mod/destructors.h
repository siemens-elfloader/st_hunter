void FreeREFCACHEentry(REFCACHE *p);
void FreeREFCACHEtotal(REFCACHE **t);
void FreeRawText(VIEWDATA *vd);
void FreeDynImgList(VIEWDATA *vd);
void FreeViewData(VIEWDATA *vd);






