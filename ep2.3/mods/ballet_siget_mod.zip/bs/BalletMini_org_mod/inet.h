void SmartREDRAW(void);
int ParseSocketMsg(GBS_MSG *msg);
void StartINET(const char *url, char *fncache);
void StopINET(void);







