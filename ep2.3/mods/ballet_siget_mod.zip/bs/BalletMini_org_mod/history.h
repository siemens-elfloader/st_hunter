void AddURLToHistory(const char *url);
void CheckHistory(const char *url);
char **GetHistory(int *cnt);
