#define wslen(ws) ws->wsbody[0]

int CreateMainMenu(VIEWDATA *vd);
int CreateInputUrl();
int CreateBookmarksMenu(char *dir);
