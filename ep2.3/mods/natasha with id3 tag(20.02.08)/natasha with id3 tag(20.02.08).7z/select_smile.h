#ifndef _SELECT_SMILE_H_
  #define _SELECT_SMILE_H_


int CreateSmileSelectGUI(EDCHAT_STRUCT *ed_struct);










#endif

