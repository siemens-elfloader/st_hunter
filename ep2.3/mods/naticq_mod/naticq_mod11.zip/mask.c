__root const CFG_HDR cfghdr6={CFG_LEVEL,"History",1,0};
    
    __root const CFG_HDR cfghdr_in_%d_%d={CFG_CHECKBOX,\"Enable vibra\",0,2};\n__root const int vibra_%d = 1;\n__root const CFG_HDR cfghdr_in_%d_%d={CFG_CHECKBOX,\"Enable sound\",0,2};\n__root const int sound_%d = 1;\n