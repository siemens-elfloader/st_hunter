char *ws2utf8(WSHDR *ws);
char *utf8_urlencode(char *s);
