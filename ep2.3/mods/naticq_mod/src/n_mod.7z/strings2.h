int convWS_to_ANSI(WSHDR *ws, char *buf);
