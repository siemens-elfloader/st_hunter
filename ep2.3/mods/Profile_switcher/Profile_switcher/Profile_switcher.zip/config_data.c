#include "..\inc\cfg_items.h"

__root const CFG_HDR cfghdr24={CFG_UINT,"100 %",0,100};
__root const unsigned int light0=5;

__root const CFG_HDR cfghdr25={CFG_UINT,"90-100 %",0,100};
__root const unsigned int light1=5;

__root const CFG_HDR cfghdr26={CFG_UINT,"80-90 %",0,100};
__root const unsigned int light2=5;

__root const CFG_HDR cfghdr27={CFG_UINT,"70-80 %",0,100};
__root const unsigned int light3=5;

__root const CFG_HDR cfghdr28={CFG_UINT,"60-70 %",0,100};
__root const unsigned int light4=5;

__root const CFG_HDR cfghdr29={CFG_UINT,"50-60 %",0,100};
__root const unsigned int light5=5;

__root const CFG_HDR cfghdr30={CFG_UINT,"40-50 %",0,100};
__root const unsigned int light6=5;

__root const CFG_HDR cfghdr31={CFG_UINT,"30-40 %",0,100};
__root const unsigned int light7=5;

__root const CFG_HDR cfghdr32={CFG_UINT,"20-30 %",0,100};
__root const unsigned int light8=5;

__root const CFG_HDR cfghdr33={CFG_UINT,"10-20 %",0,100};
__root const unsigned int light9=5;

__root const CFG_HDR cfghdr34={CFG_UINT,"<10 %",0,100};
__root const unsigned int light10=5;





