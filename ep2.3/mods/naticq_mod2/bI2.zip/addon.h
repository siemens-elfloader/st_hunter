#ifndef _ADDON_H_
  #define _NATICQ_H_
void CheckComand2(char *txt, CLIST *t);
void DoScreen();
#endif
