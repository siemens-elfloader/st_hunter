#include "..\inc\cfg_items.h"
__root const CFG_HDR cfghdr0={CFG_CBOX,"Long press",0,2};
__root const int LONG_P = 0;
__root const CFG_CBOX_ITEM cbox1[2]={"No","Yes"};

__root const CFG_HDR cfghdr1 = {CFG_INT, "Hotkey (dec)", 0, 255};
__root const int BTN = 0x15;

__root const CFG_HDR cfghdr2={CFG_CBOX,"Hello message",0,2};
__root const int ENA_HELLO = 0;
__root const CFG_CBOX_ITEM cfgcbox1[2]={"No","Yes"};

__root const CFG_HDR cfghdr_m11={CFG_LEVEL,"Names",1,0};

__root const CFG_HDR cfghdr1_1={CFG_STR_WIN1251,"Bookmark 1 name",1,31};
__root const char BMNAME1[32]="mc";

__root const CFG_HDR cfghdr1_2={CFG_STR_WIN1251,"Bookmark 2 name",1,31};
__root const char BMNAME2[32]="";

__root const CFG_HDR cfghdr1_3={CFG_STR_WIN1251,"Bookmark 3 name",1,31};
__root const char BMNAME3[32]="NatICQ";

__root const CFG_HDR cfghdr1_4={CFG_STR_WIN1251,"Bookmark 4 name",1,31};
__root const char BMNAME4[32]="";

__root const CFG_HDR cfghdr1_5={CFG_STR_WIN1251,"Bookmark 5 name",1,31};
__root const char BMNAME5[32]="";

__root const CFG_HDR cfghdr1_6={CFG_STR_WIN1251,"Bookmark 6 name",1,31};
__root const char BMNAME6[32]="";

__root const CFG_HDR cfghdr1_7={CFG_STR_WIN1251,"Bookmark 7 name",1,31};
__root const char BMNAME7[32]="";

__root const CFG_HDR cfghdr1_8={CFG_STR_WIN1251,"Bookmark 8 name",1,31};
__root const char BMNAME8[32]="";

__root const CFG_HDR cfghdr1_9={CFG_STR_WIN1251,"Bookmark 9 name",1,31};
__root const char BMNAME9[32]="";

__root const CFG_HDR cfghdr_m10={CFG_LEVEL,"",0,0};

__root const CFG_HDR cfghdr_m21={CFG_LEVEL,"Path to files",1,0};

__root const CFG_HDR cfghdr2_1={CFG_STR_UTF8,"Bookmark 1 file",3,127};
__root const char BM1FILE[128]="0:\\zbin\\mc\\mc.elf";

__root const CFG_HDR cfghdr2_2={CFG_STR_UTF8,"Bookmark 2 file",3,127};
__root const char BM2FILE[128]="";

__root const CFG_HDR cfghdr2_3={CFG_STR_UTF8,"Bookmark 3 file",3,127};
__root const char BM3FILE[128]="0:\\zbin\\naticq\\naticq.elf";

__root const CFG_HDR cfghdr2_4={CFG_STR_UTF8,"Bookmark 4 file",3,127};
__root const char BM4FILE[128]="";

__root const CFG_HDR cfghdr2_5={CFG_STR_UTF8,"Bookmark 5 file",3,127};
__root const char BM5FILE[128]="";

__root const CFG_HDR cfghdr2_6={CFG_STR_UTF8,"Bookmark 6 file",3,127};
__root const char BM6FILE[128]="";

__root const CFG_HDR cfghdr2_7={CFG_STR_UTF8,"Bookmark 7 file",3,127};
__root const char BM7FILE[128]="";

__root const CFG_HDR cfghdr2_8={CFG_STR_UTF8,"Bookmark 8 file",3,127};
__root const char BM8FILE[128]="";

__root const CFG_HDR cfghdr2_9={CFG_STR_UTF8,"Bookmark 9 file",3,127};
__root const char BM9FILE[128]="";

__root const CFG_HDR cfghdr_m20={CFG_LEVEL,"",0,0};


__root const CFG_HDR cfghdr_m31={CFG_LEVEL,"�������...",1,0};

__root const CFG_HDR cfghdr3_1={CFG_STR_WIN1251,"1 name",1,31};
__root const char NAME1[32]="Date";

__root const CFG_HDR cfghdr3_2={CFG_STR_WIN1251,"2 name",1,31};
__root const char NAME2[32]="Time";

__root const CFG_HDR cfghdr3_3={CFG_STR_WIN1251,"3 name",1,31};
__root const char NAME3[32]="����� ���";

__root const CFG_HDR cfghdr3_4={CFG_STR_WIN1251,"4 name",1,31};
__root const char NAME4[32]="Free disc 0:";

__root const CFG_HDR cfghdr3_5={CFG_STR_WIN1251,"5 name",1,31};
__root const char NAME5[32]="CPU Load";

__root const CFG_HDR cfghdr3_6={CFG_STR_WIN1251,"6 name",1,31};
__root const char NAME6[32]="����.����";

__root const CFG_HDR cfghdr3_7={CFG_STR_WIN1251,"7 name",1,31};
__root const char NAME7[32]="FreeRam:";

__root const CFG_HDR cfghdr3_8={CFG_STR_WIN1251,"8 name",1,31};
__root const char NAME8[32]="";

__root const CFG_HDR cfghdr3_9={CFG_STR_WIN1251,"9 name",1,31};
__root const char NAME9[32]="";


__root const CFG_HDR cfghdr_m30={CFG_LEVEL,"",0,0};


__root const CFG_HDR cfghdr_m41={CFG_LEVEL,"Path to icons...",1,0};

__root const CFG_HDR cfghdr4_1={CFG_STR_UTF8,"1 icon",0,127};
__root const char ICON1[128]="";

__root const CFG_HDR cfghdr4_2={CFG_STR_UTF8,"2 icon",0,127};
__root const char ICON2[128]="";

__root const CFG_HDR cfghdr4_3={CFG_STR_UTF8,"3 icon",0,127};
__root const char ICON3[128]="0:\\online.png";

__root const CFG_HDR cfghdr4_4={CFG_STR_UTF8,"4 icon",0,127};
__root const char ICON4[128]="";

__root const CFG_HDR cfghdr4_5={CFG_STR_UTF8,"5 icon",0,127};
__root const char ICON5[128]="";

__root const CFG_HDR cfghdr4_6={CFG_STR_UTF8,"6 icon",0,127};
__root const char ICON6[128]="";

__root const CFG_HDR cfghdr4_7={CFG_STR_UTF8,"7 icon",0,127};
__root const char ICON7[128]="";

__root const CFG_HDR cfghdr4_8={CFG_STR_UTF8,"8 icon",0,127};
__root const char ICON8[128]="";

__root const CFG_HDR cfghdr4_9={CFG_STR_UTF8,"9 icon",0,127};
__root const char ICON9[128]="";

__root const CFG_HDR cfghdr4_10={CFG_STR_UTF8,"No icon",0,127};
__root const char NO_ICON[128]="0:\\icons\\no_icon.png";

__root const CFG_HDR cfghdr_m40={CFG_LEVEL,"",0,0};
