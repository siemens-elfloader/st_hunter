#include "..\inc\swilib.h"
char filetostart[128];
int my_csm_id=0;

char BM1NAME[32];//info
char BM2NAME[32];
char BM3NAME[32];
char BM4NAME[32];
char BM5NAME[32];
char BM6NAME[32];
char BM7NAME[32];
char BM8NAME[32];
char BM9NAME[32];

extern const char NAME1[32];//name for info
extern const char NAME2[32];
extern const char NAME3[32];
extern const char NAME4[32];
extern const char NAME5[32];
extern const char NAME6[32];
extern const char NAME7[32];
extern const char NAME8[32];
extern const char NAME9[32];

extern const char ICON1[128];//path to icons
extern const char ICON2[128];
extern const char ICON3[128];
extern const char ICON4[128];
extern const char ICON5[128];
extern const char ICON6[128];
extern const char ICON7[128];
extern const char ICON8[128];
extern const char ICON9[128];
extern const char NO_ICON[128];

int S_ICONS[10]={
(int)ICON1,
(int)ICON2,
(int)ICON3,
(int)ICON4,
(int)ICON5,
(int)ICON6,
(int)ICON7,
(int)ICON8,
(int)ICON9,
(int)NO_ICON
};

extern const char BM9FILE[128];//path to files
extern const char BM1FILE[128];
extern const char BM2FILE[128];
extern const char BM3FILE[128];
extern const char BM4FILE[128];
extern const char BM5FILE[128];
extern const char BM6FILE[128];
extern const char BM7FILE[128];
extern const char BM8FILE[128];
//extern const char BM9FILE[128];

extern const char BMNAME1[32];//Name for bookmark
extern const char BMNAME2[32];
extern const char BMNAME3[32];
extern const char BMNAME4[32];
extern const char BMNAME5[32];
extern const char BMNAME6[32];
extern const char BMNAME7[32];
extern const char BMNAME8[32];
extern const char BMNAME9[32];

extern const int ENA_HELLO;
extern const int RED_BUT_MODE;
extern const int LONG_P;
extern void InitConfig();

volatile int contactlist_menu_id;
unsigned int *ErrorNumber;

const char percent_t[]="%t";
#ifdef NEWSGOLD
#define USE_ONE_KEY
#endif

#ifdef NEWSGOLD
#define DEFAULT_DISK "4"
#else
#define DEFAULT_DISK "0"
#endif

extern void kill_data(void *p, void (*func_p)(void *));
typedef struct
{
  CSM_RAM csm;
  int gui_id;
}MAIN_CSM;   

void *about()
{ char s[256];
snprintf(s,255,"Info Everywhere v0.1\n(c)kluchnik\nCompile:\n%s %s",__DATE__,__TIME__);
  ShowMSG(2, (int)s);
  return 0;
}
void info()
{ WSHDR *ws=AllocWS(256); 
  TDate date;
  TTime time;
  GetDateTime(&date,&time);
  RAMNET *rn=RamNet();
  int dayy=0;
  char ss[32],ss1[32],ss3[32],ss4[32],ss5[32],ss6[32],ss7[32];
  char *days[8]={" ","��","��","��","��","��","��","��"},
       *mounth[13]={" ","���","���","����","���","���","���","���","���","����","���","���","���"};
  dayy=date.day;
  while(dayy>7)
  {dayy=dayy-7;   
  }
  char *s=date.day<10?"0":"";
  sprintf(ss,"%s %s,%s%d %s",NAME1,days[dayy],s,date.day,mounth[date.month]);
  int len=strlen(ss);
    for(int j=0;j<len;j++)
    {BM1NAME[j]=ss[j];}

  char *t2=time.sec<10?"0":"";
  char *t=time.min<10?"0":"";
  sprintf(ss1,"%s %d:%s%d:%s%d",NAME2,time.hour,t,time.min,t2,time.sec);
  int len2=strlen(ss1);
    for(int j=0;j<len2;j++)
     {BM2NAME[j]=ss1[j];}
  sprintf(ss3,"%s %d %%",NAME3,*RamCap());
  int len3=strlen(ss3);
    for(int j=0;j<len3;j++)
     {BM3NAME[j]=ss3[j];}
  int f0 = GetFreeFlexSpace(0, ErrorNumber)/1024;
  sprintf(ss4,"%s %d kb",NAME4,f0);
  int len4=strlen(ss4);
    for(int j=0;j<len4;j++)
     {BM4NAME[j]=ss4[j];}
  sprintf(ss5,"%s %d %%",NAME5,GetCPULoad());
  int len5=strlen(ss5);
    for(int j=0;j<len5;j++)
     {BM5NAME[j]=ss5[j];}

  sprintf(ss6,"%s %d db",NAME6,rn->power);
  int len6=strlen(ss6);
    for(int j=0;j<len6;j++)
    {BM6NAME[j]=ss6[j];} 
    
    sprintf(ss7,"%s %d b",NAME7,GetFreeRamAvail()/1000);
  int len7=strlen(ss7);
    for(int j=0;j<len7;j++)
    {BM7NAME[j]=ss7[j];} 
}

#pragma inline
void patch_header(const HEADER_DESC* headc)
{
  HEADER_DESC *head=(HEADER_DESC *)headc;
  head->rc.x=0;
  head->rc.y=YDISP;
  head->rc.x2=ScreenW()-1;
  head->rc.y2=HeaderH()+YDISP;
}

void ElfKiller(void)
{
  extern void *ELF_BEGIN;
  kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}

const char *bm_name(int bm)//info
{
  switch(bm)
  {
  case 0: return BM1NAME;
  case 1: return BM2NAME;
  case 2: return BM3NAME;
  case 3: return BM4NAME;
  case 4: return BM5NAME;
  case 5: return BM6NAME;
  case 6: return BM7NAME;
  case 7: return BM8NAME;
  case 8: return "�� �����:)";
  }
  return(0);
}
const char *bmname(int bm)//real name
{
  switch(bm)
  {
  case 0: return BMNAME1;
  case 1: return BMNAME2;
  case 2: return BMNAME3;
  case 3: return BMNAME4;
  case 4: return BMNAME5;
  case 5: return BMNAME6;
  case 6: return BMNAME7;
  case 7: return BMNAME8;
  case 8: return "�� �����:)";
  }
  return(0);
}
const char *bm_file(int bm)
{
  switch(bm)
  {
  case 0: return BM1FILE;
  case 1: return BM2FILE;
  case 2: return BM3FILE;
  case 3: return BM4FILE;
  case 4: return BM5FILE;
  case 5: return BM6FILE;
  case 6: return BM7FILE;
  case 7: return BM8FILE;
  case 8: return about();
  }
  return(0);
}
void bm_menu_iconhndl(void *data, int curitem, void *unk);
void bm_menu_iconhnd(void *data, int curitem, void *unk);
const HEADER_DESC bm_menuhdr={0,0,131,21,NULL,(int)"Extra Info v0.1",LGP_NULL};
const int menusoftkeys[]={0,1,2};
const SOFTKEY_DESC menu_sk[]=
{
  {0x0004,0x0000,(int)"Name"},
  {0x0001,0x0000,(int)"Close"},
  {0x003D,0x0000,(int)LGP_DOIT_PIC}
};

const SOFTKEYSTAB menu_skt=
{
  menu_sk,0
};

const SOFTKEY_DESC menu_sk2[]=
{
  {0x0004,0x0000,(int)""},
  {0x0001,0x0000,(int)"Close"},
  {0x003D,0x0000,(int)LGP_DOIT_PIC}
};

const SOFTKEYSTAB menu_skt2=
{
  menu_sk2,0
};
void bm_menu_ghook(void *data, int cmd){}
int bm_menu_onkey(void *data, GUI_MSG *msg);
int bm_menu_onkey2(void *data, GUI_MSG *msg);


const MENU_DESC bm_menu=
{
  8,bm_menu_onkey,bm_menu_ghook,NULL,
  menusoftkeys,
  &menu_skt,
  0x10,//0x11,
  bm_menu_iconhndl,
  NULL,   //Items
  NULL,   //Procs
  0   //n
};
const ML_MENU_DESC bmmenu=
{
  8,bm_menu_onkey2,bm_menu_ghook,NULL,
  menusoftkeys,
  &menu_skt2,
  0x1,//0x1,
  bm_menu_iconhnd,
  NULL,   //Items
  NULL,   //Procs
  0,   //n
  0  
};
int RunBM(int bm)
{
  const char *s=bm_file(bm);
  if (s)
  {
    if (strlen(s))
    {
      WSHDR *ws;
      ws=AllocWS(150);
      str_2ws(ws,s,128);
      ExecuteFile(ws,0,0);
      FreeWS(ws);
      return(1);
    }
  }
  return(0);
}

void bm_menu_iconhndl(void *data, int curitem, void *unk)
{
  const char *s;
  WSHDR *ws;
  void *item=AllocMenuItem(data);

  s=bm_name(curitem);
  if (s)
  {
    if (strlen(s))
    {
      ws=AllocMenuWS(data,strlen(s));
      wsprintf(ws,percent_t,s);
    }
    else
    {
      ws=AllocMenuWS(data,10);
      wsprintf(ws,percent_t,"�����:)");
    }
  }
  else
  {
    ws=AllocMenuWS(data,10);
    wsprintf(ws,"error");
  }
  SetMenuItemText(data,item,ws,curitem);
}

void bm_menu_iconhnd(void *data, int curitem, void *unk)
{ const char *s;
  WSHDR *ws;
  int len1=strlen(ICON1);
  int len2=strlen(ICON2);
  int len3=strlen(ICON3);
  int len4=strlen(ICON4);  
  int len5=strlen(ICON5);
  int len6=strlen(ICON6);
  int len7=strlen(ICON7);
  int len8=strlen(ICON8);
  int len9=strlen(ICON9);
 
  void *item=AllocMenuItem(data);
  s=bmname(curitem); 
 
  if (s)
  {
    if (strlen(s))
    {
      ws=AllocMenuWS(data,strlen(s));
      wsprintf(ws,percent_t,s);
    }
    else
    {
      ws=AllocMenuWS(data,10);
      wsprintf(ws,percent_t,"�����:)");
    }
  }
  else
  {
    ws=AllocMenuWS(data,10);
    wsprintf(ws,"error");
  }
 
  switch(curitem)
  { 
  case 0:
    if(len1!=0)
      SetMenuItemIconArray(data,item,S_ICONS + curitem);
    else SetMenuItemIconArray(data,item,S_ICONS + 9);
    break;
  case 1:
    if(len2 != 0)
      SetMenuItemIconArray(data,item,S_ICONS + curitem);
    else SetMenuItemIconArray(data,item,S_ICONS + 9);
    break;
  case 2:
    if(len3!=0)
      SetMenuItemIconArray(data,item,S_ICONS + curitem);
    else SetMenuItemIconArray(data,item,S_ICONS + 9);
    break;
  case 3:
    if(len4!=0)
      SetMenuItemIconArray(data,item,S_ICONS + curitem);
    else SetMenuItemIconArray(data,item,S_ICONS + 9);
    break;
  case 4:
    if(len5!=0)
      SetMenuItemIconArray(data,item,S_ICONS + curitem);
    else SetMenuItemIconArray(data,item,S_ICONS + 9);
    break;
  case 5:
    if(len6!=0)
      SetMenuItemIconArray(data,item,S_ICONS + curitem);
    else SetMenuItemIconArray(data,item,S_ICONS + 9);
    break;
  case 6:
    if(len7!=0)
      SetMenuItemIconArray(data,item,S_ICONS + curitem);
    else SetMenuItemIconArray(data,item,S_ICONS + 9);
    break;    
  case 7:
    if(len8!=0)
      SetMenuItemIconArray(data,item,S_ICONS + curitem);
    else SetMenuItemIconArray(data,item,S_ICONS + 9);
    break;
  case 8:
    if(len9!=0)
      SetMenuItemIconArray(data,item,S_ICONS + curitem);
    else SetMenuItemIconArray(data,item,S_ICONS + 9);
    break;
  }
  SetMenuItemText(data,item,ws,curitem);
}

void ShowBMmenu(void)
{
  patch_header(&bm_menuhdr);
  CreateMenu(0,0,&bm_menu,&bm_menuhdr,0,9,0,0);
}

void ShowBMmenu1(void)
{
  patch_header(&bm_menuhdr);
  CreateMultiLinesMenu(0,0,&bmmenu,&bm_menuhdr,0,9);
}


int bm_menu_onkey(void *data, GUI_MSG *msg)
{
  int i;
  i=GetCurMenuItem(data);
  int k=msg->gbsmsg->submess;
  if (msg->keys==0x15)// '#'
  {
      WSHDR *ws;
      ws=AllocWS(150);
      str_2ws(ws,DEFAULT_DISK":\\Zbin\\utilities\\CfgEdit.elf",128);
      ExecuteFile(ws,0,0);
      FreeWS(ws);
    return(-1);
  }
  
  if(msg->keys==RIGHT_SOFT)
   {ShowBMmenu1();
    return (-1);
   }
   if ((k>='1')&&(k<='9'))
      { if (RunBM(k-'1')) return 1;
	return(-1);
      }
  if (msg->keys==0x3D)
  {
    if (RunBM(i))
    {
      return(1);
    }
    return(-1);
  }
  return(0);
}

int bm_menu_onkey2(void *data, GUI_MSG *msg)
{
  int i;
  i=GetCurMenuItem(data);
  int k=msg->gbsmsg->submess;
  if(msg->keys==RIGHT_SOFT)
   {ShowBMmenu();
    return (-1);
   }
  if ((k>='1')&&(k<='9'))
   { if (RunBM(k-'1')) return 1;
     return(-1);
   }
  if (msg->keys==0x3D)
  {
    if (RunBM(i))
    {
      return(1);
    }
    return(-1);
  }
  return(0);
}


int mm_menu_onkey(void *data, GUI_MSG *msg)
{
  int i;
  if (msg->gbsmsg->msg==KEY_DOWN)
  {
    i=msg->gbsmsg->submess;
    {
      if (i=='0')
      {
        ShowBMmenu();
        return(-1);
      }
      if ((i>='1')&&(i<='9'))
      {
        if (RunBM(i-'1')) return 1;
	return(-1);
      }
    }
   }
    
  return(0);
}
unsigned int *ErrorNumber;

typedef struct
{
  GUI gui;
  int show_csm;
}DUMMY_GUI;

int mode;
extern const int BTN;
int keyhook(int submsg, int msg)
{
  int scrH=ScreenH();
  int scrW=ScreenW();
  if(IsUnlocked() && submsg==BTN)
  {
    if(mode==1)
    {
      if(msg==KEY_UP)
      {
        GBS_SendMessage(MMI_CEPID,KEY_DOWN,BTN);
        return(0);
      }
      if(msg==KEY_DOWN)
      {
        mode=0;
        GBS_SendMessage(MMI_CEPID,KEY_UP,BTN);
        return(0);
      }
    }

    if(msg==KEY_UP)
    { if(mode==2)
      {
        mode=0;
        return(2);
      }
    }
    else if(msg==(LONG_P?LONG_PRESS:KEY_DOWN) )
    {info();ShowBMmenu();
      }
   if(!IsUnlocked()) return(2);

    if(LONG_P)
    {
      if(msg==LONG_PRESS)
      {
        mode=2;
        return(2);
      }
      if(msg==KEY_DOWN)
      {
        mode=1;
        return(2);
      }
    }
    else  return(2);
  } 
  return(0);

}
int main()
{ InitConfig();
  if (!AddKeybMsgHook_end((void *)keyhook))
  {
    ShowMSG(1,(int)"���������� ���������������� ����������!");
    SUBPROC((void *)ElfKiller);
  }
  if(ENA_HELLO) ShowMSG(1,(int)"Info started!");
  
}
