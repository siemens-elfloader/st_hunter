#include "../inc/swilib.h"

void Message(char *s) 
{
   ShowMSG(1,(int)s);
};

void Message(int i)
{
   const char _d[]="%d";
   char s[32];
   sprintf(s,_d,i);      
   ShowMSG(1,(int)s);
};

