
void Message(char *s);
void Message(int i);