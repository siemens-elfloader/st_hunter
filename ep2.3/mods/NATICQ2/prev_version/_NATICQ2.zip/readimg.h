#include "swilib.h"

IMGHDR *read_pngimg(const char *buf);

IMGHDR *CreateImgr(int width, int height);

IMGHDR *CreateImgr16(int width, int height);
