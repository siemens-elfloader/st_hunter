#ifndef _PROTECT_H_
#define _PROTECT_H_

char *getkey();
int invalidkey();
#endif
