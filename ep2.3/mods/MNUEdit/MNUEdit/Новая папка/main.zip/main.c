#include "..\inc\swilib.h"
#include "fileman.c"
CSM_DESC icsmd;

int (*old_icsm_onMessage)(CSM_RAM*,GBS_MSG*);
unsigned int MAINCSM_ID = 0;
unsigned int MAINGUI_ID = 0;
const int minus11=-11;
const char per_t[]="%t";


unsigned short maincsm_name_body[140];

typedef struct
{
  CSM_RAM csm;
  int gui_id;
}MAIN_CSM;

typedef struct
{
  GUI gui;
  WSHDR *ws1;
  WSHDR *ws2;
  int i1;
}MAIN_GUI;

int DrawText(/*int curitem*/);
void create(void);

GBSTMR mytmr;

char file[256];
int TotalItem=0;
int j;
int k;
DIR_ENTRY de;

void submenu(void);
void SaveFile();
int my_csm_id=0;

unsigned int err;

const char percent_t[]="%t";
const char per_s[]="%s";
const char empty_str[]="";

#pragma inline
void patch_header(const HEADER_DESC* headc)
{
  HEADER_DESC *head=(HEADER_DESC *)headc;
  head->rc.x=0;
  head->rc.y=YDISP;
  head->rc.x2=ScreenW()-1;
  head->rc.y2=HeaderH()+YDISP;
}
#pragma inline
void patch_input(const INPUTDIA_DESC* inp)
{
  ((INPUTDIA_DESC*)inp)->rc.x=0;
  ((INPUTDIA_DESC*)inp)->rc.y=HeaderH()+1+YDISP;
  ((INPUTDIA_DESC*)inp)->rc.x2=ScreenW()-1;
  ((INPUTDIA_DESC*)inp)->rc.y2=ScreenH()-SoftkeyH()-1;
}
//=============================================================================
typedef struct
{
  void *next;
  char name[64];
  char icon[256];
  char type[24];
  char path[128];
  int item;
  WSHDR *ws_name;
  WSHDR *ws_icon;
  WSHDR *ws_type;
  WSHDR *ws_path;
  int change;
}MNU;
   
EDITCONTROL ec;

MNU menu[40];//���������� �������,����� ������ �� �����...:)

void *about()
{ 
  char s[128];
  snprintf(s,128,"MNUEdit v0.1b\n(c)kluchnik\n%s %s",__DATE__,__TIME__);
  ShowMSG(2, (int)s);
  mfree(s);
  return 0;
}

void process(char *str, int number)//������ ������ � ��������� ����
{ 
  j=0; 
  k=0;
  while (str[j]!='|') { menu[number].name[k++]=str[j]; j++;}    
  j++;
  k=0;
  while (str[j]!='|') { menu[number].icon[k++]=str[j]; j++;}    
  j++;
  k=0;
  while (str[j]!='|') { menu[number].type[k++]=str[j]; j++;}
  j++;
  k=0;
  while (str[j]!='\r'/*j<=strlen(str)*/) { menu[number].path[k++]=str[j]; j++;}
}

void LoadMNU(char *path)//��� ������...
{
  unsigned int err; 
  int plhandle; 
  char *mem;
  int size; 
  int i; 
  char *str; 
   plhandle = fopen( path, A_ReadOnly + A_BIN, P_READ, & err ); 
 if ( plhandle==-1 ) 
  {
    ShowMSG(1,(int)"Can't open *.mnu");
    fclose( plhandle, & err ); 
    return; 
  }
  mem=malloc(10000); 
  str=malloc(256); 
 if ((mem!=0)&&(str!=0)) 
  { 
    size=fread(plhandle,mem,9999,&err); 
    i=0; 
    while (i<size) //���� �� ����� ����� 
    { 
      strcpy(str," "); 
      j=0; 
      while (((*(mem+i)!='\n')) && (i<size) ) {*(str+j)=*(mem+i); j++;i++;}    //������ ������ �� ����� 
      //������������ ���� ������� 
      process(str,TotalItem);//��������� ����� � ����
      i++;  
      TotalItem++;
    }
  }
fclose(plhandle,&err); 
mfree(mem); 
mfree(str); 
//create();
}

//==========================
//      ������� ������
//==========================
void bm_menu_iconhnd(void *data, int curitem, void *unk);
const HEADER_DESC bm_menuhdr={0,0,131,21,NULL,(int)"MNUEditor",LGP_NULL};
const int menusoftkeys[]={0,1,2};

const SOFTKEY_DESC menu_sk2[]=
{
  {0x0004,0x0000,(int)"Save!"},
  {0x0001,0x0000,(int)"Close"},
  {0x003D,0x0000,(int)LGP_DOIT_PIC}
};

const SOFTKEYSTAB menu_skt2=
{
  menu_sk2,0
};

void bm_menu_ghook(void *data, int cmd)
{
  if(cmd==3)//Destroy
    {
      SaveFile();
    }
}
int bm_menu_onkey2(void *data, GUI_MSG *msg)
{
  int i;
  i=GetCurMenuItem(data);
//  int k=msg->gbsmsg->submess;
 if(msg->keys==0x14)
   {
     about();
     return (-1);
   }

 if(msg->keys==0x04 || (msg->keys==0x3D))
 {
   menu[0].item=i;//����� ������ ����
   menu[0].change=1;
   DrawText();
   return (-1);
 }
  
return 0;
}
const HEADER_DESC bm_menuhdr2={0,0,131,21,NULL,(int)"MNUEditor",LGP_NULL};

MENU_DESC bmmenu=//Bookmarks
{
  8,bm_menu_onkey2,bm_menu_ghook,NULL,
  menusoftkeys,
  &menu_skt2,
  0x10,//0x1,
  bm_menu_iconhnd,
  NULL,   //Items
  NULL,   //Procs
  0  //n    
};



//==============================================
//  ����� �� ����� �������� �������� � �������
//==============================================
void bm_menu_iconhnd(void *data, int curitem, void *unk)
{
  char *s;
  WSHDR *ws;
  void *item=AllocMenuItem(data);
  s=malloc(512);
  sprintf(s,per_s,menu[curitem].name); 
  menu[curitem].item=curitem;

  if (s)
  {
    if (strlen(s))
    { 
      ws=AllocMenuWS(data,strlen(s)+128);
      wsprintf(ws,"%d.%t",curitem+1,s);
    }  
  else
   {
    ws=AllocMenuWS(data,10);
    wsprintf(ws,"error");
    wsInsertChar(ws,2,1);//���� ��������
   }
  }
  SetMenuItemText(data,item,ws,curitem);
  mfree(s);
  FreeWS(ws);

}

void create(void)
{  
  patch_header(&bm_menuhdr);
  CreateMenu(0,0,&bmmenu,&bm_menuhdr2,0,TotalItem-1,0,0);
}
//==============================================================================
char *name_mnu[]={"���","������","��������","���� � �����/��������"};
char *action[]={"FILE","SHORTCUT","SUBMENU","FOLDER","KEYSEND"};
char *act_icon[]={"���� � ��������","����� �� �����"};
char *act_path[]={"Path","Shortcut"};
//path/shortcut/number

//==========================
//      ������� ������
//==========================

void menu_iconhnd(void *data, int curitem, void *unk);
const HEADER_DESC menu_menuhdr={0,0,131,21,NULL,(int)"MNUEditor",LGP_NULL};

void menu_ghook(void *data, int cmd)
{
//  MNU t[100];
 if (cmd==3)//Destroys
  {
//  sub=0;
    //actions=0;//� �� ����� ��� ������� ����������������...:)
    /*
    for(int i=0;i<TotalItem;i++)
      {
        mfree(t[i].name);
        mfree(t[i].icon);
        mfree(t[i].type);
        mfree(t[i].path);
                            
      }*/
  }

}



int menu_onkey2(void *data, GUI_MSG *msg)
{

 if(msg->keys==0x14)
   {
     about();
     return (-1);
   }

return 0;
}
const HEADER_DESC menu_menuhdr2={0,0,131,21,NULL,(int)"Edit",LGP_NULL};

MENU_DESC mnu_menu=
{
  8,menu_onkey2,menu_ghook,NULL,
  menusoftkeys,
  &menu_skt2,
  0x10,//0x1,
  menu_iconhnd,
  NULL,   //Items
  NULL,   //Procs
  0  //n    
};

//------------------------------------------------------------------------------

void menu_iconhnd(void *data, int curitem, void *unk)
{
  char *s;
  WSHDR *ws;
  void *item=AllocMenuItem(data);
  s=malloc(512);
  
  if (s)
  {
    if (strlen(s))
    { 
      ws=AllocMenuWS(data,strlen(s)+128);
      wsprintf(ws,percent_t,s);
    }
  else
    {
      ws=AllocMenuWS(data,10);
      wsprintf(ws,"error");
    }
  }
 SetMenuItemText(data,item,ws,curitem);
 mfree(s);
 FreeWS(ws);

}

void submenu(void)
{  
  patch_header(&bm_menuhdr);
  CreateMenu(0,0,&mnu_menu,&menu_menuhdr2,0,4,0,0);
}
//==============================================================================
WSHDR *ws_name;
void maincsm_oncreate(CSM_RAM *data)
{
  MAIN_CSM *csm=(MAIN_CSM*)data;
  ws_name=AllocWS(256);
  csm->gui_id=DrawText();
}

void Killer(void)
{
  extern void seqkill(void *data, void(*next_in_seq)(CSM_RAM *), void *data_to_kill, void *seqkiller);
  extern void *ELF_BEGIN;
}

void maincsm_onclose(CSM_RAM *csm)
{
   SUBPROC((void *)Killer);
}

int maincsm_onmessage(CSM_RAM *data, GBS_MSG *msg)
{
  MAIN_CSM *csm=(MAIN_CSM*)data;
  if (msg->msg==MSG_GUI_DESTROYED)
  {
    if ((int)msg->data0==csm->gui_id)
    {
      {
	csm->csm.state=-3;
      }
    }
  }
 
  return(1);
}

unsigned short maincsm_name_body[140];

const struct
{
  CSM_DESC maincsm;
  WSHDR maincsm_name;
}MAINCSM =
{
  {
  maincsm_onmessage,
  maincsm_oncreate,
#ifdef NEWSGOLD
  0,
  0,
  0,
  0,
#endif
  maincsm_onclose,
  sizeof(MAIN_CSM),
  1,
  &minus11
  },
  {
    maincsm_name_body,
    NAMECSM_MAGIC1,
    NAMECSM_MAGIC2,
    0x0,
    139
  }
};

void UpdateCSMname(void)
{ 
  wsprintf((WSHDR *)(&MAINCSM.maincsm_name),"MNUEdit");
}


int main(char *exename, char *fname)
{ 
  if (fname)
  {
    if (strlen(fname)<256)
    {
      strcpy(file,fname);
    }
    LoadMNU(file);
  }
  else LoadMNU("0:\\stdirs.mnu");  
  create();
/*
  char dummy[sizeof(MAIN_CSM)];
  LockSched();
  UpdateCSMname();
  CreateCSM(&MAINCSM.maincsm,dummy,0);
  UnlockSched();
  */
 return 0;
}


//==============================================================================

void on_utf8ec(USR_MENU_ITEM *item)
{
  if (item->type==0)
  {
    switch(item->cur_item)
    {
    case 0:
      wsprintf(item->ws,per_t,"SelectFile");
      break;
    }
  }

  if (item->type==1)
  {
    switch(item->cur_item)
    {
    case 0: 
      CreateRootMenu();open_fm();
      break;
    }
  }   
}
//=================================================
HEADER_DESC disk_prop_hdr={0,0,131,21,NULL,0,LGP_NULL};
int empty_onkey(GUI *data, GUI_MSG *msg)
{ 
//  EDITCONTROL ec[4];
  if (msg->gbsmsg->msg==KEY_DOWN)
  { 
    int CurPos=EDIT_GetCursorPos(data)-1;
    switch(msg->gbsmsg->submess)
    {
      case ENTER_BUTTON: EDIT_OpenOptionMenuWithUserItems(data,on_utf8ec,data,1); return -1;
      case GREEN_BUTTON:case RIGHT_SOFT: 
		
                ExtractEditControl(data,2,&ec);	
		wstrcpy(menu[menu[0].item].ws_name,ec.pWS);
                GeneralFuncF1(1);
                
                ExtractEditControl(data,4,&ec);	
		wstrcpy(menu[menu[0].item].ws_icon,ec.pWS);
                GeneralFuncF1(1);

                ExtractEditControl(data,6,&ec);	
		wstrcpy(menu[menu[0].item].ws_type,ec.pWS);
                GeneralFuncF1(1);

                ExtractEditControl(data,8,&ec);	
		wstrcpy(menu[menu[0].item].ws_path,ec.pWS);
                GeneralFuncF1(1);
    
                if(menu[0].change)
                {
                    ws_2str(menu[menu[0].item].ws_name,menu[menu[0].item].name,64);
                    ws_2str(menu[menu[0].item].ws_icon,menu[menu[0].item].icon,256);
                    ws_2str(menu[menu[0].item].ws_type,menu[menu[0].item].type,8);
                    ws_2str(menu[menu[0].item].ws_path,menu[menu[0].item].path,256);
                }
                break;
    }

  }
return(0);
}

SOFTKEY_DESC sk[];

SOFTKEYSTAB skt=
{
  sk,0
};
int cur_pos=1;
void empty_locret(void){}
void empty_ghook(GUI *gui, int cmd)
{ 
 // static SOFTKEY_DESC sk={0x0018, 0x0000,(int)"Save"};
  if (cmd==7)
  {
//    SetSoftKey(gui,&sk2,1);
  }

  if(cmd==0xA)
  {
    DisableIDLETMR();   // ��������� ������ ������ �� ��������
  }
  if (cmd==0x0C)
  {
   ws_name=AllocWS(256);
    // EDIT_SetCursorPos(gui,1);    
  }
  if(cmd==0x03)     // onDestroy
  {
   //sub=0;
  //    FreeWS(ews);
  //  ews = NULL;
 //   SaveFile();
    menu[0].change=0;
  }

};


INPUTDIA_DESC edit_desc=//��������������
{
  1,
  empty_onkey,
  empty_ghook,
  (void *)empty_locret,
  0,
  &skt,
  {0,0,0,0},
  FONT_SMALL,
  100,
  101,
  0,
  0,
  0x40000000
};
 
//===========================
char *sss=NULL;
void SaveFile()
{
  unsigned int err;
  int f;
//  ws_2str(menu[0].ws_name,menu[0].name,wstrlen(menu[0].ws_name));
  char *s=malloc(10000);
  char *ss=malloc(256);
//  ws_2str(ws_name,ss,256);
//  sprintf(menu[0].name,per_s,ss);
  unlink("0:\\zzzz.mnu.c",&err);
  if((f=fopen("0:\\zzzz.mnu.c",A_Create+A_ReadWrite+A_BIN+A_Append,P_WRITE,&err))!=-1)
   {

     for(int i=0;i<TotalItem;i++)//TotalItem
      {
        sprintf(s,empty_str);
/*      if(menu[0].change)
      {
        ws_2str(menu[i].ws_name,menu[i].name,64);
        ws_2str(menu[i].ws_icon,menu[i].icon,256);
        ws_2str(menu[i].ws_type,menu[i].type,8);
        ws_2str(menu[i].ws_path,menu[i].path,256);
      }*/
        sprintf(s,"%s|%s|%s|%s\n",menu[i].name,menu[i].icon,menu[i].type,menu[i].path);    
        fwrite(f,s,strlen(s),&err);
      }
     ShowMSG(1,(int)"File Save!!!");
   }
  else ShowMSG(1,(int)"Don't save!:(");
  fclose(f,&err);
  mfree(s);
}
//===========================
int DrawText(/*int curitem*/)
{  
  EDITC_OPTIONS ec_options;
  PrepareEditControl(&ec);

  void *ma=malloc_adr();
  void *eq=AllocEQueue(ma, mfree_adr());
  menu[menu[0].item].ws_name=AllocWS(64);
  menu[menu[0].item].ws_icon=AllocWS(256);
  menu[menu[0].item].ws_type=AllocWS(8);
  menu[menu[0].item].ws_path=AllocWS(256);
  
  char *ss=malloc(64);
  WSHDR *wss=AllocWS(64);

  wsprintf(wss,per_s,"���:");
  ConstructEditControl(&ec,ECT_HEADER,ECF_SET_CURSOR_END,wss,12);
  SetPenColorToEditCOptions(&ec_options,2);
  CopyOptionsToEditControl(&ec,&ec_options);
  AddEditControlToEditQend(eq,&ec,ma);
  wsprintf(menu[menu[0].item].ws_name,per_s,menu[menu[0].item].name);
  ConstructEditControl(&ec,ECT_NORMAL_TEXT,ECF_SET_CURSOR_END,menu[menu[0].item].ws_name,256);//F_NORMAL_STR
  PrepareEditCOptions(&ec_options);
  SetFontToEditCOptions(&ec_options,1);
  SetPenColorToEditCOptions(&ec_options,0);
  CopyOptionsToEditControl(&ec,&ec_options);
  AddEditControlToEditQend(eq,&ec,ma);

  wsprintf(wss,per_s,"\n������:");
  ConstructEditControl(&ec,ECT_HEADER,ECF_APPEND_EOL,wss,12);
  SetPenColorToEditCOptions(&ec_options,2);
  CopyOptionsToEditControl(&ec,&ec_options);
  AddEditControlToEditQend(eq,&ec,ma);
  wsprintf(menu[menu[0].item].ws_icon,per_s,menu[menu[0].item].icon);
  ConstructEditControl(&ec,ECT_NORMAL_TEXT,ECF_SET_CURSOR_END,menu[menu[0].item].ws_icon,256);//F_NORMAL_STR
  PrepareEditCOptions(&ec_options);
  SetFontToEditCOptions(&ec_options,1);
  SetPenColorToEditCOptions(&ec_options,0);
  CopyOptionsToEditControl(&ec,&ec_options);
  AddEditControlToEditQend(eq,&ec,ma);
  
  wsprintf(wss,per_s,"\n��������:");
  ConstructEditControl(&ec,ECT_HEADER,ECF_APPEND_EOL,wss,12);
  SetPenColorToEditCOptions(&ec_options,2);
  CopyOptionsToEditControl(&ec,&ec_options);
  AddEditControlToEditQend(eq,&ec,ma);
  wsprintf(menu[menu[0].item].ws_type,per_s,menu[menu[0].item].type);
  ConstructEditControl(&ec,ECT_NORMAL_TEXT,ECF_SET_CURSOR_END,menu[menu[0].item].ws_type,8);//F_NORMAL_STR
  PrepareEditCOptions(&ec_options);
  SetFontToEditCOptions(&ec_options,1);
  SetPenColorToEditCOptions(&ec_options,0);
  CopyOptionsToEditControl(&ec,&ec_options);
  AddEditControlToEditQend(eq,&ec,ma);
  
  wsprintf(wss,per_s,"\n����/shortcut:");
  ConstructEditControl(&ec,ECT_HEADER,ECF_APPEND_EOL,wss,24);
  SetPenColorToEditCOptions(&ec_options,2);
  CopyOptionsToEditControl(&ec,&ec_options);
  AddEditControlToEditQend(eq,&ec,ma);
  wsprintf(menu[menu[0].item].ws_path,per_s,menu[menu[0].item].path);
  ConstructEditControl(&ec,ECT_NORMAL_TEXT,ECF_SET_CURSOR_END,menu[menu[0].item].ws_path,256);//F_NORMAL_STR
  PrepareEditCOptions(&ec_options);
  SetFontToEditCOptions(&ec_options,1);
  SetPenColorToEditCOptions(&ec_options,0);
  CopyOptionsToEditControl(&ec,&ec_options);
  AddEditControlToEditQend(eq,&ec,ma);

  disk_prop_hdr.lgp_id = (int)"Edit";        
  patch_header(&disk_prop_hdr);
  patch_input(&edit_desc);      

  FreeWS(wss);
//  FreeWS(menu[curitem].ws_name);
//  FreeWS(menu[curitem].ws_icon);
//  FreeWS(menu[curitem].ws_type);
//  FreeWS(menu[curitem].ws_path);
  mfree(ss);
  return CreateInputTextDialog(&edit_desc,&disk_prop_hdr,eq,1,0);
}



