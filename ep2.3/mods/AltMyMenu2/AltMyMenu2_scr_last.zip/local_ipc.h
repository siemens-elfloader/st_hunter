#define IPC_TEXTINFO_NAME "AltMyMenu2"
#define IPC_UPDATE_STAT 1
#define IPC_CHECK_DOUBLERUN 2
#define IPC_OPEN_GUI 3

