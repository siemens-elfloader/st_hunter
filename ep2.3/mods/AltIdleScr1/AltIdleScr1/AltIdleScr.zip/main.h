#ifndef _MAIN_H_
  #define _MAIN_H_
typedef struct
{ int x;
  int y;
}crds;

crds crd[6];

#define clock 0
#define NetDB 1
#define NetAdv 2
#define BattCap 3
#define BattVolt 4
#define Dialogs 5

typedef struct
{ char filename[64];
  char file[256];
}NamePanel;

NamePanel name[9];
int NumberPanelFile;
int NumOfItems=0;

char *NAME[6];

void SaveNamePanel();
int i;

#endif

