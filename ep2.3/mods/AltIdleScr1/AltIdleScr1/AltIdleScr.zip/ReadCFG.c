/************* 
*���� ����:  * 
*bat|x|y     * 
*netDB|x|y   *
*� �.�.      *
*************/ 

#include "main.h"

int atoi(char *attr)
{
  int ret=0;
  int neg=1;
  for (int k=0; ; k++)
  {
    if ( attr[k]>0x2F && attr[k]<0x3A) {ret=ret*10+attr[k]-0x30;} 
    else { if ( attr[k]=='-') {neg=-1;} 
           else {return(ret*neg);}
         }
  }
  
}
void LoadParamsCrd()
{ 
  unsigned int err; 
  int crdcfg; 
  char mem[9999]; 
  char *name;
  crdcfg = fopen( "0:\\coord.cfg", A_ReadOnly + A_BIN, P_READ, & err ); 
 if ( crdcfg==-1 ) 
 {  ShowMSG(1,(int)"Can't open coord.cfg"); 
    fclose( crdcfg, & err ); 
 } 
     fread(crdcfg,mem,9999,&err); 
     
     name=strstr(mem,"Cap x")+6;
     crd[BattCap].x=atoi(name);
     
     name=strstr(mem,"Cap y")+6;
     crd[BattCap].y=atoi(name);

     name=strstr(mem,"Volt x")+7;
     crd[BattVolt].x=atoi(name);
     
     name=strstr(mem,"Volt y")+7;
     crd[BattVolt].y=atoi(name);
     
     name=strstr(mem,"clock x")+8;
     crd[clock].y=atoi(name);
    
     name=strstr(mem,"clock y")+8;
     crd[clock].y=atoi(name);
     
     name=strstr(mem,"NetAdv x")+9;
     crd[NetAdv].y=atoi(name);
     
     name=strstr(mem,"NetAdv y")+9;
     crd[NetAdv].y=atoi(name);
     
     name=strstr(mem,"NetDB x")+8;
     crd[NetDB].y=atoi(name);
     
     name=strstr(mem,"NetDB y")+8;
     crd[NetDB].y=atoi(name);
     
     name=strstr(mem,"Dialogs x")+10;
     crd[Dialogs].x=atoi(name);
     
     name=strstr(mem,"Dialogs y")+10;
     crd[Dialogs].y=atoi(name);
       
fclose( crdcfg, & err ); 
}





void process(char *str, int number)
{ int j=0; 
  int k=0;
  while (str[j]!='|') {name[number].filename[k++]=str[j]; j++;}    
  j++;
  k=0;
  while (str[j]!='|') {name[number].file[k++]=str[j]; j++;}    
}
int i=0;
void SaveNamePanel()
{
  for(i=0;i<=9;i++)
    NAME[i]=name[i].filename;
    NumberPanelFile++;

}
void LoadParams() 
{
  unsigned int err; 
  int plhandle; 
  char *mem;
  int size; 
  int i,j=0; 
  char *str; 
   plhandle = fopen( "0:\\name.cfg", A_ReadOnly + A_BIN, P_READ, & err ); 
 if ( plhandle==-1 ) 
  { 
    fclose( plhandle, & err ); 
    return; 
  } 
  mem=malloc(10000); 
  str=malloc(256); 
 if ((mem!=0)&&(str!=0)) 
  { 
    size=fread(plhandle,mem,9999,&err); 
    i=0; 
    while (i<size) //���� �� ����� ����� 
    { 
      strcpy(str,""); 
      j=0; 
      while (((*(mem+i)!='\r'))&&(i<size)) {*(str+j)=*(mem+i); j++;i++;}    //������ ������ �� ����� 
      //������������ ���� ������� 
      process(str,NumOfItems);//��������� ����� � ����
      i++; 
      NumOfItems++;
    
    }
  }
mfree(mem); 
mfree(str); 
fclose( plhandle, & err ); 
}
