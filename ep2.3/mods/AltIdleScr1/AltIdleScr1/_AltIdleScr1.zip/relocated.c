/*#pragma swi_number=0x80EA
__swi __arm int PicVibra();

#pragma swi_number=0x80EA
__swi __arm int PicVibra();

#pragma swi_number=0x80EA
__swi __arm int PicVibra();

#pragma swi_number=0x80EA
__swi __arm int PicVibra();

#pragma swi_number=0x80EA
__swi __arm int PicVibra();

#pragma swi_number=0x80EA
__swi __arm int PicVibra();

#pragma swi_number=0x80EA
__swi __arm int PicVibra();

#pragma swi_number=0x80EA
__swi __arm int PicVibra();

#pragma swi_number=0x80EA
__swi __arm int PicVibra();
*/

