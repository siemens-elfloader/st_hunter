#include "..\inc\cfg_items.h"

__root const CFG_HDR cfghdr0={CFG_STR_UTF8,"����",0,127};
__root const char dir[128]="0:\\Mark";
